import { useEffect, useState } from "react";

export interface MateriaStat {
  answered: number;
  correct: number;
  timeSec: number;
}

export interface DailyStat {
  date: string; // YYYY-MM-DD
  answered: number;
  correct: number;
}

export interface SimuladoResult {
  date: string;
  corretas: number;
  total: number;
  notaTri: number;
}

export interface UserStats {
  xp: number;
  streakDays: number;
  bestStreak: number;
  lastStudyDate: string | null; // YYYY-MM-DD
  totalAnswered: number;
  totalCorrect: number;
  perMateria: Record<string, MateriaStat>;
  daily: DailyStat[];
  simulados: SimuladoResult[];
  createdAt: string;
}

const STORAGE_PREFIX = "aprovaedu-stats:";

function currentUserKey(): string {
  try {
    const raw = localStorage.getItem("sb-ozuhsrhuedsdbbrokvwt-auth-token");
    if (raw) {
      const parsed = JSON.parse(raw);
      const uid = parsed?.user?.id ?? parsed?.currentSession?.user?.id;
      if (uid) return uid;
    }
  } catch {}
  return "anon";
}

export function emptyStats(): UserStats {
  return {
    xp: 0,
    streakDays: 0,
    bestStreak: 0,
    lastStudyDate: null,
    totalAnswered: 0,
    totalCorrect: 0,
    perMateria: {},
    daily: [],
    simulados: [],
    createdAt: new Date().toISOString(),
  };
}

function todayStr(): string {
  return new Date().toISOString().slice(0, 10);
}

function loadStats(): UserStats {
  try {
    const raw = localStorage.getItem(STORAGE_PREFIX + currentUserKey());
    if (raw) return { ...emptyStats(), ...JSON.parse(raw) };
  } catch {}
  return emptyStats();
}

function saveStats(s: UserStats) {
  try {
    localStorage.setItem(STORAGE_PREFIX + currentUserKey(), JSON.stringify(s));
    window.dispatchEvent(new CustomEvent("stats-changed"));
  } catch {}
}

function bumpStreak(s: UserStats): UserStats {
  const today = todayStr();
  if (s.lastStudyDate === today) return s;
  let streak = 1;
  if (s.lastStudyDate) {
    const last = new Date(s.lastStudyDate);
    const diff = Math.round((Date.now() - last.getTime()) / 86400000);
    if (diff === 1) streak = s.streakDays + 1;
  }
  return {
    ...s,
    streakDays: streak,
    bestStreak: Math.max(streak, s.bestStreak),
    lastStudyDate: today,
  };
}

function bumpDaily(s: UserStats, correct: boolean): UserStats {
  const today = todayStr();
  const daily = [...s.daily];
  const idx = daily.findIndex((d) => d.date === today);
  if (idx >= 0) {
    daily[idx] = {
      ...daily[idx],
      answered: daily[idx].answered + 1,
      correct: daily[idx].correct + (correct ? 1 : 0),
    };
  } else {
    daily.push({ date: today, answered: 1, correct: correct ? 1 : 0 });
  }
  return { ...s, daily: daily.slice(-30) };
}

export function recordAnswer(params: {
  materia: string;
  correct: boolean;
  xp: number;
  timeSec?: number;
}) {
  let s = loadStats();
  s = bumpStreak(s);
  s = bumpDaily(s, params.correct);
  s.totalAnswered += 1;
  if (params.correct) s.totalCorrect += 1;
  s.xp += params.xp;
  const m = s.perMateria[params.materia] ?? { answered: 0, correct: 0, timeSec: 0 };
  s.perMateria[params.materia] = {
    answered: m.answered + 1,
    correct: m.correct + (params.correct ? 1 : 0),
    timeSec: m.timeSec + (params.timeSec ?? 30),
  };
  saveStats(s);
}

export function recordSimulado(r: Omit<SimuladoResult, "date">) {
  let s = loadStats();
  s = bumpStreak(s);
  s.simulados.push({ ...r, date: todayStr() });
  saveStats(s);
}

export function resetStats() {
  saveStats(emptyStats());
}

export function useStats(): UserStats {
  const [s, setS] = useState<UserStats>(() => loadStats());
  useEffect(() => {
    const handler = () => setS(loadStats());
    window.addEventListener("stats-changed", handler);
    window.addEventListener("storage", handler);
    return () => {
      window.removeEventListener("stats-changed", handler);
      window.removeEventListener("storage", handler);
    };
  }, []);
  return s;
}

export function taxaAcerto(s: UserStats): number {
  return s.totalAnswered ? s.totalCorrect / s.totalAnswered : 0;
}

export function predicaoEnem(s: UserStats): number {
  if (s.simulados.length > 0) {
    const avg =
      s.simulados.reduce((a, x) => a + x.notaTri, 0) / s.simulados.length;
    return Math.round(avg);
  }
  if (s.totalAnswered === 0) return 0;
  return Math.round(400 + taxaAcerto(s) * 400);
}

export function dominioTri(s: UserStats): number {
  if (s.totalAnswered < 5) return 0;
  return Math.round(taxaAcerto(s) * 100) / 100;
}

export function last14Days(s: UserStats): { dia: string; acertos: number }[] {
  const out: { dia: string; acertos: number }[] = [];
  for (let i = 13; i >= 0; i--) {
    const d = new Date();
    d.setDate(d.getDate() - i);
    const key = d.toISOString().slice(0, 10);
    const entry = s.daily.find((x) => x.date === key);
    out.push({ dia: `D${14 - i}`, acertos: entry?.correct ?? 0 });
  }
  return out;
}

export function materiasResumo(s: UserStats) {
  return Object.entries(s.perMateria).map(([materia, m]) => ({
    materia,
    acertos: m.correct,
    erros: m.answered - m.correct,
    timeSec: m.timeSec,
    taxa: m.answered ? m.correct / m.answered : 0,
  }));
}
