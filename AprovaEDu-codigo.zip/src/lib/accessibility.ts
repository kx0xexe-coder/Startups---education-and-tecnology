import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/components/AuthProvider";

export type Neurotype =
  | "tdah"
  | "tea"
  | "dislexia"
  | "discalculia"
  | "ansiedade"
  | "outro";

export interface AccessibilityProfile {
  /** Whether the user has an approved laudo (either marked approved, or pending past the analysis period). */
  active: boolean;
  /** Inferred neurodivergence type from CID + free-text. */
  neurotype: Neurotype | null;
  /** Friendly label for UI. */
  label: string;
  /** Time multiplier for timed activities (simulados). 1 = normal. */
  timeMultiplier: number;
  /** Use OpenDyslexic-style spacing + serif fallback. */
  dyslexiaFont: boolean;
  /** Reduce animation intensity, softer transitions. */
  calmMode: boolean;
  /** Emphasize focus outlines & limit distractions. */
  focusMode: boolean;
  /** Show step-by-step math hints. */
  mathScaffold: boolean;
  /** Adaptations the user will see in the UI. */
  adaptations: string[];
  /** ISO string when analysis ends (for pending laudos). */
  analysisEndsAt: string | null;
  /** Raw status from DB. */
  status: "pending" | "approved" | "rejected" | "none";
}

const EMPTY: AccessibilityProfile = {
  active: false,
  neurotype: null,
  label: "Padrão",
  timeMultiplier: 1,
  dyslexiaFont: false,
  calmMode: false,
  focusMode: false,
  mathScaffold: false,
  adaptations: [],
  analysisEndsAt: null,
  status: "none",
};

/** 48h analysis window — after this, a pending laudo auto-activates personalization. */
const ANALYSIS_MS = 48 * 60 * 60 * 1000;

export function inferNeurotype(cid: string | null | undefined): Neurotype | null {
  if (!cid) return null;
  const c = cid.toUpperCase().replace(/\s+/g, "");
  if (c.startsWith("F90")) return "tdah";
  if (c.startsWith("F84")) return "tea";
  if (c.startsWith("F81.0") || c === "F810") return "dislexia";
  if (c.startsWith("F81.2") || c === "F812") return "discalculia";
  if (c.startsWith("F81")) return "dislexia";
  if (c.startsWith("F41") || c.startsWith("F40")) return "ansiedade";
  return "outro";
}

function buildProfile(
  neurotype: Neurotype | null,
  status: AccessibilityProfile["status"],
  analysisEndsAt: string | null,
): AccessibilityProfile {
  if (!neurotype || status === "rejected" || status === "none") {
    return { ...EMPTY, status, analysisEndsAt };
  }
  const active = status === "approved";
  const base: AccessibilityProfile = {
    ...EMPTY,
    status,
    analysisEndsAt,
    active,
    neurotype,
  };
  if (!active) return base;

  switch (neurotype) {
    case "tdah":
      return {
        ...base,
        label: "TDAH",
        timeMultiplier: 1.25,
        focusMode: true,
        calmMode: true,
        adaptations: [
          "+25% de tempo nos simulados",
          "Modo foco: menos distrações na interface",
          "Pausas sugeridas a cada 25 min (Pomodoro)",
          "Conteúdo dividido em blocos curtos",
        ],
      };
    case "tea":
      return {
        ...base,
        label: "TEA",
        timeMultiplier: 1.2,
        calmMode: true,
        focusMode: true,
        adaptations: [
          "+20% de tempo nos simulados",
          "Interface previsível, sem animações intensas",
          "Roteiro de estudo estruturado e sequencial",
          "Instruções diretas, sem linguagem figurada",
        ],
      };
    case "dislexia":
      return {
        ...base,
        label: "Dislexia",
        timeMultiplier: 1.5,
        dyslexiaFont: true,
        adaptations: [
          "+50% de tempo nos simulados",
          "Fonte amigável e maior espaçamento entre letras",
          "Enunciados com leitura em áudio (em breve)",
          "Destaque visual de palavras-chave",
        ],
      };
    case "discalculia":
      return {
        ...base,
        label: "Discalculia",
        timeMultiplier: 1.5,
        mathScaffold: true,
        adaptations: [
          "+50% de tempo em questões de exatas",
          "Resolução passo a passo nos itens de matemática",
          "Calculadora liberada nos simulados",
          "Reforço visual com gráficos e diagramas",
        ],
      };
    case "ansiedade":
      return {
        ...base,
        label: "Ansiedade / TAG",
        timeMultiplier: 1.2,
        calmMode: true,
        adaptations: [
          "+20% de tempo nos simulados",
          "Modo calmo: animações suaves e tons reduzidos",
          "Lembretes de respiração entre sessões",
          "Sem ranking público forçado",
        ],
      };
    default:
      return {
        ...base,
        label: "Personalizado",
        timeMultiplier: 1.25,
        calmMode: true,
        adaptations: [
          "+25% de tempo nos simulados",
          "Ajustes individuais conforme laudo",
        ],
      };
  }
}

export function useAccessibilityProfile(): {
  profile: AccessibilityProfile;
  loading: boolean;
  refresh: () => void;
} {
  const { user } = useAuth();
  const [profile, setProfile] = useState<AccessibilityProfile>(EMPTY);
  const [loading, setLoading] = useState(true);
  const [tick, setTick] = useState(0);

  useEffect(() => {
    let cancelled = false;
    if (!user) {
      setProfile(EMPTY);
      setLoading(false);
      return;
    }
    setLoading(true);
    (async () => {
      const { data } = await supabase
        .from("medical_reports")
        .select("status, cid, created_at")
        .order("created_at", { ascending: false })
        .limit(5);
      if (cancelled) return;
      const rows = data ?? [];
      // Prefer approved; else a pending row whose analysis window has passed.
      const approved = rows.find((r) => r.status === "approved");
      let status: AccessibilityProfile["status"] = "none";
      let cid: string | null = null;
      let analysisEndsAt: string | null = null;
      if (approved) {
        status = "approved";
        cid = approved.cid;
      } else {
        const pending = rows.find((r) => r.status === "pending");
        if (pending) {
          const created = new Date(pending.created_at).getTime();
          const endsAt = new Date(created + ANALYSIS_MS);
          analysisEndsAt = endsAt.toISOString();
          cid = pending.cid;
          status = Date.now() >= created + ANALYSIS_MS ? "approved" : "pending";
        } else if (rows.some((r) => r.status === "rejected")) {
          status = "rejected";
        }
      }
      setProfile(buildProfile(inferNeurotype(cid), status, analysisEndsAt));
      setLoading(false);
    })();
    return () => {
      cancelled = true;
    };
  }, [user?.id, tick]);

  return { profile, loading, refresh: () => setTick((t) => t + 1) };
}
