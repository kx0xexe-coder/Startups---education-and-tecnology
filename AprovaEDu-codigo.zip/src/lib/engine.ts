import { Difficulty, Question, dificuldadeOrdem } from "@/data/questions";

/**
 * Algoritmo Adaptativo
 * Regra: 3 acertos seguidos no nível atual → sobe um nível.
 * 1 erro → desce um nível para reforço da base no mesmo assunto.
 */
export function nextDifficulty(
  current: Difficulty,
  correctStreak: number,
  lastWrong: boolean
): Difficulty {
  const idx = dificuldadeOrdem.indexOf(current);
  if (lastWrong) return dificuldadeOrdem[Math.max(0, idx - 1)];
  if (correctStreak >= 3) return dificuldadeOrdem[Math.min(dificuldadeOrdem.length - 1, idx + 1)];
  return current;
}

/**
 * TRI simplificado — pondera o valor da questão pela taxa de acerto global.
 * Quanto menor a taxa de acerto, maior o peso (0..1000 escala).
 */
export function triScore(question: Question, acertou: boolean): number {
  if (!acertou) return 0;
  const dificuldadeBase = 1 - question.taxaAcerto;
  const pesoNivel = { facil: 0.5, media: 1, dificil: 1.5, absurdo: 2 }[question.dificuldade];
  return Math.round(dificuldadeBase * pesoNivel * 500);
}

/**
 * XP logarítmico para nivelamento.
 * f(level) = floor(100 * log2(level + 1))
 */
export function xpToLevel(totalXp: number): { level: number; nextLevelXp: number; progress: number } {
  let level = 1;
  while (xpForLevel(level + 1) <= totalXp) level++;
  const current = xpForLevel(level);
  const next = xpForLevel(level + 1);
  return {
    level,
    nextLevelXp: next,
    progress: (totalXp - current) / (next - current),
  };
}

function xpForLevel(level: number): number {
  return Math.floor(150 * Math.log2(level + 1) * level);
}

/**
 * Filtro por exclusão — usuário define o que NÃO quer ver.
 */
export interface ExclusionFilter {
  excludedMaterias: string[];
  excludedDifficulties: Difficulty[];
  excludedBancas: string[];
  excludedTags: string[];
}

export function applyExclusion(qs: Question[], filter: ExclusionFilter): Question[] {
  return qs.filter(
    (q) =>
      !filter.excludedMaterias.includes(q.materia) &&
      !filter.excludedDifficulties.includes(q.dificuldade) &&
      !filter.excludedBancas.includes(q.banca) &&
      !filter.excludedTags.some((t) => q.tags.includes(t))
  );
}
