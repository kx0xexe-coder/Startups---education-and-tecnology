import { createRoot } from "react-dom/client";
import App from "./App.tsx";
import "./index.css";
import { registerAppServiceWorker } from "./pwa/register";

document.documentElement.classList.add("dark");

createRoot(document.getElementById("root")!).render(<App />);

registerAppServiceWorker();
