import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider } from "@/components/AuthProvider";
import { AccessibilityProvider } from "@/components/AccessibilityProvider";
import ProtectedRoute from "@/components/ProtectedRoute";
import Landing from "./pages/Landing.tsx";
import Auth from "./pages/Auth.tsx";
import AppLayout from "./components/AppLayout.tsx";
import Dashboard from "./pages/Dashboard.tsx";
import Questoes from "./pages/Questoes.tsx";
import Simulado from "./pages/Simulado.tsx";
import Ranking from "./pages/Ranking.tsx";
import Analytics from "./pages/Analytics.tsx";
import Acessibilidade from "./pages/Acessibilidade.tsx";
import Perfil from "./pages/Perfil.tsx";
import Biblioteca from "./pages/Biblioteca.tsx";
import Suporte from "./pages/Suporte.tsx";
import Feedbacks from "./pages/Feedbacks.tsx";
import NotFound from "./pages/NotFound.tsx";
import Chat from "./pages/Chat.tsx";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <AuthProvider>
          <AccessibilityProvider>
            <Routes>
              <Route path="/" element={<Landing />} />
              <Route path="/auth" element={<Auth />} />
              <Route
                element={
                  <ProtectedRoute>
                    <AppLayout />
                  </ProtectedRoute>
                }
              >
                <Route path="/dashboard" element={<Dashboard />} />
                <Route path="/questoes" element={<Questoes />} />
                <Route path="/simulado" element={<Simulado />} />
                <Route path="/ranking" element={<Ranking />} />
                <Route path="/chat" element={<Chat />} />
                <Route path="/analytics" element={<Analytics />} />
                <Route path="/biblioteca" element={<Biblioteca />} />
                <Route path="/suporte" element={<Suporte />} />
                <Route path="/feedbacks" element={<Feedbacks />} />
                <Route path="/acessibilidade" element={<Acessibilidade />} />
                <Route path="/perfil" element={<Perfil />} />
              </Route>
              <Route path="*" element={<NotFound />} />
            </Routes>
          </AccessibilityProvider>
        </AuthProvider>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
