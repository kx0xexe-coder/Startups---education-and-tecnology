export type Difficulty = "facil" | "media" | "dificil" | "absurdo";

export interface Question {
  id: string;
  enunciado: string;
  opcoes: { id: string; texto: string }[];
  corretaId: string;
  comentario: string;
  tags: string[];
  materia: string;
  dificuldade: Difficulty;
  ano: number;
  banca: string;
  taxaAcerto: number; // 0..1 — usada para TRI
}

export const questions: Question[] = [
  {
    id: "q1",
    materia: "Matemática",
    enunciado:
      "Um reservatório em forma de cilindro circular reto possui raio da base igual a 2 m e altura 5 m. Qual é o volume aproximado, em litros, desse reservatório? (Use π ≈ 3,14)",
    opcoes: [
      { id: "a", texto: "31.400 litros" },
      { id: "b", texto: "62.800 litros" },
      { id: "c", texto: "15.700 litros" },
      { id: "d", texto: "6.280 litros" },
      { id: "e", texto: "20.000 litros" },
    ],
    corretaId: "b",
    comentario:
      "V = π·r²·h = 3,14 · 4 · 5 = 62,8 m³. Como 1 m³ = 1000 L, temos 62.800 litros.",
    tags: ["geometria", "volumes", "cilindro"],
    dificuldade: "media",
    ano: 2022,
    banca: "ENEM",
    taxaAcerto: 0.54,
  },
  {
    id: "q2",
    materia: "Linguagens",
    enunciado:
      "No texto literário, a função poética da linguagem se caracteriza principalmente por:",
    opcoes: [
      { id: "a", texto: "Centrar-se no destinatário, buscando convencê-lo." },
      { id: "b", texto: "Centrar-se na mensagem, valorizando a forma." },
      { id: "c", texto: "Centrar-se no canal de comunicação." },
      { id: "d", texto: "Centrar-se no emissor e suas emoções." },
      { id: "e", texto: "Centrar-se no código linguístico." },
    ],
    corretaId: "b",
    comentario:
      "A função poética (Jakobson) prioriza a mensagem em si — escolhas formais, ritmo, sonoridade.",
    tags: ["funções da linguagem", "literatura"],
    dificuldade: "facil",
    ano: 2021,
    banca: "ENEM",
    taxaAcerto: 0.71,
  },
  {
    id: "q3",
    materia: "Ciências da Natureza",
    enunciado:
      "Uma amostra de gás ideal sofre transformação isotérmica. Se o volume é reduzido à metade, a pressão:",
    opcoes: [
      { id: "a", texto: "Reduz à metade" },
      { id: "b", texto: "Permanece constante" },
      { id: "c", texto: "Dobra" },
      { id: "d", texto: "Quadruplica" },
      { id: "e", texto: "Reduz a um quarto" },
    ],
    corretaId: "c",
    comentario: "Lei de Boyle: P·V = constante a T fixa. V/2 ⇒ P·2.",
    tags: ["física", "gases", "termodinâmica"],
    dificuldade: "media",
    ano: 2023,
    banca: "ENEM",
    taxaAcerto: 0.48,
  },
  {
    id: "q4",
    materia: "Humanas",
    enunciado:
      "A Revolução Industrial inglesa (séc. XVIII) tem como uma de suas causas estruturais:",
    opcoes: [
      { id: "a", texto: "A expansão do feudalismo." },
      { id: "b", texto: "Os cercamentos e a formação de mão de obra livre urbana." },
      { id: "c", texto: "A descoberta do petróleo como matriz energética." },
      { id: "d", texto: "A unificação alemã." },
      { id: "e", texto: "A Revolução Russa." },
    ],
    corretaId: "b",
    comentario:
      "Os enclosures expulsaram camponeses para as cidades, formando o proletariado fabril.",
    tags: ["história", "revolução industrial"],
    dificuldade: "facil",
    ano: 2020,
    banca: "ENEM",
    taxaAcerto: 0.66,
  },
  {
    id: "q5",
    materia: "Matemática",
    enunciado:
      "Considere a função f(x) = log₂(x − 3). Qual é o domínio de f?",
    opcoes: [
      { id: "a", texto: "x > 0" },
      { id: "b", texto: "x ≥ 3" },
      { id: "c", texto: "x > 3" },
      { id: "d", texto: "x ≠ 3" },
      { id: "e", texto: "x ∈ ℝ" },
    ],
    corretaId: "c",
    comentario:
      "Logaritmando precisa ser estritamente positivo: x − 3 > 0 ⇒ x > 3.",
    tags: ["funções", "logaritmo"],
    dificuldade: "dificil",
    ano: 2023,
    banca: "FUVEST",
    taxaAcerto: 0.32,
  },
  {
    id: "q6",
    materia: "Linguagens",
    enunciado:
      "Em \"Ele chegou cedo, embora estivesse cansado\", a oração destacada classifica-se como:",
    opcoes: [
      { id: "a", texto: "Adverbial causal" },
      { id: "b", texto: "Adverbial concessiva" },
      { id: "c", texto: "Substantiva subjetiva" },
      { id: "d", texto: "Adjetiva restritiva" },
      { id: "e", texto: "Adverbial consecutiva" },
    ],
    corretaId: "b",
    comentario:
      "\"Embora\" introduz uma concessão — ideia contrária que não impede a principal.",
    tags: ["sintaxe", "orações subordinadas"],
    dificuldade: "media",
    ano: 2022,
    banca: "ENEM",
    taxaAcerto: 0.51,
  },
  {
    id: "q7",
    materia: "Matemática",
    enunciado:
      "Quantos números de 4 algarismos distintos podem ser formados usando apenas os dígitos 1, 2, 3, 4, 5 e 6?",
    opcoes: [
      { id: "a", texto: "120" },
      { id: "b", texto: "360" },
      { id: "c", texto: "720" },
      { id: "d", texto: "1.296" },
      { id: "e", texto: "240" },
    ],
    corretaId: "b",
    comentario: "Arranjo A(6,4) = 6·5·4·3 = 360.",
    tags: ["análise combinatória"],
    dificuldade: "absurdo",
    ano: 2024,
    banca: "ITA",
    taxaAcerto: 0.18,
  },
  {
    id: "q8",
    materia: "Ciências da Natureza",
    enunciado:
      "A fotossíntese realizada pelas plantas converte energia luminosa em energia química, produzindo:",
    opcoes: [
      { id: "a", texto: "Glicose e oxigênio" },
      { id: "b", texto: "Gás carbônico e água" },
      { id: "c", texto: "Amido e nitrogênio" },
      { id: "d", texto: "ATP e gás carbônico" },
      { id: "e", texto: "Apenas oxigênio" },
    ],
    corretaId: "a",
    comentario:
      "6 CO₂ + 6 H₂O + luz → C₆H₁₂O₆ (glicose) + 6 O₂.",
    tags: ["biologia", "fotossíntese"],
    dificuldade: "facil",
    ano: 2021,
    banca: "ENEM",
    taxaAcerto: 0.78,
  },
  {
    id: "q9",
    materia: "Humanas",
    enunciado:
      "O Movimento das Diretas Já, ocorrido no Brasil em 1984, tinha como principal reivindicação:",
    opcoes: [
      { id: "a", texto: "A realização de eleições diretas para presidente da República." },
      { id: "b", texto: "A redemocratização dos sindicatos no campo e na cidade." },
      { id: "c", texto: "A anistia aos presos políticos do regime militar." },
      { id: "d", texto: "A elaboração de uma nova Constituição Federal." },
      { id: "e", texto: "A extinção do bipartidarismo (ARENA x MDB)." },
    ],
    corretaId: "a",
    comentario:
      "O movimento pedia eleições diretas para presidente, o que resultou na Emenda Dante de Oliveira e, posteriormente, na eleição de Tancredo Neves pela colégio eleitoral.",
    tags: ["história", "ditadura militar", "redemocratização"],
    dificuldade: "media",
    ano: 2022,
    banca: "ENEM",
    taxaAcerto: 0.55,
  },
  {
    id: "q10",
    materia: "Linguagens",
    enunciado:
      "Na frase 'A água, correria pela encosta', o termo destacado funciona como:",
    opcoes: [
      { id: "a", texto: "Sujeito simples" },
      { id: "b", texto: "Predicado verbal" },
      { id: "c", texto: "Complemento nominal" },
      { id: "d", texto: "Objeto direto preposicionado" },
      { id: "e", texto: "Adjunto adnominal" },
    ],
    corretaId: "a",
    comentario:
      "'A água' é o ser sobre o qual se declara algo; é o sujeito simples da oração.",
    tags: ["análise sintática", "sujeito"],
    dificuldade: "facil",
    ano: 2023,
    banca: "ENEM",
    taxaAcerto: 0.68,
  },
  {
    id: "q11",
    materia: "Matemática",
    enunciado:
      "Uma loja oferece um desconto de 20% sobre o preço de uma camisa. Após o desconto, um cliente ainda paga o ICMS de 12% sobre o valor pago. Se o preço original da camisa é R$ 80,00, qual o valor final pago pelo cliente?",
    opcoes: [
      { id: "a", texto: "R$ 56,32" },
      { id: "b", texto: "R$ 64,00" },
      { id: "c", texto: "R$ 70,40" },
      { id: "d", texto: "R$ 71,68" },
      { id: "e", texto: "R$ 89,60" },
    ],
    corretaId: "d",
    comentario:
      "Desconto de 20%: 80 × 0,80 = 64. ICMS de 12% sobre 64: 64 × 1,12 = 71,68.",
    tags: ["porcentagem", "matemática financeira"],
    dificuldade: "media",
    ano: 2023,
    banca: "ENEM",
    taxaAcerto: 0.42,
  },
  {
    id: "q12",
    materia: "Ciências da Natureza",
    enunciado:
      "A água sofre constantes mudanças de estado físico no ciclo hidrológico. No processo de condensação, ocorre:",
    opcoes: [
      { id: "a", texto: "Liberação de energia térmica pelo vapor de água." },
      { id: "b", texto: "Absorção de energia térmica pela água líquida." },
      { id: "c", texto: "Passagem direta do sólido para o gasoso." },
      { id: "d", texto: "Formação de cristais de gelo a partir da névoa." },
      { id: "e", texto: "Expansão térmica dos oceanos." },
    ],
    corretaId: "a",
    comentario:
      "A condensação é a passagem do estado gasoso para o líquido; como é uma transformação exotérmica, libera calor para o ambiente.",
    tags: ["química", "mudanças de estado físico"],
    dificuldade: "facil",
    ano: 2022,
    banca: "ENEM",
    taxaAcerto: 0.60,
  },
  {
    id: "q13",
    materia: "Humanas",
    enunciado:
      "A Carta de Caminha, escrita por Pero Vaz de Caminha em 1500, é considerada um documento histórico importante porque:",
    opcoes: [
      { id: "a", texto: "Registra a primeira visão europeia sobre os povos indígenas do Brasil." },
      { id: "b", texto: "Estabelece as fronteiras do território brasileiro segundo o Tratado de Tordesilhas." },
      { id: "c", texto: "Fundamenta a doutrina da ocupação da América pelos portugueses." },
      { id: "d", texto: "Comprova a existência de ouro e prata no litoral brasileiro." },
      { id: "e", texto: "Critica a violência da colonização portuguesa nas terras descobertas." },
    ],
    corretaId: "a",
    comentario:
      "Caminha descreveu com detalhes os costumes e a aparência dos indígenas, constituindo a primeira narrativa europeia sobre o Brasil.",
    tags: ["história", "descobrimento", "carta de caminha"],
    dificuldade: "facil",
    ano: 2021,
    banca: "ENEM",
    taxaAcerto: 0.74,
  },
  {
    id: "q14",
    materia: "Linguagens",
    enunciado:
      "No trecho 'Muitos alunos reclamam da dificuldade, mas poucos realmente se esforçam para melhorar', o uso da vírgula antes de 'mas' tem a função de:",
    opcoes: [
      { id: "a", texto: "Separar orações coordenadas assindéticas." },
      { id: "b", texto: "Isolar um aposto explicativo." },
      { id: "c", texto: "Indicar uma pausa antes de uma oração coordenada adversativa." },
      { id: "d", texto: "Delimitar uma oração subordinada substantiva." },
      { id: "e", texto: "Evitar ambiguidade entre termos da mesma função." },
    ],
    corretaId: "c",
    comentario:
      "'Mas' é uma conjunção coordenativa adversativa; a vírgula antecede-a para marcar a pausa entre as orações coordenadas.",
    tags: ["pontuação", "orações coordenadas"],
    dificuldade: "media",
    ano: 2024,
    banca: "ENEM",
    taxaAcerto: 0.50,
  },
  {
    id: "q15",
    materia: "Matemática",
    enunciado:
      "Uma empresa tem 120 funcionários. Sabe-se que 70% são mulheres e, entre as mulheres, 40% têm curso superior. Quantas mulheres da empresa possuem curso superior?",
    opcoes: [
      { id: "a", texto: "28" },
      { id: "b", texto: "34" },
      { id: "c", texto: "42" },
      { id: "d", texto: "48" },
      { id: "e", texto: "56" },
    ],
    corretaId: "b",
    comentario:
      "Mulheres: 120 × 0,70 = 84. Com curso superior: 84 × 0,40 = 33,6 → arredondando, 34.",
    tags: ["porcentagem", "estatística básica"],
    dificuldade: "facil",
    ano: 2022,
    banca: "ENEM",
    taxaAcerto: 0.65,
  },
];

export const materias = [
  "Matemática",
  "Linguagens",
  "Ciências da Natureza",
  "Humanas",
] as const;

export const bancas = ["ENEM", "FUVEST", "ITA", "CESPE", "FGV", "VUNESP"] as const;

export const dificuldadeLabel: Record<Difficulty, string> = {
  facil: "Fácil",
  media: "Média",
  dificil: "Difícil",
  absurdo: "Absurdo",
};

export const dificuldadeOrdem: Difficulty[] = ["facil", "media", "dificil", "absurdo"];
