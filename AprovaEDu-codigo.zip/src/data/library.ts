import { questions } from "./questions";

export interface MaterialTopic {
  id: string;
  materia: string;
  titulo: string;
  resumo: string;
  conteudo: string;
  tags: string[];
  questoesRelacionadas: string[]; // question ids
}

export const library: MaterialTopic[] = [
  // ============================================================
  // MATEMÁTICA
  // ============================================================
  {
    id: "mat-cilindro",
    materia: "Matemática",
    titulo: "Volume de cilindros e sólidos",
    resumo: "Como calcular volumes usando V = π·r²·h e converter unidades.",
    conteudo:
      "O volume de um cilindro circular reto é dado por V = π·r²·h, onde r é o raio da base e h a altura.\n\n" +
      "Outras fórmulas importantes:\n" +
      "• Esfera: V = (4/3)·π·r³\n" +
      "• Cone: V = (1/3)·π·r²·h\n" +
      "• Prisma: V = Área da base · altura\n" +
      "• Pirâmide: V = (1/3)·Área da base · altura\n\n" +
      "Conversões essenciais: 1 m³ = 1000 L = 1.000.000 cm³; 1 dm³ = 1 L. " +
      "Sempre confira as unidades antes de aplicar a fórmula. Erros mais comuns: misturar cm com m e esquecer de elevar o raio ao quadrado.\n\n" +
      "Exemplo: cilindro de r = 2 m e h = 5 m → V = 3,14·4·5 = 62,8 m³ = 62.800 L.",
    tags: ["geometria", "volumes", "cilindro"],
    questoesRelacionadas: ["q1"],
  },
  {
    id: "mat-areas",
    materia: "Matemática",
    titulo: "Áreas de figuras planas",
    resumo: "Quadrado, retângulo, triângulo, círculo, trapézio e losango.",
    conteudo:
      "Quadrado: A = l². Retângulo: A = b·h. Triângulo: A = (b·h)/2. " +
      "Triângulo equilátero: A = (l²·√3)/4. Trapézio: A = ((B + b)·h)/2. " +
      "Losango: A = (D·d)/2. Círculo: A = π·r². Setor circular: A = (θ·π·r²)/360°.\n\n" +
      "Lei dos senos para área de qualquer triângulo: A = (1/2)·a·b·sen(C). " +
      "Fórmula de Herão: A = √[s(s−a)(s−b)(s−c)], com s = (a+b+c)/2.",
    tags: ["geometria", "áreas"],
    questoesRelacionadas: [],
  },
  {
    id: "mat-log",
    materia: "Matemática",
    titulo: "Funções logarítmicas — domínio e propriedades",
    resumo: "Condições de existência e principais propriedades dos logaritmos.",
    conteudo:
      "Para log_b(x) existir é preciso que x > 0, b > 0 e b ≠ 1.\n\n" +
      "Propriedades fundamentais:\n" +
      "• log(a·b) = log(a) + log(b)\n" +
      "• log(a/b) = log(a) − log(b)\n" +
      "• log(aⁿ) = n·log(a)\n" +
      "• Mudança de base: log_b(a) = log(a)/log(b)\n" +
      "• log_b(1) = 0 e log_b(b) = 1\n\n" +
      "Exemplo: f(x) = log₂(x − 3) → x − 3 > 0 ⇒ x > 3.",
    tags: ["funções", "logaritmo"],
    questoesRelacionadas: ["q5"],
  },
  {
    id: "mat-exponencial",
    materia: "Matemática",
    titulo: "Funções exponenciais",
    resumo: "Crescimento e decaimento, equações exponenciais.",
    conteudo:
      "Forma geral: f(x) = a·bˣ, com b > 0 e b ≠ 1.\n" +
      "• Se b > 1: função crescente (crescimento exponencial).\n" +
      "• Se 0 < b < 1: decrescente (decaimento).\n\n" +
      "Para resolver equações exponenciais, iguale as bases: 2ˣ = 8 ⇒ 2ˣ = 2³ ⇒ x = 3. " +
      "Quando não é possível, aplique logaritmo dos dois lados.\n\n" +
      "Aplicações: juros compostos, crescimento populacional, meia-vida radioativa (N = N₀·(1/2)^(t/T)).",
    tags: ["funções", "exponencial"],
    questoesRelacionadas: [],
  },
  {
    id: "mat-combin",
    materia: "Matemática",
    titulo: "Análise combinatória — arranjos e permutações",
    resumo: "Quando usar arranjo, combinação e permutação.",
    conteudo:
      "ARRANJO A(n,p) = n!/(n−p)!: agrupamentos onde a ORDEM importa.\n" +
      "COMBINAÇÃO C(n,p) = n!/(p!·(n−p)!): a ordem NÃO importa.\n" +
      "PERMUTAÇÃO P(n) = n!: ordena todos os n elementos.\n" +
      "Permutação com repetição: P(n; a,b,c) = n!/(a!·b!·c!).\n\n" +
      "Princípio Fundamental da Contagem: se um evento tem m formas e outro n formas, juntos têm m·n possibilidades.\n\n" +
      "Exemplo: números de 4 dígitos distintos com 6 algarismos = A(6,4) = 6·5·4·3 = 360.",
    tags: ["análise combinatória"],
    questoesRelacionadas: ["q7"],
  },
  {
    id: "mat-probabilidade",
    materia: "Matemática",
    titulo: "Probabilidade — eventos e regras",
    resumo: "Cálculo clássico, união, intersecção e probabilidade condicional.",
    conteudo:
      "P(A) = casos favoráveis / casos possíveis (espaço amostral equiprovável).\n\n" +
      "• União: P(A ∪ B) = P(A) + P(B) − P(A ∩ B)\n" +
      "• Eventos mutuamente exclusivos: P(A ∩ B) = 0\n" +
      "• Eventos independentes: P(A ∩ B) = P(A)·P(B)\n" +
      "• Condicional: P(A|B) = P(A ∩ B)/P(B)\n" +
      "• Complementar: P(Aᶜ) = 1 − P(A)\n\n" +
      "No ENEM aparece muito em jogos de azar, sorteios e contextos de saúde (testes diagnósticos).",
    tags: ["probabilidade", "estatística"],
    questoesRelacionadas: [],
  },
  {
    id: "mat-funcoes",
    materia: "Matemática",
    titulo: "Funções de 1º e 2º grau",
    resumo: "Forma geral, raízes, vértice e gráficos.",
    conteudo:
      "Função afim: f(x) = ax + b — gráfico é uma reta; a é o coeficiente angular e b o linear. " +
      "a > 0 → crescente; a < 0 → decrescente.\n\n" +
      "Função quadrática: f(x) = ax² + bx + c — parábola.\n" +
      "• Raízes por Bhaskara: x = (−b ± √Δ)/2a, com Δ = b² − 4ac.\n" +
      "• Δ > 0: duas raízes reais; Δ = 0: uma; Δ < 0: nenhuma.\n" +
      "• Vértice: xv = −b/(2a), yv = −Δ/(4a).\n" +
      "• Concavidade: para cima se a > 0; para baixo se a < 0.\n" +
      "• Soma das raízes: −b/a; produto: c/a.",
    tags: ["funções", "álgebra"],
    questoesRelacionadas: [],
  },
  {
    id: "mat-trigonometria",
    materia: "Matemática",
    titulo: "Trigonometria no triângulo retângulo",
    resumo: "Seno, cosseno, tangente e relações fundamentais.",
    conteudo:
      "Em um triângulo retângulo:\n" +
      "• sen θ = cateto oposto / hipotenusa\n" +
      "• cos θ = cateto adjacente / hipotenusa\n" +
      "• tg θ = oposto / adjacente = sen/cos\n\n" +
      "Relação fundamental: sen²θ + cos²θ = 1.\n\n" +
      "Valores notáveis:\n" +
      "• sen 30° = 1/2; sen 45° = √2/2; sen 60° = √3/2\n" +
      "• cos 30° = √3/2; cos 45° = √2/2; cos 60° = 1/2\n" +
      "• tg 30° = √3/3; tg 45° = 1; tg 60° = √3\n\n" +
      "Lei dos senos: a/sen A = b/sen B = c/sen C = 2R.\n" +
      "Lei dos cossenos: a² = b² + c² − 2bc·cos A.",
    tags: ["trigonometria", "geometria"],
    questoesRelacionadas: [],
  },
  {
    id: "mat-porcentagem",
    materia: "Matemática",
    titulo: "Porcentagem e juros",
    resumo: "Aumentos, descontos, juros simples e compostos.",
    conteudo:
      "Aumento de x%: multiplique por (1 + x/100).\n" +
      "Desconto: multiplique por (1 − x/100).\n" +
      "Aumentos sucessivos NÃO se somam: 10% + 10% = 21% (1,1 · 1,1 = 1,21).\n\n" +
      "Juros simples: M = C·(1 + i·t). Juros incidem só sobre o capital inicial.\n" +
      "Juros compostos: M = C·(1 + i)ᵗ. Juros sobre juros.\n\n" +
      "Onde i é a taxa por período (decimal) e t o número de períodos. Sempre alinhe a unidade de tempo da taxa com t.",
    tags: ["matemática financeira", "porcentagem"],
    questoesRelacionadas: [],
  },
  {
    id: "mat-pa-pg",
    materia: "Matemática",
    titulo: "Progressões aritméticas e geométricas",
    resumo: "Termo geral, soma dos termos e identificação.",
    conteudo:
      "PA — diferença constante (razão r):\n" +
      "• Termo geral: aₙ = a₁ + (n−1)·r\n" +
      "• Soma: Sₙ = (a₁ + aₙ)·n/2\n\n" +
      "PG — razão multiplicativa (q):\n" +
      "• Termo geral: aₙ = a₁·q^(n−1)\n" +
      "• Soma finita: Sₙ = a₁·(qⁿ − 1)/(q − 1), q ≠ 1\n" +
      "• Soma infinita (|q| < 1): S = a₁/(1 − q)\n\n" +
      "Exemplo PG: 2, 6, 18, 54... q = 3, a₅ = 2·3⁴ = 162.",
    tags: ["sequências", "progressões"],
    questoesRelacionadas: [],
  },
  {
    id: "mat-matrizes",
    materia: "Matemática",
    titulo: "Matrizes e sistemas lineares",
    resumo: "Operações com matrizes e resolução de sistemas.",
    conteudo:
      "Matriz m×n: m linhas por n colunas. Soma e subtração: mesma ordem, elemento a elemento. " +
      "Multiplicação A·B: número de colunas de A = número de linhas de B.\n\n" +
      "Determinante 2×2: ad − bc. Determinante 3×3: regra de Sarrus.\n\n" +
      "Sistemas lineares — classificação:\n" +
      "• Possível Determinado (SPD): uma única solução (det ≠ 0).\n" +
      "• Possível Indeterminado (SPI): infinitas soluções.\n" +
      "• Impossível (SI): sem solução.\n" +
      "Métodos: substituição, escalonamento (Gauss) e regra de Cramer.",
    tags: ["matrizes", "sistemas lineares"],
    questoesRelacionadas: [],
  },
  {
    id: "mat-estatistica",
    materia: "Matemática",
    titulo: "Estatística — média, mediana e moda",
    resumo: "Medidas de tendência central e dispersão.",
    conteudo:
      "MÉDIA aritmética: soma dos valores / número de valores.\n" +
      "MÉDIA ponderada: Σ(xᵢ·pᵢ)/Σpᵢ.\n" +
      "MEDIANA: valor central dos dados ORDENADOS. Se n é par, média dos dois centrais.\n" +
      "MODA: valor que mais se repete (pode haver mais de uma).\n\n" +
      "Dispersão:\n" +
      "• Amplitude = máximo − mínimo\n" +
      "• Variância = média dos quadrados dos desvios em relação à média\n" +
      "• Desvio padrão = √variância\n\n" +
      "Quando há valores extremos (outliers), a mediana representa melhor o conjunto que a média.",
    tags: ["estatística"],
    questoesRelacionadas: [],
  },
  {
    id: "mat-geometria-analitica",
    materia: "Matemática",
    titulo: "Geometria analítica — reta e circunferência",
    resumo: "Distância, equações da reta e da circunferência no plano.",
    conteudo:
      "Distância entre pontos: d = √[(x₂−x₁)² + (y₂−y₁)²].\n" +
      "Ponto médio: M = ((x₁+x₂)/2, (y₁+y₂)/2).\n\n" +
      "Equação da reta:\n" +
      "• Reduzida: y = mx + n (m = coeficiente angular)\n" +
      "• Geral: ax + by + c = 0\n" +
      "• Retas paralelas: m₁ = m₂. Perpendiculares: m₁·m₂ = −1.\n\n" +
      "Circunferência de centro (a, b) e raio r: (x − a)² + (y − b)² = r².",
    tags: ["geometria analítica"],
    questoesRelacionadas: [],
  },

  // ============================================================
  // LINGUAGENS
  // ============================================================
  {
    id: "lin-funcoes",
    materia: "Linguagens",
    titulo: "Funções da linguagem (Jakobson)",
    resumo: "As 6 funções: referencial, emotiva, conativa, fática, metalinguística e poética.",
    conteudo:
      "Cada função enfatiza um elemento da comunicação:\n\n" +
      "• REFERENCIAL (contexto): informação objetiva — jornalismo, textos científicos.\n" +
      "• EMOTIVA / EXPRESSIVA (emissor): sentimentos, 1ª pessoa, interjeições.\n" +
      "• CONATIVA / APELATIVA (receptor): convencer, vocativo, imperativo — propaganda.\n" +
      "• FÁTICA (canal): testar/manter o contato — \"alô?\", \"né?\".\n" +
      "• METALINGUÍSTICA (código): a linguagem fala dela mesma — dicionários, gramáticas.\n" +
      "• POÉTICA (mensagem): forma, ritmo, sonoridade — literatura e publicidade criativa.\n\n" +
      "Um mesmo texto pode ter mais de uma função; a questão pede a PREDOMINANTE.",
    tags: ["funções da linguagem", "literatura"],
    questoesRelacionadas: ["q2"],
  },
  {
    id: "lin-sintaxe",
    materia: "Linguagens",
    titulo: "Orações subordinadas adverbiais",
    resumo: "Classificação pelas conjunções: causal, concessiva, condicional...",
    conteudo:
      "Tipos principais (e suas conjunções típicas):\n" +
      "• CAUSAL: porque, já que, visto que.\n" +
      "• CONSECUTIVA: tão... que, tanto... que.\n" +
      "• CONDICIONAL: se, caso, contanto que.\n" +
      "• CONCESSIVA: embora, ainda que, mesmo que (ideia contrária à principal).\n" +
      "• COMPARATIVA: como, do que.\n" +
      "• CONFORMATIVA: conforme, segundo.\n" +
      "• FINAL: para que, a fim de que.\n" +
      "• TEMPORAL: quando, enquanto, assim que.\n" +
      "• PROPORCIONAL: à medida que, à proporção que.",
    tags: ["sintaxe", "orações subordinadas"],
    questoesRelacionadas: ["q6"],
  },
  {
    id: "lin-figuras",
    materia: "Linguagens",
    titulo: "Figuras de linguagem",
    resumo: "Metáfora, metonímia, hipérbole, ironia e outras.",
    conteudo:
      "FIGURAS DE PALAVRAS:\n" +
      "• Metáfora: comparação implícita (\"seus olhos são estrelas\").\n" +
      "• Comparação: explícita, com conectivo (\"como\", \"feito\").\n" +
      "• Metonímia: parte pelo todo, autor pela obra (\"li Machado de Assis\").\n" +
      "• Catacrese: metáfora desgastada (\"pé da mesa\").\n" +
      "• Sinestesia: cruzamento de sentidos (\"cor quente\").\n\n" +
      "FIGURAS DE PENSAMENTO: hipérbole (exagero), ironia (oposto do que se diz), antítese (ideias opostas), paradoxo (contradição lógica), eufemismo (suavizar), prosopopeia (personificação).\n\n" +
      "FIGURAS DE SOM: aliteração (consoantes), assonância (vogais), onomatopeia (imitação de sons).",
    tags: ["figuras de linguagem", "literatura"],
    questoesRelacionadas: [],
  },
  {
    id: "lin-escolas",
    materia: "Linguagens",
    titulo: "Escolas literárias brasileiras",
    resumo: "Do Barroco ao Modernismo — características essenciais.",
    conteudo:
      "• BARROCO (séc. XVII): contraste, dualismo fé/pecado — Gregório de Matos, Pe. Antônio Vieira.\n" +
      "• ARCADISMO (XVIII): bucolismo, simplicidade, pseudônimos pastoris — Tomás A. Gonzaga.\n" +
      "• ROMANTISMO (XIX): subjetividade, nacionalismo, indianismo — José de Alencar, Gonçalves Dias, Castro Alves.\n" +
      "• REALISMO/NATURALISMO: crítica social, ciência, determinismo — Machado de Assis, Aluísio Azevedo.\n" +
      "• PARNASIANISMO: forma perfeita, arte pela arte — Olavo Bilac.\n" +
      "• SIMBOLISMO: musicalidade, mistério — Cruz e Sousa.\n" +
      "• PRÉ-MODERNISMO: Euclides da Cunha, Lima Barreto, Monteiro Lobato.\n" +
      "• MODERNISMO (1922): ruptura — Mário e Oswald de Andrade. 2ª fase: Drummond, Bandeira, Graciliano, Jorge Amado. 3ª fase: Clarice Lispector, Guimarães Rosa, João Cabral.",
    tags: ["literatura", "escolas literárias"],
    questoesRelacionadas: [],
  },
  {
    id: "lin-interpretacao",
    materia: "Linguagens",
    titulo: "Interpretação de texto — tese e argumentos",
    resumo: "Como identificar a ideia central e os recursos argumentativos.",
    conteudo:
      "TESE: posição defendida pelo autor — geralmente na introdução ou conclusão.\n" +
      "ARGUMENTOS: dados, exemplos, citações de autoridade, comparações, relações de causa/consequência.\n\n" +
      "Distinções essenciais:\n" +
      "• O que o texto AFIRMA (literal) × o que apenas SUGERE (inferência).\n" +
      "• Fato × opinião.\n" +
      "• Tema (assunto geral) × tese (ponto de vista).\n\n" +
      "Atenção a CONECTIVOS que marcam relações: \"porém/contudo\" (oposição), \"portanto/logo\" (conclusão), \"embora\" (concessão), \"porque\" (causa), \"além disso\" (adição).",
    tags: ["interpretação", "leitura"],
    questoesRelacionadas: [],
  },
  {
    id: "lin-concordancia",
    materia: "Linguagens",
    titulo: "Concordância verbal e nominal",
    resumo: "Regras essenciais de concordância na norma culta.",
    conteudo:
      "VERBAL — verbo concorda com o sujeito em número e pessoa.\n" +
      "• Sujeito composto antes do verbo → plural.\n" +
      "• Sujeito composto depois → pode concordar com o mais próximo.\n" +
      "• Verbo HAVER (= existir) é impessoal: fica no singular.\n" +
      "• FAZER indicando tempo é impessoal: \"Faz dois anos\".\n" +
      "• Expressões \"a maioria de\", \"grande parte de\" + plural: aceita verbo no singular ou plural.\n\n" +
      "NOMINAL — adjetivo concorda com o substantivo em gênero e número.\n" +
      "• \"Anexo\" e \"obrigado\" variam; \"em anexo\" e \"menos\" são invariáveis.\n" +
      "• \"Bastante\" como pronome adjetivo varia (bastantes alunos); como advérbio, não.",
    tags: ["gramática", "concordância"],
    questoesRelacionadas: [],
  },
  {
    id: "lin-regencia",
    materia: "Linguagens",
    titulo: "Regência verbal e crase",
    resumo: "Verbos com preposição e o uso correto do acento grave.",
    conteudo:
      "REGÊNCIA — alguns verbos exigem preposição:\n" +
      "• Assistir (=ver) a: \"Assisti AO filme\".\n" +
      "• Obedecer / desobedecer a.\n" +
      "• Implicar (= acarretar) é transitivo direto: \"Isso implica mudanças\".\n" +
      "• Preferir A a B (sem \"do que\").\n\n" +
      "CRASE — fusão da preposição \"a\" com o artigo \"a(s)\":\n" +
      "• Ocorre antes de palavra feminina que aceita artigo: \"Vou À escola\".\n" +
      "• NÃO ocorre antes de masculino, verbo ou pronomes pessoais: \"a cavalo\", \"a partir\", \"a ela\".\n" +
      "• Locuções femininas adverbiais sempre têm crase: à noite, às vezes, à tarde.\n" +
      "• Antes de nome de cidade, depende: \"Vou a Paris\" / \"Vou à Roma antiga\" (se vier qualificada).",
    tags: ["gramática", "regência", "crase"],
    questoesRelacionadas: [],
  },
  {
    id: "lin-generos",
    materia: "Linguagens",
    titulo: "Gêneros e tipos textuais",
    resumo: "Diferença entre gênero (forma social) e tipo (estrutura).",
    conteudo:
      "TIPOS TEXTUAIS (estrutura):\n" +
      "• Narrativo: enredo, personagens, tempo.\n" +
      "• Descritivo: caracterização de seres, lugares, objetos.\n" +
      "• Dissertativo-argumentativo: tese + argumentos.\n" +
      "• Expositivo: informa sem opinar.\n" +
      "• Injuntivo / Instrucional: orienta ações (receitas, manuais).\n\n" +
      "GÊNEROS TEXTUAIS (uso social): notícia, reportagem, crônica, conto, romance, e-mail, post, meme, charge, tirinha, editorial, artigo de opinião, poema, propaganda, bula, manual, currículo etc.\n\n" +
      "Um mesmo gênero pode misturar tipos (ex.: crônica narrativa com trechos descritivos).",
    tags: ["gêneros textuais", "tipologia"],
    questoesRelacionadas: [],
  },
  {
    id: "lin-variacao",
    materia: "Linguagens",
    titulo: "Variação linguística",
    resumo: "Variações regional, social, histórica e situacional.",
    conteudo:
      "Toda língua varia. Tipos de variação:\n" +
      "• DIATÓPICA (regional): \"mandioca/aipim/macaxeira\".\n" +
      "• DIASTRÁTICA (social): grupo socioeconômico, profissional.\n" +
      "• DIAFÁSICA (situacional): formal × informal segundo o contexto.\n" +
      "• DIACRÔNICA (histórica): mudança ao longo do tempo (\"Vossa Mercê\" → \"você\").\n\n" +
      "PRECONCEITO LINGUÍSTICO: julgar variedades não-padrão como \"erradas\". Toda variedade tem regras próprias e funciona perfeitamente para sua comunidade. " +
      "A norma culta é UMA das variedades, valorizada socialmente, mas não é \"a língua certa\" em sentido absoluto.",
    tags: ["sociolinguística", "variação"],
    questoesRelacionadas: [],
  },
  {
    id: "lin-modernismo",
    materia: "Linguagens",
    titulo: "Modernismo brasileiro — Semana de 22",
    resumo: "Rupturas, fases e principais autores.",
    conteudo:
      "Semana de Arte Moderna (fevereiro de 1922, São Paulo): rompimento com o academicismo.\n\n" +
      "1ª FASE (1922–1930) — heroica/destruidora: Mário de Andrade (Macunaíma, Pauliceia Desvairada), Oswald de Andrade (Manifesto Antropófago, Pau-Brasil), Manuel Bandeira.\n\n" +
      "2ª FASE (1930–1945) — consolidação, romance regionalista: Graciliano Ramos (Vidas Secas), Jorge Amado, Rachel de Queiroz, José Lins do Rego. Poesia: Drummond, Cecília Meireles, Vinicius, Murilo Mendes.\n\n" +
      "3ª FASE (1945+) — Geração de 45: João Cabral de Melo Neto (rigor formal), Clarice Lispector (introspecção), Guimarães Rosa (linguagem inventiva — Grande Sertão: Veredas).",
    tags: ["literatura", "modernismo"],
    questoesRelacionadas: [],
  },

  // ============================================================
  // CIÊNCIAS DA NATUREZA
  // ============================================================
  {
    id: "cn-gases",
    materia: "Ciências da Natureza",
    titulo: "Leis dos gases ideais",
    resumo: "Boyle, Charles, Gay-Lussac e a equação geral PV = nRT.",
    conteudo:
      "• Lei de Boyle (T constante): P·V = constante. Volume cai pela metade ⇒ pressão dobra.\n" +
      "• Lei de Charles (P constante): V/T = constante.\n" +
      "• Gay-Lussac (V constante): P/T = constante.\n" +
      "• Equação geral dos gases ideais: P·V = n·R·T, com R = 0,082 atm·L/(mol·K).\n\n" +
      "Use sempre TEMPERATURA EM KELVIN (T(K) = T(°C) + 273). Gás ideal supõe partículas pontuais sem interação — boa aproximação para gases reais a baixa pressão e alta temperatura.",
    tags: ["física", "gases", "termodinâmica"],
    questoesRelacionadas: ["q3"],
  },
  {
    id: "cn-fotos",
    materia: "Ciências da Natureza",
    titulo: "Fotossíntese",
    resumo: "Conversão de luz em energia química com produção de glicose e O₂.",
    conteudo:
      "Equação geral: 6 CO₂ + 6 H₂O + luz → C₆H₁₂O₆ + 6 O₂.\n\n" +
      "Ocorre nos cloroplastos:\n" +
      "• FASE CLARA (tilacoides): a clorofila absorve luz, ocorre fotólise da água (libera O₂), produz ATP e NADPH.\n" +
      "• FASE ESCURA / Ciclo de Calvin (estroma): usa ATP e NADPH para fixar CO₂ formando glicose.\n\n" +
      "Fatores limitantes: intensidade luminosa, concentração de CO₂, temperatura, disponibilidade de água.",
    tags: ["biologia", "fotossíntese"],
    questoesRelacionadas: ["q8"],
  },
  {
    id: "cn-mecanica",
    materia: "Ciências da Natureza",
    titulo: "Leis de Newton",
    resumo: "Inércia, força resultante e ação-reação.",
    conteudo:
      "1ª LEI (Inércia): corpo permanece em repouso ou MRU se a força resultante for nula.\n" +
      "2ª LEI: F = m·a. A aceleração é proporcional à força resultante e inversa à massa. Unidade de força: newton (N) = kg·m/s².\n" +
      "3ª LEI (Ação e reação): toda ação gera uma reação de mesma intensidade, mesma direção e sentido oposto, em CORPOS DIFERENTES.\n\n" +
      "Atenção: peso (P = m·g) é a força gravitacional sobre o corpo; massa é constante, peso varia com g (Lua, Marte).",
    tags: ["física", "mecânica", "newton"],
    questoesRelacionadas: [],
  },
  {
    id: "cn-cinematica",
    materia: "Ciências da Natureza",
    titulo: "Cinemática — MRU e MRUV",
    resumo: "Velocidade, aceleração e equações horárias.",
    conteudo:
      "MRU (movimento retilíneo uniforme): v constante. Equação: S = S₀ + v·t.\n\n" +
      "MRUV (uniformemente variado): a constante.\n" +
      "• v = v₀ + a·t\n" +
      "• S = S₀ + v₀·t + (a·t²)/2\n" +
      "• Equação de Torricelli: v² = v₀² + 2·a·ΔS\n\n" +
      "Queda livre: a = g ≈ 9,8 m/s² (na Terra). Lançamento vertical: na subida, a velocidade diminui; no ponto mais alto, v = 0.",
    tags: ["física", "cinemática"],
    questoesRelacionadas: [],
  },
  {
    id: "cn-energia",
    materia: "Ciências da Natureza",
    titulo: "Energia mecânica — cinética e potencial",
    resumo: "Conservação de energia e trabalho.",
    conteudo:
      "• Energia cinética: Ec = (m·v²)/2.\n" +
      "• Energia potencial gravitacional: Ep = m·g·h.\n" +
      "• Energia potencial elástica: Eel = (k·x²)/2.\n" +
      "• Trabalho: W = F·d·cosθ (J).\n" +
      "• Potência: P = W/t (W).\n\n" +
      "CONSERVAÇÃO: na ausência de atrito, Em = Ec + Ep é constante. Com atrito, parte vira calor (energia dissipada).",
    tags: ["física", "energia"],
    questoesRelacionadas: [],
  },
  {
    id: "cn-eletro",
    materia: "Ciências da Natureza",
    titulo: "Eletrodinâmica — Lei de Ohm",
    resumo: "Tensão, corrente, resistência e potência elétrica.",
    conteudo:
      "Lei de Ohm: U = R·i (U em V, R em Ω, i em A).\n" +
      "Potência: P = U·i = R·i² = U²/R.\n\n" +
      "Associação de resistores:\n" +
      "• SÉRIE: Rₑ = R₁ + R₂ + ... A corrente é a mesma; tensão se divide.\n" +
      "• PARALELO: 1/Rₑ = 1/R₁ + 1/R₂ + ... A tensão é a mesma; corrente se divide.\n\n" +
      "Energia consumida: E = P·t. Conta de luz é cobrada em kWh.",
    tags: ["física", "eletricidade"],
    questoesRelacionadas: [],
  },
  {
    id: "cn-ondas",
    materia: "Ciências da Natureza",
    titulo: "Ondas — propriedades fundamentais",
    resumo: "Comprimento de onda, frequência, velocidade e fenômenos.",
    conteudo:
      "Equação fundamental: v = λ·f, onde λ = comprimento de onda (m), f = frequência (Hz).\n" +
      "Período: T = 1/f.\n\n" +
      "Tipos:\n" +
      "• Mecânicas (precisam de meio): som, ondas na corda.\n" +
      "• Eletromagnéticas (vácuo OK): luz, rádio, raios-X.\n\n" +
      "Fenômenos: REFLEXÃO, REFRAÇÃO (mudança de meio, muda v e λ, mas f se mantém), DIFRAÇÃO (contorno de obstáculos), INTERFERÊNCIA (construtiva/destrutiva), EFEITO DOPPLER (mudança de frequência percebida pelo movimento).",
    tags: ["física", "ondas"],
    questoesRelacionadas: [],
  },
  {
    id: "cn-quimica-organica",
    materia: "Ciências da Natureza",
    titulo: "Química orgânica — funções e nomenclatura",
    resumo: "Hidrocarbonetos, álcoois, ácidos carboxílicos e outras funções.",
    conteudo:
      "Funções e sufixos:\n" +
      "• Hidrocarbonetos: só C e H. Alcanos -ano, alcenos -eno, alcinos -ino.\n" +
      "• Álcoois: −OH em carbono saturado → -ol. Ex.: etanol.\n" +
      "• Fenóis: −OH em anel aromático.\n" +
      "• Aldeídos: −CHO → -al.\n" +
      "• Cetonas: C=O entre carbonos → -ona.\n" +
      "• Ácidos carboxílicos: −COOH → ácido -oico.\n" +
      "• Ésteres: −COO−R (ácido + álcool, libera água).\n" +
      "• Aminas: −NH₂.\n" +
      "• Amidas: −CONH₂.\n\n" +
      "Isomeria: substâncias com mesma fórmula molecular mas estruturas diferentes.",
    tags: ["química", "orgânica"],
    questoesRelacionadas: [],
  },
  {
    id: "cn-quimica-geral",
    materia: "Ciências da Natureza",
    titulo: "Estequiometria e mol",
    resumo: "Cálculos com massa, mol e equações balanceadas.",
    conteudo:
      "1 mol = 6,02·10²³ partículas (constante de Avogadro).\n" +
      "Massa molar (g/mol) = soma das massas atômicas.\n" +
      "Volume molar de gás nas CNTP = 22,4 L.\n\n" +
      "Passos para estequiometria:\n" +
      "1. Balanceie a equação química.\n" +
      "2. Identifique a proporção em mols dos reagentes/produtos.\n" +
      "3. Converta dados (massa, volume) para mols, calcule e converta de volta.\n\n" +
      "Reagente limitante: aquele que acaba primeiro e determina quanto produto se forma.",
    tags: ["química", "estequiometria"],
    questoesRelacionadas: [],
  },
  {
    id: "cn-acido-base",
    materia: "Ciências da Natureza",
    titulo: "Ácidos, bases, sais e pH",
    resumo: "Funções inorgânicas e escala de acidez.",
    conteudo:
      "ÁCIDOS (Arrhenius): liberam H⁺ em água. Ex.: HCl, H₂SO₄.\n" +
      "BASES: liberam OH⁻. Ex.: NaOH, Ca(OH)₂.\n" +
      "SAIS: produto da neutralização ácido + base → sal + água.\n" +
      "ÓXIDOS: compostos binários com oxigênio.\n\n" +
      "pH = −log[H⁺]:\n" +
      "• pH < 7: ácido\n" +
      "• pH = 7: neutro\n" +
      "• pH > 7: básico\n\n" +
      "Escala vai de 0 a 14. Cada unidade representa fator 10 na concentração.",
    tags: ["química", "ácidos", "bases"],
    questoesRelacionadas: [],
  },
  {
    id: "cn-genetica",
    materia: "Ciências da Natureza",
    titulo: "Genética — leis de Mendel",
    resumo: "1ª e 2ª leis, dominância e quadro de Punnett.",
    conteudo:
      "1ª LEI (Segregação dos fatores): cada característica é determinada por um par de genes que se separam na formação dos gametas. " +
      "Cruzamento Aa × Aa → genotípica 1 AA : 2 Aa : 1 aa; fenotípica 3 dominantes : 1 recessivo.\n\n" +
      "2ª LEI (Segregação independente): genes em cromossomos diferentes se distribuem independentemente — diíbridos AaBb × AaBb resultam em 9:3:3:1.\n\n" +
      "Conceitos: homozigoto (AA, aa), heterozigoto (Aa), genótipo (carga genética), fenótipo (manifestação).\n\n" +
      "Exceções: codominância (AB), dominância incompleta, alelos múltiplos (sistema ABO), herança ligada ao sexo (daltonismo, hemofilia).",
    tags: ["biologia", "genética", "mendel"],
    questoesRelacionadas: [],
  },
  {
    id: "cn-ecologia",
    materia: "Ciências da Natureza",
    titulo: "Ecologia — cadeias e ciclos",
    resumo: "Níveis tróficos, fluxo de energia e ciclos biogeoquímicos.",
    conteudo:
      "Cadeia alimentar: produtores → consumidores 1ºs (herbívoros) → 2ºs (carnívoros) → 3ºs → decompositores.\n\n" +
      "ENERGIA flui (unidirecional, com perda em cada nível — só ~10% passa adiante).\n" +
      "MATÉRIA cicla (água, carbono, nitrogênio, oxigênio).\n\n" +
      "Relações ecológicas:\n" +
      "• Harmônicas: mutualismo, protocooperação, comensalismo, inquilinismo.\n" +
      "• Desarmônicas: predação, parasitismo, competição, amensalismo.\n\n" +
      "Impactos antrópicos: efeito estufa intensificado (CO₂, CH₄), eutrofização, bioacumulação de poluentes ao longo da cadeia.",
    tags: ["biologia", "ecologia"],
    questoesRelacionadas: [],
  },
  {
    id: "cn-citologia",
    materia: "Ciências da Natureza",
    titulo: "Citologia — célula e organelas",
    resumo: "Procariontes, eucariontes e funções das organelas.",
    conteudo:
      "PROCARIONTES (sem núcleo): bactérias e arqueas. Material genético no citoplasma.\n" +
      "EUCARIONTES (com núcleo): protozoários, fungos, plantas, animais.\n\n" +
      "Organelas e funções:\n" +
      "• Mitocôndria: respiração celular, produção de ATP.\n" +
      "• Cloroplasto (vegetais): fotossíntese.\n" +
      "• Retículo endoplasmático rugoso: síntese de proteínas; liso: síntese de lipídios.\n" +
      "• Complexo de Golgi: empacotamento e secreção.\n" +
      "• Lisossomos: digestão intracelular.\n" +
      "• Ribossomos: tradução do RNA em proteínas.\n" +
      "• Núcleo: contém o DNA, controla a célula.",
    tags: ["biologia", "citologia"],
    questoesRelacionadas: [],
  },
  {
    id: "cn-corpo-humano",
    materia: "Ciências da Natureza",
    titulo: "Sistemas do corpo humano",
    resumo: "Digestório, circulatório, respiratório e nervoso — visão geral.",
    conteudo:
      "DIGESTÓRIO: boca → esôfago → estômago → intestino delgado (absorção) → intestino grosso → ânus. Enzimas: amilase, pepsina, lipase.\n\n" +
      "CIRCULATÓRIO: coração (4 câmaras), artérias (saem do coração), veias (chegam), capilares. Pequena circulação (pulmonar) e grande (sistêmica).\n\n" +
      "RESPIRATÓRIO: vias aéreas → pulmões → alvéolos (troca gasosa O₂/CO₂ por difusão).\n\n" +
      "NERVOSO: SNC (encéfalo + medula) e SNP (nervos). Neurônio transmite impulso elétrico via sinapses (neurotransmissores).",
    tags: ["biologia", "fisiologia"],
    questoesRelacionadas: [],
  },

  // ============================================================
  // HUMANAS
  // ============================================================
  {
    id: "hum-revind",
    materia: "Humanas",
    titulo: "Revolução Industrial inglesa",
    resumo: "Causas estruturais e a formação do proletariado urbano.",
    conteudo:
      "Por que começou na Inglaterra (séc. XVIII)?\n" +
      "• ENCLOSURES (cercamentos): privatização das terras comuns expulsou camponeses para as cidades, formando mão de obra livre e barata.\n" +
      "• Acúmulo de capital comercial vindo das colônias.\n" +
      "• Jazidas abundantes de carvão e ferro.\n" +
      "• Estabilidade política após a Revolução Gloriosa (1688).\n" +
      "• Mercado consumidor garantido pelas colônias.\n\n" +
      "Consequências: urbanização caótica, jornadas de 14–16h, trabalho infantil, surgimento do PROLETARIADO e da burguesia industrial, ludismo, cartismo, ideologias socialistas.",
    tags: ["história", "revolução industrial"],
    questoesRelacionadas: ["q4"],
  },
  {
    id: "hum-revfrancesa",
    materia: "Humanas",
    titulo: "Revolução Francesa (1789)",
    resumo: "Crise do Antigo Regime, fases e legado iluminista.",
    conteudo:
      "Causas: crise financeira da monarquia (gastos com guerras), privilégios da nobreza/clero, fome, influência iluminista (Rousseau, Voltaire, Montesquieu).\n\n" +
      "Fases:\n" +
      "• Assembleia Nacional Constituinte (1789–91): Queda da Bastilha, Declaração dos Direitos do Homem.\n" +
      "• Convenção (1792–95): República, execução de Luís XVI, Terror jacobino sob Robespierre.\n" +
      "• Diretório (1795–99): governo burguês moderado.\n" +
      "• Consulado / Império de Napoleão (1799–1815): código civil, expansão militar.\n\n" +
      "Legado: fim do feudalismo na Europa, Direitos Humanos, lema Liberdade-Igualdade-Fraternidade, Estado moderno.",
    tags: ["história", "revoluções"],
    questoesRelacionadas: [],
  },
  {
    id: "hum-eravargas",
    materia: "Humanas",
    titulo: "Era Vargas (1930–1945)",
    resumo: "Governo Provisório, Constitucional e Estado Novo.",
    conteudo:
      "GOVERNO PROVISÓRIO (1930–34): Vargas chega ao poder pela Revolução de 30, derrubando a República Velha. Centralização, Ministério do Trabalho, voto feminino e secreto (1932).\n\n" +
      "CONSTITUCIONAL (1934–37): nova Constituição, polarização entre ANL (esquerda) e AIB (integralistas, direita).\n\n" +
      "ESTADO NOVO (1937–45): ditadura inspirada no fascismo, censura via DIP, perseguição a opositores. CLT (1943) consolida direitos trabalhistas. Industrialização: criação da CSN (Volta Redonda). Brasil entra na 2ª Guerra ao lado dos Aliados — contradição com o autoritarismo interno levou à queda em 1945.",
    tags: ["história do brasil", "era vargas"],
    questoesRelacionadas: [],
  },
  {
    id: "hum-ditadura",
    materia: "Humanas",
    titulo: "Ditadura Militar no Brasil (1964–1985)",
    resumo: "Golpe, Atos Institucionais, Anos de Chumbo e abertura.",
    conteudo:
      "Golpe de 31 de março de 1964 derrubou João Goulart, com apoio dos EUA (contexto da Guerra Fria).\n\n" +
      "Atos Institucionais cassaram direitos políticos. AI-5 (dez/1968) foi o mais duro: suspendeu garantias, fechou o Congresso, instituiu censura plena.\n\n" +
      "\"MILAGRE ECONÔMICO\" (1969–73): crescimento de ~10% ao ano, com forte concentração de renda. Crise do petróleo (1973) encerra o ciclo.\n\n" +
      "Resistência: guerrilhas urbana e rural (Araguaia), MDB como oposição consentida. Abertura \"lenta, gradual e segura\" sob Geisel. Lei da Anistia (1979). Eleições Diretas Já (1984, derrotadas) → eleição indireta de Tancredo Neves (1985).",
    tags: ["história do brasil", "ditadura militar"],
    questoesRelacionadas: [],
  },
  {
    id: "hum-imperio-brasil",
    materia: "Humanas",
    titulo: "Brasil Imperial — do 1º Reinado à República",
    resumo: "Independência, Regência, 2º Reinado e a queda da Monarquia.",
    conteudo:
      "1º REINADO (1822–31): D. Pedro I — Independência, Constituição outorgada de 1824 (Poder Moderador), Confederação do Equador, abdicação.\n\n" +
      "REGÊNCIAS (1831–40): instabilidade — Cabanagem, Balaiada, Sabinada, Farroupilha. Ato Adicional de 1834.\n\n" +
      "2º REINADO (1840–89): D. Pedro II — Lei Eusébio de Queirós (1850, fim do tráfico), Guerra do Paraguai (1864–70), abolição gradual: Lei do Ventre Livre (1871), Sexagenários (1885), Áurea (1888).\n\n" +
      "Queda: descontentamento da elite agrária pós-abolição, crise com a Igreja, ascensão republicana e militar (Benjamin Constant, Deodoro). Proclamação em 15/11/1889.",
    tags: ["história do brasil", "império"],
    questoesRelacionadas: [],
  },
  {
    id: "hum-globalizacao",
    materia: "Humanas",
    titulo: "Globalização e geopolítica contemporânea",
    resumo: "Fluxos econômicos, blocos regionais e desigualdades.",
    conteudo:
      "Globalização: integração de mercados, tecnologia da informação, atuação de empresas transnacionais, cadeias produtivas globais.\n\n" +
      "Blocos econômicos: União Europeia (mais integrado, com moeda única), Mercosul, USMCA (ex-NAFTA), ASEAN, BRICS.\n\n" +
      "Críticas: aprofundamento das desigualdades Norte-Sul, desindustrialização periférica, perda de soberania, financeirização da economia, precarização do trabalho.\n\n" +
      "Multipolaridade atual: ascensão da China, retorno da Rússia ao protagonismo militar, disputa tecnológica EUA × China (semicondutores, IA).",
    tags: ["geografia", "globalização"],
    questoesRelacionadas: [],
  },
  {
    id: "hum-clima",
    materia: "Humanas",
    titulo: "Climas e domínios morfoclimáticos do Brasil",
    resumo: "Equatorial, tropical, semiárido, subtropical e os 6 domínios de Ab'Saber.",
    conteudo:
      "CLIMAS:\n" +
      "• Equatorial (Amazônia): quente e úmido o ano todo.\n" +
      "• Tropical típico (Centro-Oeste, parte do NE): estações seca e chuvosa.\n" +
      "• Semiárido (Sertão NE): baixa pluviosidade, irregularidade.\n" +
      "• Tropical de Altitude (SE): chuvas no verão, invernos amenos.\n" +
      "• Subtropical (Sul): 4 estações bem definidas, chuvas o ano todo.\n" +
      "• Litorâneo úmido: alta umidade da costa.\n\n" +
      "DOMÍNIOS MORFOCLIMÁTICOS (Aziz Ab'Saber): Amazônico, Cerrado, Caatinga, Mares de Morros (Mata Atlântica), Araucárias (Mata das Araucárias), Pradarias (Pampas) — além de faixas de transição.",
    tags: ["geografia", "clima", "brasil"],
    questoesRelacionadas: [],
  },
  {
    id: "hum-urbanizacao",
    materia: "Humanas",
    titulo: "Urbanização brasileira",
    resumo: "Êxodo rural, metropolização e problemas urbanos.",
    conteudo:
      "Urbanização brasileira foi TARDIA, RÁPIDA e CONCENTRADA. Em 1940, ~30% urbano; hoje, mais de 85%.\n\n" +
      "Causas: industrialização concentrada no Sudeste (anos 1950+), mecanização agrícola, fuga da seca no Nordeste — êxodo rural.\n\n" +
      "Consequências: metropolização (RM de SP, RJ, BH), favelização, déficit habitacional, periferização, segregação socioespacial, mobilidade precária.\n\n" +
      "Conceitos: macrocefalia urbana (cidade primaz domina a rede), conurbação (cidades vizinhas se fundem), gentrificação (elitização de áreas centrais).",
    tags: ["geografia", "urbanização"],
    questoesRelacionadas: [],
  },
  {
    id: "hum-filosofia",
    materia: "Humanas",
    titulo: "Filosofia política — contratualistas",
    resumo: "Hobbes, Locke e Rousseau sobre o Estado.",
    conteudo:
      "Os três partem do conceito de \"estado de natureza\" e \"contrato social\" — mas chegam a conclusões opostas.\n\n" +
      "• HOBBES (Leviatã, 1651): estado de natureza é \"guerra de todos contra todos\". Pacto cede poder ABSOLUTO ao soberano em troca de segurança. Justifica o absolutismo.\n\n" +
      "• LOCKE (Dois Tratados, 1689): estado de natureza tem direitos naturais (vida, liberdade, propriedade). Governo é LIMITADO e cabe direito de resistência se ele violar o pacto. Base do liberalismo.\n\n" +
      "• ROUSSEAU (Contrato Social, 1762): \"o homem nasce livre e em toda parte está acorrentado\". Soberania é POPULAR; vontade geral. Inspirou a Revolução Francesa.",
    tags: ["filosofia", "política"],
    questoesRelacionadas: [],
  },
  {
    id: "hum-filosofia-classica",
    materia: "Humanas",
    titulo: "Filosofia clássica — Sócrates, Platão e Aristóteles",
    resumo: "O tripé da filosofia grega antiga.",
    conteudo:
      "SÓCRATES: \"só sei que nada sei\". Método maiêutico (parto das ideias) — perguntas que levam o interlocutor a reconhecer suas contradições. Não escreveu; conhecemos por Platão.\n\n" +
      "PLATÃO (discípulo de Sócrates): teoria das ideias / mundo das formas. O Mito da Caverna ilustra a passagem do mundo sensível (sombras) para o inteligível (verdade). Defendia a República governada pelo filósofo-rei.\n\n" +
      "ARISTÓTELES (discípulo de Platão): rompeu com o dualismo platônico. Lógica formal, classificação dos seres, ética da virtude (mediania), política como zoon politikon (\"o homem é um animal político\"). Influenciou a escolástica medieval.",
    tags: ["filosofia", "antiguidade"],
    questoesRelacionadas: [],
  },
  {
    id: "hum-sociologia",
    materia: "Humanas",
    titulo: "Sociologia clássica — Marx, Durkheim e Weber",
    resumo: "Os três fundadores da sociologia e seus conceitos centrais.",
    conteudo:
      "• MARX: materialismo histórico — a história se move pela LUTA DE CLASSES. Conceitos: mais-valia (lucro extraído do trabalho), alienação, infraestrutura econômica determina a superestrutura (política, cultura).\n\n" +
      "• DURKHEIM: define o FATO SOCIAL (exterior ao indivíduo, coercitivo, geral). Distingue solidariedade mecânica (sociedades tradicionais, semelhança) e orgânica (modernas, divisão do trabalho). Estudou suicídio e anomia.\n\n" +
      "• WEBER: foco na AÇÃO SOCIAL com sentido. Tipos de dominação: tradicional, carismática e racional-legal (burocracia moderna). Em \"A Ética Protestante e o Espírito do Capitalismo\" relaciona valores religiosos ao surgimento do capitalismo.",
    tags: ["sociologia", "teoria social"],
    questoesRelacionadas: [],
  },
  {
    id: "hum-direitos-humanos",
    materia: "Humanas",
    titulo: "Cidadania e Direitos Humanos",
    resumo: "Gerações de direitos e a Constituição de 1988.",
    conteudo:
      "Gerações (ou dimensões) dos direitos:\n" +
      "• 1ª (séc. XVIII–XIX): direitos CIVIS e POLÍTICOS — liberdade, voto. Inspirados pela Revolução Francesa.\n" +
      "• 2ª (séc. XX): direitos SOCIAIS, econômicos e culturais — saúde, educação, trabalho. Estado de bem-estar.\n" +
      "• 3ª: direitos DIFUSOS — meio ambiente, paz, desenvolvimento.\n" +
      "• 4ª/5ª (debate atual): bioética, direitos digitais, dados pessoais.\n\n" +
      "CF/1988 (\"Constituição Cidadã\"): art. 5º enumera direitos e garantias fundamentais. SUS, educação obrigatória, ECA (1990), Lei Maria da Penha (2006), Estatuto do Idoso (2003).",
    tags: ["sociologia", "cidadania", "direitos humanos"],
    questoesRelacionadas: [],
  },
  {
    id: "hum-guerra-fria",
    materia: "Humanas",
    titulo: "Guerra Fria (1947–1991)",
    resumo: "Bipolaridade EUA × URSS, conflitos periféricos e queda do Muro.",
    conteudo:
      "Após a 2ª Guerra, mundo bipolar: EUA (capitalismo, OTAN, Plano Marshall) × URSS (socialismo real, Pacto de Varsóvia, COMECON).\n\n" +
      "Não houve confronto direto entre as superpotências, mas conflitos periféricos: Coreia (1950–53), Vietnã (1955–75), Cuba (1959 — Crise dos Mísseis em 1962), Afeganistão.\n\n" +
      "Doutrinas: contenção (Truman), coexistência pacífica, détente nos anos 70.\n\n" +
      "Fim: crise econômica soviética, Glasnost e Perestroika de Gorbachev, Queda do Muro de Berlim (1989), dissolução da URSS (1991). Mundo passa a ser, brevemente, unipolar (EUA).",
    tags: ["história", "guerra fria"],
    questoesRelacionadas: [],
  },
];

export function findMaterialsForQuestion(questionId: string): MaterialTopic[] {
  const q = questions.find((x) => x.id === questionId);
  if (!q) return [];
  return library.filter(
    (m) =>
      m.questoesRelacionadas.includes(questionId) ||
      m.materia === q.materia ||
      m.tags.some((t) => q.tags.includes(t))
  );
}
