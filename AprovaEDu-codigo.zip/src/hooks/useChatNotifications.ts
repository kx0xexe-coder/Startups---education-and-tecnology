import { useEffect, useRef } from "react";
import { useLocation } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/components/AuthProvider";
import { toast } from "sonner";

/**
 * Global listener for incoming chat messages.
 * - Shows a browser notification when the tab is hidden or the user isn't on /chat.
 * - Shows an in-app toast otherwise.
 * Also requests Notification permission once per session on user gesture-less mount
 * (browsers will silently keep "default" until a user action, which is fine).
 */
export function useChatNotifications() {
  const { user } = useAuth();
  const location = useLocation();
  const locationRef = useRef(location.pathname);
  locationRef.current = location.pathname;

  useEffect(() => {
    if (!user) return;

    if (typeof Notification !== "undefined" && Notification.permission === "default") {
      // Best-effort; will succeed on Android/desktop after any prior gesture.
      Notification.requestPermission().catch(() => {});
    }

    const channel = supabase
      .channel(`chat-notify:${user.id}`)
      .on(
        "postgres_changes",
        {
          event: "INSERT",
          schema: "public",
          table: "chat_messages",
          filter: `recipient_id=eq.${user.id}`,
        },
        async (payload) => {
          const msg = payload.new as {
            sender_id: string;
            content: string;
          };

          const onChatPage = locationRef.current.startsWith("/chat");
          const hidden = typeof document !== "undefined" && document.visibilityState !== "visible";

          const { data: prof } = await supabase
            .from("profiles")
            .select("display_name")
            .eq("id", msg.sender_id)
            .maybeSingle();
          const name = prof?.display_name ?? "Novo estudante";
          const preview = msg.content.length > 120 ? `${msg.content.slice(0, 117)}…` : msg.content;

          const shouldNotifySystem =
            (hidden || !onChatPage) &&
            typeof Notification !== "undefined" &&
            Notification.permission === "granted";

          if (shouldNotifySystem) {
            try {
              const reg = await navigator.serviceWorker?.getRegistration();
              const options: NotificationOptions = {
                body: preview,
                icon: "/icon-192.png",
                badge: "/icon-192.png",
                tag: `chat-${msg.sender_id}`,
                data: { url: "/chat" },
              };
              if (reg?.showNotification) {
                await reg.showNotification(name, options);
              } else {
                new Notification(name, options);
              }
              return;
            } catch {
              /* fall through to toast */
            }
          }

          if (!onChatPage) {
            toast(`${name}`, { description: preview });
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user]);
}
