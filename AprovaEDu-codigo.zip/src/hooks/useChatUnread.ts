import { useEffect, useSyncExternalStore } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/components/AuthProvider";

// Singleton unread store shared between the nav badge and the Chat page.
type Counts = Record<string, number>;

let counts: Counts = {};
let lastRead: Record<string, string> = {};
let currentUserId: string | null = null;
const listeners = new Set<() => void>();

function emit() {
  // Recreate the object reference so useSyncExternalStore triggers re-renders.
  counts = { ...counts };
  listeners.forEach((l) => l());
}

function lastReadKey(uid: string) {
  return `aprovaedu:chat:lastRead:${uid}`;
}

function loadLastRead(uid: string) {
  try {
    const raw = localStorage.getItem(lastReadKey(uid));
    lastRead = raw ? JSON.parse(raw) : {};
  } catch {
    lastRead = {};
  }
}
function saveLastRead(uid: string) {
  localStorage.setItem(lastReadKey(uid), JSON.stringify(lastRead));
}

export function markConversationRead(peerId: string) {
  if (!currentUserId) return;
  lastRead[peerId] = new Date().toISOString();
  saveLastRead(currentUserId);
  if (counts[peerId]) {
    counts[peerId] = 0;
    emit();
  }
}

function subscribe(cb: () => void) {
  listeners.add(cb);
  return () => listeners.delete(cb);
}

function getSnapshot() {
  return counts;
}

/** Initializes the unread store; call once from AppLayout. */
export function useChatUnreadTracker() {
  const { user } = useAuth();

  useEffect(() => {
    if (!user) {
      currentUserId = null;
      counts = {};
      emit();
      return;
    }
    currentUserId = user.id;
    loadLastRead(user.id);

    let cancelled = false;

    (async () => {
      const { data } = await supabase
        .from("chat_messages")
        .select("sender_id, created_at")
        .eq("recipient_id", user.id)
        .order("created_at", { ascending: false })
        .limit(500);
      if (cancelled || !data) return;
      const next: Counts = {};
      for (const m of data) {
        const cutoff = lastRead[m.sender_id];
        if (!cutoff || new Date(m.created_at) > new Date(cutoff)) {
          next[m.sender_id] = (next[m.sender_id] ?? 0) + 1;
        }
      }
      counts = next;
      emit();
    })();

    const channel = supabase
      .channel(`chat-unread:${user.id}`)
      .on(
        "postgres_changes",
        {
          event: "INSERT",
          schema: "public",
          table: "chat_messages",
          filter: `recipient_id=eq.${user.id}`,
        },
        (payload) => {
          const m = payload.new as { sender_id: string };
          counts[m.sender_id] = (counts[m.sender_id] ?? 0) + 1;
          emit();
        }
      )
      .subscribe();

    return () => {
      cancelled = true;
      supabase.removeChannel(channel);
    };
  }, [user]);
}

/** Read the live unread counts (per peer + total). */
export function useChatUnread() {
  const map = useSyncExternalStore(subscribe, getSnapshot, getSnapshot);
  const total = Object.values(map).reduce((a, b) => a + b, 0);
  return { counts: map, total };
}
