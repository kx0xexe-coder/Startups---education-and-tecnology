import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, Legend,
} from "recharts";
import { Target, TrendingUp, Brain } from "lucide-react";
import { useStats, predicaoEnem, taxaAcerto, dominioTri, materiasResumo } from "@/lib/stats";

const PIE_COLORS = [
  "hsl(var(--primary))",
  "hsl(var(--primary-glow))",
  "hsl(var(--accent))",
  "hsl(var(--success))",
  "hsl(var(--warning))",
];

export default function Analytics() {
  const stats = useStats();
  const resumo = materiasResumo(stats);
  const tempo = resumo
    .filter((r) => r.timeSec > 0)
    .map((r, i) => ({
      name: r.materia,
      value: Math.round(r.timeSec / 60), // minutos
      color: PIE_COLORS[i % PIE_COLORS.length],
    }));

  const predicao = predicaoEnem(stats);
  const taxa = Math.round(taxaAcerto(stats) * 100);
  const tri = dominioTri(stats);

  const hasData = stats.totalAnswered > 0;

  return (
    <div className="container py-8 md:py-12 space-y-8">
      <div>
        <div className="text-xs uppercase tracking-widest text-accent mb-2">Analytics</div>
        <h1 className="font-display text-5xl md:text-6xl">Sua mente, em números.</h1>
        {!hasData && (
          <p className="text-muted-foreground mt-2">
            Resolva questões para começar a popular seus dados.
          </p>
        )}
      </div>

      <div className="grid md:grid-cols-3 gap-4">
        <Big icon={Target} label="Predição ENEM" value={predicao ? predicao.toString() : "—"} sub={hasData ? "Atualizado em tempo real" : "Sem dados ainda"} accent="text-success" />
        <Big icon={TrendingUp} label="Taxa de acerto" value={hasData ? `${taxa}%` : "—"} sub={hasData ? `${stats.totalCorrect}/${stats.totalAnswered} questões` : "Sem dados ainda"} accent="text-primary-glow" />
        <Big icon={Brain} label="Domínio TRI" value={tri ? tri.toFixed(2) : "—"} sub={tri ? "Calculado pelos acertos" : "Mínimo de 5 questões"} accent="text-accent" />
      </div>

      <div className="grid lg:grid-cols-3 gap-4">
        <div className="card-elevated rounded-2xl p-6 lg:col-span-2">
          <h2 className="font-display text-2xl mb-4">Acertos por matéria</h2>
          <div className="h-[320px]">
            {resumo.length === 0 ? (
              <Empty msg="Responda questões para ver acertos por matéria." />
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={resumo}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
                  <XAxis dataKey="materia" stroke="hsl(var(--muted-foreground))" fontSize={12} />
                  <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} allowDecimals={false} />
                  <Tooltip
                    contentStyle={{ background: "hsl(var(--popover))", border: "1px solid hsl(var(--border))", borderRadius: 12 }}
                  />
                  <Legend />
                  <Bar dataKey="acertos" fill="hsl(var(--primary))" radius={[8, 8, 0, 0]} />
                  <Bar dataKey="erros" fill="hsl(var(--destructive))" radius={[8, 8, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            )}
          </div>
        </div>

        <div className="card-elevated rounded-2xl p-6">
          <h2 className="font-display text-2xl mb-4">Distribuição de tempo</h2>
          <div className="h-[320px]">
            {tempo.length === 0 ? (
              <Empty msg="Sem tempo registrado ainda." />
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie data={tempo} dataKey="value" nameKey="name" innerRadius={60} outerRadius={100} paddingAngle={4}>
                    {tempo.map((e) => <Cell key={e.name} fill={e.color} stroke="none" />)}
                  </Pie>
                  <Tooltip
                    contentStyle={{ background: "hsl(var(--popover))", border: "1px solid hsl(var(--border))", borderRadius: 12 }}
                  />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            )}
          </div>
        </div>
      </div>

      <div className="card-elevated rounded-2xl p-8">
        <h2 className="font-display text-3xl">Recomendações da IA</h2>
        {!hasData ? (
          <p className="text-sm text-muted-foreground mt-3">
            As recomendações aparecem assim que você começar a responder questões.
          </p>
        ) : (
          <ul className="mt-4 space-y-3">
            {gerarRecomendacoes(stats, resumo).map((r, i) => (
              <li key={i} className="flex items-start gap-3 p-4 rounded-xl bg-surface-elevated border border-border">
                <div className="size-7 rounded-full bg-gradient-primary grid place-items-center text-xs font-bold text-primary-foreground shrink-0">
                  {i + 1}
                </div>
                <span className="text-sm">{r}</span>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}

function gerarRecomendacoes(stats: ReturnType<typeof useStats>, resumo: ReturnType<typeof materiasResumo>): string[] {
  const recs: string[] = [];
  const piores = [...resumo].filter((r) => r.acertos + r.erros >= 2).sort((a, b) => a.taxa - b.taxa);
  if (piores[0]) {
    recs.push(`Reforce ${piores[0].materia} — taxa de acerto de ${Math.round(piores[0].taxa * 100)}%.`);
  }
  if (stats.simulados.length === 0) {
    recs.push("Faça seu primeiro simulado completo para calibrar a predição do ENEM.");
  } else {
    recs.push(`Você já fez ${stats.simulados.length} simulado(s) — mantenha a frequência semanal.`);
  }
  if (stats.streakDays < 3) {
    recs.push("Estude por 3 dias seguidos para construir uma ofensiva.");
  }
  return recs.slice(0, 3);
}

function Empty({ msg }: { msg: string }) {
  return (
    <div className="h-full grid place-items-center text-sm text-muted-foreground">{msg}</div>
  );
}

function Big({ icon: Icon, label, value, sub, accent }: any) {
  return (
    <div className="card-elevated rounded-2xl p-6">
      <div className={`flex items-center gap-2 ${accent}`}>
        <Icon className="size-4" />
        <span className="text-xs uppercase tracking-wider">{label}</span>
      </div>
      <div className="font-display text-5xl mt-2">{value}</div>
      <div className="text-xs text-muted-foreground mt-1">{sub}</div>
    </div>
  );
}
