import { useEffect, useState } from "react";
import { Star, MessageSquareHeart, GraduationCap, Loader2, Quote } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { useAuth } from "@/components/AuthProvider";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { z } from "zod";
import { Link } from "react-router-dom";

type Feedback = {
  id: string;
  user_id: string;
  display_name: string;
  message: string;
  rating: number;
  course: string | null;
  university: string | null;
  approved_enem: boolean;
  created_at: string;
};

const schema = z.object({
  display_name: z.string().trim().min(2).max(80),
  message: z.string().trim().min(10, "Mínimo 10 caracteres").max(1000),
  rating: z.number().int().min(1).max(5),
  course: z.string().trim().max(80).optional().or(z.literal("")),
  university: z.string().trim().max(120).optional().or(z.literal("")),
  approved_enem: z.boolean(),
});

function Stars({ value, onChange, readOnly }: { value: number; onChange?: (n: number) => void; readOnly?: boolean }) {
  return (
    <div className="flex gap-0.5">
      {[1, 2, 3, 4, 5].map((n) => (
        <button
          key={n}
          type="button"
          disabled={readOnly}
          onClick={() => onChange?.(n)}
          className={readOnly ? "cursor-default" : "hover:scale-110 transition"}
          aria-label={`${n} estrela${n > 1 ? "s" : ""}`}
        >
          <Star className={`size-4 ${n <= value ? "fill-warning text-warning" : "text-muted-foreground"}`} />
        </button>
      ))}
    </div>
  );
}

export default function Feedbacks() {
  const { user } = useAuth();
  const [list, setList] = useState<Feedback[]>([]);
  const [loading, setLoading] = useState(true);
  const [mine, setMine] = useState<Feedback | null>(null);

  // form state
  const [name, setName] = useState((user?.user_metadata?.display_name as string) ?? "");
  const [message, setMessage] = useState("");
  const [rating, setRating] = useState(5);
  const [course, setCourse] = useState("");
  const [university, setUniversity] = useState("");
  const [approved, setApproved] = useState(false);
  const [saving, setSaving] = useState(false);

  async function load() {
    setLoading(true);
    const { data } = await supabase
      .from("feedbacks")
      .select("*")
      .eq("is_published", true)
      .order("approved_enem", { ascending: false })
      .order("rating", { ascending: false })
      .order("created_at", { ascending: false })
      .limit(60);
    setList((data ?? []) as Feedback[]);
    if (user) {
      const own = (data ?? []).find((f) => f.user_id === user.id);
      setMine((own as Feedback) ?? null);
      if (own) {
        setName(own.display_name);
        setMessage(own.message);
        setRating(own.rating);
        setCourse(own.course ?? "");
        setUniversity(own.university ?? "");
        setApproved(own.approved_enem);
      }
    }
    setLoading(false);
  }

  useEffect(() => { load(); /* eslint-disable-next-line */ }, [user?.id]);

  async function submit() {
    if (!user) { toast.error("Faça login para enviar feedback"); return; }
    const parsed = schema.safeParse({
      display_name: name, message, rating,
      course, university, approved_enem: approved,
    });
    if (!parsed.success) { toast.error(parsed.error.issues[0].message); return; }
    setSaving(true);
    const payload = {
      user_id: user.id,
      display_name: parsed.data.display_name,
      message: parsed.data.message,
      rating: parsed.data.rating,
      course: parsed.data.course || null,
      university: parsed.data.university || null,
      approved_enem: parsed.data.approved_enem,
    };
    const { error } = mine
      ? await supabase.from("feedbacks").update(payload).eq("id", mine.id)
      : await supabase.from("feedbacks").insert(payload);
    setSaving(false);
    if (error) { toast.error(error.message); return; }
    toast.success(mine ? "Feedback atualizado!" : "Obrigado pelo seu feedback! 💙");
    load();
  }

  const avg = list.length ? (list.reduce((a, b) => a + b.rating, 0) / list.length) : 0;
  const approvedCount = list.filter((f) => f.approved_enem).length;

  return (
    <div className="p-4 md:p-8 max-w-6xl mx-auto space-y-8">
      <header className="space-y-1">
        <div className="flex items-center gap-2 text-primary">
          <MessageSquareHeart className="size-5" />
          <span className="text-xs font-medium uppercase tracking-wider">Feedbacks dos alunos</span>
        </div>
        <h1 className="font-display text-3xl md:text-4xl">Histórias de quem estudou no AprovaEDU</h1>
        <p className="text-muted-foreground">
          Depoimentos reais de estudantes que usaram a plataforma para se preparar para o ENEM.
        </p>
        {list.length > 0 && (
          <div className="flex flex-wrap gap-4 pt-3">
            <div className="flex items-center gap-2 text-sm">
              <Stars value={Math.round(avg)} readOnly />
              <span className="font-medium">{avg.toFixed(1)}</span>
              <span className="text-muted-foreground">de {list.length} avaliações</span>
            </div>
            {approvedCount > 0 && (
              <div className="flex items-center gap-1.5 text-sm text-emerald-600 dark:text-emerald-400">
                <GraduationCap className="size-4" />
                <span className="font-medium">{approvedCount}</span>
                <span className="text-muted-foreground">aprovados no ENEM</span>
              </div>
            )}
          </div>
        )}
      </header>

      {/* Form */}
      <Card className="p-5 space-y-4">
        <h2 className="font-display text-xl">{mine ? "Editar seu depoimento" : "Compartilhe sua experiência"}</h2>
        {!user ? (
          <div className="text-sm text-muted-foreground">
            <Link to="/auth" className="text-primary underline">Faça login</Link> para deixar seu feedback.
          </div>
        ) : (
          <div className="grid md:grid-cols-2 gap-3">
            <Input placeholder="Seu nome" value={name} onChange={(e) => setName(e.target.value)} maxLength={80} />
            <div className="flex items-center gap-3 px-3 rounded-md border border-input bg-background">
              <span className="text-sm text-muted-foreground">Nota:</span>
              <Stars value={rating} onChange={setRating} />
            </div>
            <Input placeholder="Curso desejado (opcional)" value={course} onChange={(e) => setCourse(e.target.value)} maxLength={80} />
            <Input placeholder="Universidade (opcional)" value={university} onChange={(e) => setUniversity(e.target.value)} maxLength={120} />
            <Textarea
              className="md:col-span-2"
              placeholder="Conte como o AprovaEDU te ajudou…"
              rows={5}
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              maxLength={1000}
            />
            <label className="md:col-span-2 flex items-center gap-2 text-sm">
              <Checkbox checked={approved} onCheckedChange={(v) => setApproved(!!v)} />
              Fui aprovado(a) no ENEM com a ajuda do AprovaEDU
            </label>
            <Button onClick={submit} disabled={saving} className="md:col-span-2">
              {saving && <Loader2 className="size-4 animate-spin" />}
              {mine ? "Atualizar depoimento" : "Publicar depoimento"}
            </Button>
          </div>
        )}
      </Card>

      {/* List */}
      <section>
        <h2 className="font-display text-2xl mb-4">O que dizem os alunos</h2>
        {loading ? (
          <div className="text-muted-foreground text-sm flex items-center gap-2">
            <Loader2 className="size-4 animate-spin" /> carregando depoimentos…
          </div>
        ) : list.length === 0 ? (
          <Card className="p-8 text-center text-muted-foreground">
            <Quote className="size-8 mx-auto mb-2 opacity-50" />
            Ainda não há depoimentos. Seja o primeiro a compartilhar sua experiência!
          </Card>
        ) : (
          <div className="grid md:grid-cols-2 gap-4">
            {list.map((f) => (
              <Card key={f.id} className="p-5 space-y-3">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <div className="font-medium">{f.display_name}</div>
                    {(f.course || f.university) && (
                      <div className="text-xs text-muted-foreground">
                        {[f.course, f.university].filter(Boolean).join(" · ")}
                      </div>
                    )}
                  </div>
                  <Stars value={f.rating} readOnly />
                </div>
                <p className="text-sm text-foreground/90 whitespace-pre-wrap">{f.message}</p>
                {f.approved_enem && (
                  <div className="inline-flex items-center gap-1.5 text-xs font-medium text-emerald-600 dark:text-emerald-400 bg-emerald-500/10 px-2 py-1 rounded-full">
                    <GraduationCap className="size-3.5" /> Aprovado(a) no ENEM
                  </div>
                )}
              </Card>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
