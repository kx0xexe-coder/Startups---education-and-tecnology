import { useEffect, useState } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { z } from "zod";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable";
import { Button } from "@/components/ui/button";
import { Sparkles, ArrowRight, Mail, Lock, User } from "lucide-react";
import { toast } from "sonner";
import { useAuth } from "@/components/AuthProvider";

const signInSchema = z.object({
  email: z.string().trim().email({ message: "E-mail inválido" }).max(255),
  password: z.string().min(6, { message: "Senha precisa ter ao menos 6 caracteres" }).max(100),
});

const signUpSchema = signInSchema.extend({
  displayName: z.string().trim().min(2, { message: "Nome muito curto" }).max(80),
});

export default function Auth() {
  const location = useLocation();
  const navigate = useNavigate();
  const { session } = useAuth();

  const params = new URLSearchParams(location.search);
  const initialMode: "signin" | "signup" =
    params.get("mode") === "signup" ? "signup" : "signin";
  const addAccount = (location.state as { addAccount?: boolean } | null)?.addAccount;

  const [mode, setMode] = useState<"signin" | "signup">(initialMode);
  const [loading, setLoading] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [displayName, setDisplayName] = useState("");

  const from = (location.state as { from?: string } | null)?.from || "/dashboard";

  useEffect(() => {
    if (session && !addAccount) navigate(from, { replace: true });
  }, [session, from, navigate, addAccount]);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    try {
      if (mode === "signup") {
        const parsed = signUpSchema.safeParse({ email, password, displayName });
        if (!parsed.success) {
          toast.error(parsed.error.issues[0].message);
          setLoading(false);
          return;
        }
        const { error } = await supabase.auth.signUp({
          email: parsed.data.email,
          password: parsed.data.password,
          options: {
            emailRedirectTo: `${window.location.origin}/dashboard`,
            data: { display_name: parsed.data.displayName },
          },
        });
        if (error) throw error;
        toast.success("Conta criada!", { description: "Confirme seu e-mail para entrar." });
      } else {
        const parsed = signInSchema.safeParse({ email, password });
        if (!parsed.success) {
          toast.error(parsed.error.issues[0].message);
          setLoading(false);
          return;
        }
        const { error } = await supabase.auth.signInWithPassword({
          email: parsed.data.email,
          password: parsed.data.password,
        });
        if (error) throw error;
      }
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : "Erro desconhecido";
      toast.error("Falha", { description: msg });
    } finally {
      setLoading(false);
    }
  }

  async function handleGoogle() {
    setLoading(true);
    try {
      const result = await lovable.auth.signInWithOAuth("google", {
        redirect_uri: `${window.location.origin}/dashboard`,
      });
      if (result.error) throw new Error(result.error.message ?? "Erro no Google");
      if (result.redirected) return;
      navigate("/dashboard", { replace: true });
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : "Erro desconhecido";
      toast.error("Falha no Google", { description: msg });
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen relative overflow-hidden grid lg:grid-cols-2">
      <div className="absolute inset-0 grid-bg pointer-events-none lg:hidden" />

      {/* Editorial side */}
      <aside className="hidden lg:flex flex-col justify-between p-12 relative bg-gradient-to-br from-primary/15 via-background to-accent/10 border-r border-border">
        <Link to="/" className="flex items-center gap-2">
          <div className="size-9 rounded-lg bg-gradient-primary grid place-items-center shadow-glow">
            <Sparkles className="size-4 text-primary-foreground" />
          </div>
          <span className="font-display text-2xl">AprovaEDu</span>
        </Link>
        <div className="max-w-md">
          <h1 className="font-display text-6xl leading-[0.95]">
            Aprovação <span className="italic text-gradient-primary">não é sorte.</span>
            <br />É algoritmo.
          </h1>
          <p className="mt-6 text-muted-foreground">
            Entre para continuar onde parou — sua ofensiva, seu XP e sua predição ENEM
            esperam por você.
          </p>
        </div>
        <p className="text-xs text-muted-foreground">© {new Date().getFullYear()} AprovaEDu</p>
      </aside>

      {/* Form */}
      <main className="flex items-center justify-center p-6 lg:p-12 relative">
        <div className="w-full max-w-md">
          <Link to="/" className="lg:hidden flex items-center gap-2 mb-8">
            <div className="size-8 rounded-lg bg-gradient-primary grid place-items-center">
              <Sparkles className="size-4 text-primary-foreground" />
            </div>
            <span className="font-display text-2xl">AprovaEDu</span>
          </Link>

          <div className="text-xs uppercase tracking-widest text-accent mb-2">
            {mode === "signin" ? "Acesso" : "Nova conta"}
          </div>
          <h2 className="font-display text-4xl">
            {mode === "signin" ? "Bem-vindo de volta." : "Comece agora."}
          </h2>
          <p className="text-sm text-muted-foreground mt-2">
            {mode === "signin"
              ? "Entre com sua conta para continuar."
              : "Crie sua conta gratuita em 30 segundos."}
          </p>

          <Button
            type="button"
            variant="outline"
            size="lg"
            className="w-full mt-8"
            onClick={handleGoogle}
            disabled={loading}
          >
            <GoogleIcon /> Continuar com Google
          </Button>

          <div className="flex items-center gap-3 my-6 text-xs text-muted-foreground">
            <div className="flex-1 h-px bg-border" />
            <span>ou com e-mail</span>
            <div className="flex-1 h-px bg-border" />
          </div>

          <form onSubmit={handleSubmit} className="space-y-3">
            {mode === "signup" && (
              <Field
                icon={User}
                label="Nome"
                type="text"
                value={displayName}
                onChange={(e) => setDisplayName(e.target.value)}
                placeholder="Como podemos te chamar?"
                autoComplete="name"
              />
            )}
            <Field
              icon={Mail}
              label="E-mail"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="voce@exemplo.com"
              autoComplete="email"
              required
            />
            <Field
              icon={Lock}
              label="Senha"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              autoComplete={mode === "signin" ? "current-password" : "new-password"}
              required
            />

            <Button
              type="submit"
              size="lg"
              disabled={loading}
              className="w-full bg-gradient-primary hover:opacity-90 shadow-glow mt-2"
            >
              {loading ? "Aguarde…" : mode === "signin" ? "Entrar" : "Criar conta"}
              <ArrowRight className="size-4" />
            </Button>
          </form>

          <p className="text-sm text-muted-foreground text-center mt-6">
            {mode === "signin" ? "Ainda não tem conta?" : "Já tem conta?"}{" "}
            <button
              type="button"
              onClick={() => setMode(mode === "signin" ? "signup" : "signin")}
              className="text-primary-glow hover:underline"
            >
              {mode === "signin" ? "Criar agora" : "Entrar"}
            </button>
          </p>
        </div>
      </main>
    </div>
  );
}

function Field({
  icon: Icon,
  label,
  ...rest
}: React.InputHTMLAttributes<HTMLInputElement> & { icon: React.ElementType; label: string }) {
  return (
    <label className="block">
      <span className="text-xs uppercase tracking-wider text-muted-foreground">{label}</span>
      <div className="relative mt-1">
        <Icon className="size-4 text-muted-foreground absolute left-3 top-1/2 -translate-y-1/2" />
        <input
          {...rest}
          className="w-full rounded-lg bg-input border border-border pl-10 pr-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-ring focus:border-primary transition-all"
        />
      </div>
    </label>
  );
}

function GoogleIcon() {
  return (
    <svg className="size-4" viewBox="0 0 24 24" aria-hidden="true">
      <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
      <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.99.66-2.25 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
      <path fill="#FBBC05" d="M5.84 14.1A6.97 6.97 0 0 1 5.46 12c0-.73.13-1.44.36-2.1V7.07H2.18A11 11 0 0 0 1 12c0 1.78.43 3.46 1.18 4.93l3.66-2.83z" />
      <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.83C6.71 7.31 9.14 5.38 12 5.38z" />
    </svg>
  );
}
