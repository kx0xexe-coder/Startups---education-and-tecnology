import { useEffect, useMemo, useRef, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/components/AuthProvider";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Search, Send, MessageSquareText, UserPlus, Circle } from "lucide-react";
import { cn } from "@/lib/utils";
import { isOnline } from "@/hooks/usePresence";
import { markConversationRead, useChatUnread } from "@/hooks/useChatUnread";
import { usePushNotifications } from "@/hooks/usePushNotifications";
import { toast } from "sonner";
import { Bell, BellOff } from "lucide-react";

type Profile = { id: string; display_name: string | null };
type Presence = { user_id: string; last_seen_at: string };
type ChatMessage = {
  id: string;
  sender_id: string;
  recipient_id: string;
  content: string;
  created_at: string;
};

type Contact = {
  profile: Profile;
  lastMessageAt?: string;
  preview?: string;
};

const CONTACTS_KEY = (uid: string) => `aprovaedu:chat:contacts:${uid}`;

export default function Chat() {
  const { user } = useAuth();
  const { counts: unreadCounts } = useChatUnread();
  const push = usePushNotifications();
  const [contacts, setContacts] = useState<Contact[]>([]);
  const [presences, setPresences] = useState<Record<string, string>>({});
  const [activeId, setActiveId] = useState<string | null>(null);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [draft, setDraft] = useState("");
  const [search, setSearch] = useState("");
  const [results, setResults] = useState<Profile[]>([]);
  const [searching, setSearching] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);

  // Load stored contact ids and their profiles
  useEffect(() => {
    if (!user) return;
    const raw = localStorage.getItem(CONTACTS_KEY(user.id));
    const ids: string[] = raw ? JSON.parse(raw) : [];
    if (ids.length === 0) return;
    supabase
      .from("profiles")
      .select("id, display_name")
      .in("id", ids)
      .then(({ data }) => {
        if (data) setContacts(data.map((p) => ({ profile: p })));
      });
  }, [user]);

  // Also pull anyone who has messaged us into contact list
  useEffect(() => {
    if (!user) return;
    (async () => {
      const { data } = await supabase
        .from("chat_messages")
        .select("sender_id, recipient_id, content, created_at")
        .or(`sender_id.eq.${user.id},recipient_id.eq.${user.id}`)
        .order("created_at", { ascending: false })
        .limit(200);
      if (!data) return;
      const peers = new Map<string, { at: string; preview: string }>();
      for (const m of data) {
        const peer = m.sender_id === user.id ? m.recipient_id : m.sender_id;
        if (!peers.has(peer)) peers.set(peer, { at: m.created_at, preview: m.content });
      }
      if (peers.size === 0) return;
      const { data: profs } = await supabase
        .from("profiles")
        .select("id, display_name")
        .in("id", Array.from(peers.keys()));
      if (!profs) return;
      setContacts((prev) => {
        const map = new Map(prev.map((c) => [c.profile.id, c]));
        for (const p of profs) {
          const meta = peers.get(p.id)!;
          map.set(p.id, { profile: p, lastMessageAt: meta.at, preview: meta.preview });
        }
        return Array.from(map.values()).sort(
          (a, b) => (b.lastMessageAt ?? "").localeCompare(a.lastMessageAt ?? "")
        );
      });
    })();
  }, [user]);

  // Presence for everyone we know + poll
  useEffect(() => {
    const ids = contacts.map((c) => c.profile.id);
    if (ids.length === 0) return;
    let cancelled = false;
    const load = async () => {
      const { data } = await supabase
        .from("user_presence")
        .select("user_id, last_seen_at")
        .in("user_id", ids);
      if (cancelled || !data) return;
      const map: Record<string, string> = {};
      for (const p of data as Presence[]) map[p.user_id] = p.last_seen_at;
      setPresences(map);
    };
    load();
    const id = window.setInterval(load, 20_000);
    return () => {
      cancelled = true;
      window.clearInterval(id);
    };
  }, [contacts]);

  // Load messages for active chat + subscribe realtime
  useEffect(() => {
    if (!user || !activeId) {
      setMessages([]);
      return;
    }
    (async () => {
      const { data } = await supabase
        .from("chat_messages")
        .select("*")
        .or(
          `and(sender_id.eq.${user.id},recipient_id.eq.${activeId}),and(sender_id.eq.${activeId},recipient_id.eq.${user.id})`
        )
        .order("created_at", { ascending: true })
        .limit(500);
      if (data) setMessages(data as ChatMessage[]);
    })();

    const channel = supabase
      .channel(`chat:${user.id}:${activeId}`)
      .on(
        "postgres_changes",
        { event: "INSERT", schema: "public", table: "chat_messages" },
        (payload) => {
          const m = payload.new as ChatMessage;
          const relevant =
            (m.sender_id === user.id && m.recipient_id === activeId) ||
            (m.sender_id === activeId && m.recipient_id === user.id);
          if (relevant) setMessages((prev) => [...prev, m]);
        }
      )
      .subscribe();
    return () => {
      supabase.removeChannel(channel);
    };
  }, [user, activeId]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  // Mark active conversation as read whenever it opens or a new message arrives.
  useEffect(() => {
    if (activeId && document.visibilityState === "visible") {
      markConversationRead(activeId);
    }
  }, [activeId, messages]);

  // Search users
  useEffect(() => {
    const q = search.trim();
    if (q.length < 2) {
      setResults([]);
      return;
    }
    setSearching(true);
    const t = window.setTimeout(async () => {
      const { data } = await supabase
        .from("profiles")
        .select("id, display_name")
        .ilike("display_name", `%${q}%`)
        .limit(10);
      setSearching(false);
      if (!data) return;
      setResults(data.filter((p) => p.id !== user?.id));
    }, 250);
    return () => window.clearTimeout(t);
  }, [search, user]);

  function addContact(p: Profile) {
    if (!user) return;
    setContacts((prev) => {
      if (prev.some((c) => c.profile.id === p.id)) return prev;
      const next = [{ profile: p }, ...prev];
      localStorage.setItem(
        CONTACTS_KEY(user.id),
        JSON.stringify(next.map((c) => c.profile.id))
      );
      return next;
    });
    setActiveId(p.id);
    setSearch("");
    setResults([]);
    toast.success(`${p.display_name ?? "Estudante"} adicionado ao bate-papo`);
  }

  async function send() {
    if (!user || !activeId) return;
    const content = draft.trim();
    if (!content) return;
    setDraft("");
    const { error } = await supabase.from("chat_messages").insert({
      sender_id: user.id,
      recipient_id: activeId,
      content,
    });
    if (error) {
      toast.error("Não foi possível enviar a mensagem");
      setDraft(content);
      return;
    }
    // Fire-and-forget push notification to the recipient's devices.
    supabase.functions
      .invoke("send-chat-push", { body: { recipient_id: activeId, content } })
      .catch(() => {
        /* silent — chat still works without push */
      });
  }

  const activeContact = useMemo(
    () => contacts.find((c) => c.profile.id === activeId) ?? null,
    [contacts, activeId]
  );

  return (
    <div className="p-4 lg:p-8 max-w-6xl mx-auto">
      <header className="mb-6 flex items-start justify-between gap-4 flex-wrap">
        <div>
          <h1 className="font-display text-3xl">Bate-papo</h1>
          <p className="text-muted-foreground text-sm mt-1">
            Converse com outros estudantes do AprovaEdu enquanto estuda.
          </p>
        </div>
        {push.status !== "unsupported" && (
          push.status === "granted" ? (
            <div className="text-xs text-emerald-500 flex items-center gap-1.5 py-2">
              <Bell className="size-3.5" />
              Notificações ativas
            </div>
          ) : push.status === "denied" ? (
            <div className="text-xs text-muted-foreground flex items-center gap-1.5 py-2 max-w-[240px]">
              <BellOff className="size-3.5 shrink-0" />
              Notificações bloqueadas. Ative-as nas configurações do navegador.
            </div>
          ) : (
            <Button
              size="sm"
              variant="outline"
              onClick={push.enable}
              disabled={push.busy}
              className="gap-2"
            >
              <Bell className="size-4" />
              Ativar notificações
            </Button>
          )
        )}
      </header>

      <div className="grid lg:grid-cols-[320px_1fr] gap-4 min-h-[70vh]">
        {/* Sidebar: search + contacts */}
        <Card className="p-3 flex flex-col gap-3 h-full">
          <div className="relative">
            <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
            <Input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Pesquisar estudante..."
              className="pl-8"
            />
          </div>

          {search.trim().length >= 2 && (
            <div className="rounded-md border border-border divide-y divide-border">
              {searching && (
                <div className="p-3 text-xs text-muted-foreground">Buscando...</div>
              )}
              {!searching && results.length === 0 && (
                <div className="p-3 text-xs text-muted-foreground">
                  Nenhum estudante encontrado.
                </div>
              )}
              {results.map((p) => (
                <button
                  key={p.id}
                  onClick={() => addContact(p)}
                  className="w-full flex items-center justify-between gap-2 p-2.5 text-left hover:bg-accent/50 transition-colors"
                >
                  <div className="flex items-center gap-2 min-w-0">
                    <div className="size-8 rounded-full bg-gradient-primary grid place-items-center text-primary-foreground text-sm font-display shrink-0">
                      {(p.display_name ?? "?")[0]?.toUpperCase()}
                    </div>
                    <div className="min-w-0">
                      <div className="text-sm truncate">
                        {p.display_name ?? "Estudante"}
                      </div>
                      <div
                        className={cn(
                          "text-[11px]",
                          isOnline(presences[p.id])
                            ? "text-emerald-500"
                            : "text-muted-foreground"
                        )}
                      >
                        {isOnline(presences[p.id]) ? "estudando!" : "offline"}
                      </div>
                    </div>
                  </div>
                  <UserPlus className="size-4 text-muted-foreground shrink-0" />
                </button>
              ))}
            </div>
          )}

          <div className="text-xs uppercase tracking-wider text-muted-foreground px-1">
            Conversas
          </div>
          <div className="flex-1 overflow-y-auto -mx-1 px-1 space-y-1">
            {contacts.length === 0 && (
              <div className="text-sm text-muted-foreground p-3 text-center">
                Pesquise um estudante para começar uma conversa.
              </div>
            )}
            {contacts.map((c) => {
              const online = isOnline(presences[c.profile.id]);
              const active = c.profile.id === activeId;
              const unread = unreadCounts[c.profile.id] ?? 0;
              return (
                <button
                  key={c.profile.id}
                  onClick={() => {
                    setActiveId(c.profile.id);
                    markConversationRead(c.profile.id);
                  }}
                  className={cn(
                    "w-full flex items-center gap-3 p-2.5 rounded-md text-left transition-colors",
                    active ? "bg-accent" : "hover:bg-accent/50"
                  )}
                >
                  <div className="relative shrink-0">
                    <div className="size-9 rounded-full bg-gradient-primary grid place-items-center text-primary-foreground font-display">
                      {(c.profile.display_name ?? "?")[0]?.toUpperCase()}
                    </div>
                    <Circle
                      className={cn(
                        "absolute -bottom-0.5 -right-0.5 size-3 rounded-full",
                        online
                          ? "fill-emerald-500 text-emerald-500"
                          : "fill-muted-foreground/40 text-muted-foreground/40"
                      )}
                    />
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="text-sm truncate flex items-center gap-1.5">
                      <span className="truncate">
                        {c.profile.display_name ?? "Estudante"}
                      </span>
                      <span
                        className={cn(
                          "text-[11px]",
                          online ? "text-emerald-500" : "text-muted-foreground"
                        )}
                      >
                        ({online ? "estudando!" : "offline"})
                      </span>
                    </div>
                    {c.preview && (
                      <div className="text-xs text-muted-foreground truncate">
                        {c.preview}
                      </div>
                    )}
                  </div>
                  {unread > 0 && !active && (
                    <span className="ml-1 min-w-5 h-5 px-1.5 rounded-full bg-primary text-primary-foreground text-[10px] font-medium grid place-items-center shrink-0">
                      {unread > 99 ? "99+" : unread}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </Card>

        {/* Chat panel */}
        <Card className="flex flex-col h-full">
          {!activeContact ? (
            <div className="flex-1 grid place-items-center text-center p-8">
              <div>
                <MessageSquareText className="size-10 mx-auto text-muted-foreground mb-2" />
                <div className="font-display text-xl">Selecione uma conversa</div>
                <p className="text-sm text-muted-foreground mt-1 max-w-sm">
                  Pesquise o nome de um estudante e adicione ao bate-papo para
                  começar a conversar.
                </p>
              </div>
            </div>
          ) : (
            <>
              <div className="p-4 border-b border-border flex items-center gap-3">
                <div className="size-10 rounded-full bg-gradient-primary grid place-items-center text-primary-foreground font-display">
                  {(activeContact.profile.display_name ?? "?")[0]?.toUpperCase()}
                </div>
                <div>
                  <div className="font-medium">
                    {activeContact.profile.display_name ?? "Estudante"}
                  </div>
                  <div
                    className={cn(
                      "text-xs",
                      isOnline(presences[activeContact.profile.id])
                        ? "text-emerald-500"
                        : "text-muted-foreground"
                    )}
                  >
                    {isOnline(presences[activeContact.profile.id])
                      ? "estudando!"
                      : "offline"}
                  </div>
                </div>
              </div>

              <div className="flex-1 overflow-y-auto p-4 space-y-2">
                {messages.length === 0 && (
                  <div className="text-center text-sm text-muted-foreground py-8">
                    Diga oi 👋
                  </div>
                )}
                {messages.map((m) => {
                  const mine = m.sender_id === user?.id;
                  return (
                    <div
                      key={m.id}
                      className={cn("flex", mine ? "justify-end" : "justify-start")}
                    >
                      <div
                        className={cn(
                          "max-w-[75%] rounded-2xl px-3.5 py-2 text-sm",
                          mine
                            ? "bg-primary text-primary-foreground rounded-br-sm"
                            : "bg-muted text-foreground rounded-bl-sm"
                        )}
                      >
                        <div className="whitespace-pre-wrap break-words">
                          {m.content}
                        </div>
                        <div
                          className={cn(
                            "text-[10px] mt-1 opacity-70",
                            mine ? "text-primary-foreground" : "text-muted-foreground"
                          )}
                        >
                          {new Date(m.created_at).toLocaleTimeString([], {
                            hour: "2-digit",
                            minute: "2-digit",
                          })}
                        </div>
                      </div>
                    </div>
                  );
                })}
                <div ref={bottomRef} />
              </div>

              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  send();
                }}
                className="p-3 border-t border-border flex items-center gap-2"
              >
                <Input
                  value={draft}
                  onChange={(e) => setDraft(e.target.value)}
                  placeholder="Escreva uma mensagem..."
                  maxLength={2000}
                />
                <Button type="submit" size="icon" disabled={!draft.trim()}>
                  <Send className="size-4" />
                </Button>
              </form>
            </>
          )}
        </Card>
      </div>
    </div>
  );
}
