import {
  Radar,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  ResponsiveContainer,
  Tooltip,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
} from "recharts";
import { Link } from "react-router-dom";
import { Flame, Trophy, Target, Zap, ArrowRight, BookOpen, Timer } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { xpToLevel } from "@/lib/engine";
import { useAuth } from "@/components/AuthProvider";
import { useStats, predicaoEnem, last14Days } from "@/lib/stats";
import { useAccessibility } from "@/components/AccessibilityProvider";
import { Heart, Clock3 } from "lucide-react";

const AREAS_BASE = ["Matemática", "Linguagens", "Ciências da Natureza", "Humanas", "Redação"];

export default function Dashboard() {
  const stats = useStats();
  const { profile } = useAccessibility();
  const xp = stats.xp;
  const { level, nextLevelXp, progress } = xpToLevel(xp);
  const notaPredita = predicaoEnem(stats);
  const { user } = useAuth();
  const fullName = (user?.user_metadata?.display_name as string | undefined) ?? user?.email ?? "Estudante";
  const firstName = fullName.split(" ")[0];

  const trendData = last14Days(stats);

  const radarData = AREAS_BASE.map((area) => {
    const m = stats.perMateria[area];
    const taxa = m && m.answered ? Math.round((m.correct / m.answered) * 100) : 0;
    return { area: area === "Ciências da Natureza" ? "C. Natureza" : area, você: taxa, média: 0 };
  });

  const rankingPos = stats.xp > 0 ? Math.max(100, 10000 - Math.floor(stats.xp / 5)) : null;

  return (
    <div className="container py-8 md:py-12 space-y-8">
      {/* Banner de personalização (acessibilidade) */}
      {profile.active && profile.adaptations.length > 0 && (
        <div className="card-elevated rounded-2xl p-5 border-success/30 bg-success/5 flex flex-col md:flex-row md:items-center gap-4">
          <div className="size-10 rounded-xl bg-success/15 grid place-items-center shrink-0">
            <Heart className="size-5 text-success" />
          </div>
          <div className="flex-1">
            <div className="text-xs uppercase tracking-widest text-success">Estudo personalizado · {profile.label}</div>
            <p className="text-sm text-muted-foreground mt-1">
              Seu laudo foi aprovado — os seguintes recursos estão ativos: {profile.adaptations.slice(0, 3).join(" · ")}.
            </p>
          </div>
          <Button asChild variant="outline" size="sm">
            <Link to="/acessibilidade">Ver detalhes</Link>
          </Button>
        </div>
      )}
      {profile.status === "pending" && (
        <div className="card-elevated rounded-2xl p-5 border-warning/30 bg-warning/5 flex items-center gap-4">
          <div className="size-10 rounded-xl bg-warning/15 grid place-items-center shrink-0">
            <Clock3 className="size-5 text-warning" />
          </div>
          <div className="flex-1">
            <div className="text-xs uppercase tracking-widest text-warning">Laudo em análise</div>
            <p className="text-sm text-muted-foreground mt-1">
              Após o período de análise (até 48h), seu estudo será personalizado automaticamente conforme sua neurodivergência.
            </p>
          </div>
        </div>
      )}


      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-end gap-4 justify-between">
        <div>
          <div className="text-xs uppercase tracking-widest text-accent mb-2">Painel</div>
          <h1 className="font-display text-5xl md:text-6xl leading-none">
            Bom estudo, <span className="italic text-gradient-primary">{firstName}.</span>
          </h1>
          <p className="text-muted-foreground mt-2">
            {stats.totalAnswered === 0
              ? "Comece sua jornada — toda métrica começa do zero."
              : "Continue evoluindo. Cada questão conta."}
          </p>
        </div>
        <Button asChild size="lg" className="bg-gradient-primary hover:opacity-90 shadow-glow">
          <Link to="/questoes">Continuar estudo <ArrowRight className="size-4" /></Link>
        </Button>
      </div>

      {/* KPI cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <KpiCard
          icon={Flame}
          label="Ofensiva"
          value={`${stats.streakDays} dias`}
          accent="text-warning"
          sub={stats.bestStreak > 0 ? `Melhor: ${stats.bestStreak} dias` : "Comece hoje!"}
        />
        <KpiCard
          icon={Zap}
          label={`Nível ${level}`}
          value={`${xp.toLocaleString("pt-BR")} XP`}
          accent="text-primary-glow"
          sub={`Próx. nível: ${nextLevelXp.toLocaleString("pt-BR")} XP`}
          progress={progress}
        />
        <KpiCard
          icon={Target}
          label="Predição ENEM"
          value={notaPredita ? notaPredita.toString() : "—"}
          accent="text-success"
          sub={notaPredita ? "Atualizado pelos seus acertos" : "Responda questões para calcular"}
        />
        <KpiCard
          icon={Trophy}
          label="Ranking"
          value={rankingPos ? `#${rankingPos.toLocaleString("pt-BR")}` : "—"}
          accent="text-accent"
          sub={rankingPos ? "Suba acumulando XP" : "Ganhe XP para entrar"}
        />
      </div>

      {/* Charts */}
      <div className="grid lg:grid-cols-3 gap-4">
        <div className="card-elevated rounded-2xl p-6 lg:col-span-2">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="font-display text-2xl">Heatmap de Conhecimento</h2>
              <p className="text-xs text-muted-foreground">Taxa de acerto por área (%)</p>
            </div>
          </div>
          <div className="h-[320px]">
            <ResponsiveContainer width="100%" height="100%">
              <RadarChart data={radarData}>
                <PolarGrid stroke="hsl(var(--border))" />
                <PolarAngleAxis dataKey="area" tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 12 }} />
                <PolarRadiusAxis tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 10 }} stroke="hsl(var(--border))" domain={[0, 100]} />
                <Tooltip
                  contentStyle={{
                    background: "hsl(var(--popover))",
                    border: "1px solid hsl(var(--border))",
                    borderRadius: 12,
                  }}
                />
                <Radar name="Você" dataKey="você" stroke="hsl(var(--primary))" fill="hsl(var(--primary))" fillOpacity={0.4} />
              </RadarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="card-elevated rounded-2xl p-6">
          <h2 className="font-display text-2xl mb-1">Curva 14 dias</h2>
          <p className="text-xs text-muted-foreground mb-4">Acertos diários</p>
          <div className="h-[280px]">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={trendData}>
                <defs>
                  <linearGradient id="grad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="hsl(var(--primary))" stopOpacity={0.6} />
                    <stop offset="100%" stopColor="hsl(var(--primary))" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
                <XAxis dataKey="dia" stroke="hsl(var(--muted-foreground))" fontSize={11} />
                <YAxis stroke="hsl(var(--muted-foreground))" fontSize={11} allowDecimals={false} />
                <Tooltip
                  contentStyle={{
                    background: "hsl(var(--popover))",
                    border: "1px solid hsl(var(--border))",
                    borderRadius: 12,
                  }}
                />
                <Area type="monotone" dataKey="acertos" stroke="hsl(var(--primary-glow))" fill="url(#grad)" strokeWidth={2} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Próximas ações */}
      <div className="grid md:grid-cols-2 gap-4">
        <ActionCard
          icon={BookOpen}
          title="Sessão de questões"
          desc="Pratique com o motor adaptativo — XP a cada acerto."
          cta="Começar"
          to="/questoes"
        />
        <ActionCard
          icon={Timer}
          title="Simulado ENEM completo"
          desc="Anti-fraude ativo, TRI real ao final."
          cta="Iniciar simulado"
          to="/simulado"
        />
      </div>
    </div>
  );
}

function KpiCard({
  icon: Icon,
  label,
  value,
  accent,
  sub,
  progress,
}: {
  icon: React.ElementType;
  label: string;
  value: string;
  accent: string;
  sub: string;
  progress?: number;
}) {
  return (
    <div className="card-elevated rounded-2xl p-5">
      <div className={`flex items-center gap-2 ${accent} mb-3`}>
        <Icon className="size-4" />
        <span className="text-xs uppercase tracking-wider font-medium">{label}</span>
      </div>
      <div className="font-display text-3xl">{value}</div>
      {progress !== undefined && <Progress value={progress * 100} className="mt-3 h-1.5" />}
      <div className="text-xs text-muted-foreground mt-2">{sub}</div>
    </div>
  );
}

function ActionCard({
  icon: Icon,
  title,
  desc,
  cta,
  to,
}: {
  icon: React.ElementType;
  title: string;
  desc: string;
  cta: string;
  to: string;
}) {
  return (
    <div className="card-elevated rounded-2xl p-6 flex flex-col md:flex-row md:items-center gap-4">
      <div className="size-12 shrink-0 rounded-xl bg-primary/10 border border-primary/20 grid place-items-center">
        <Icon className="size-5 text-primary-glow" />
      </div>
      <div className="flex-1">
        <h3 className="font-display text-xl">{title}</h3>
        <p className="text-sm text-muted-foreground">{desc}</p>
      </div>
      <Button asChild variant="outline">
        <Link to={to}>{cta} <ArrowRight className="size-4" /></Link>
      </Button>
    </div>
  );
}
