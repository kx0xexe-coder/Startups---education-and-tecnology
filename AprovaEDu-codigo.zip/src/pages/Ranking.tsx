import { useEffect, useState } from "react";
import { Trophy, Crown, Flame, Medal, ArrowUp, Target } from "lucide-react";
import { cn } from "@/lib/utils";
import { useStats } from "@/lib/stats";
import { useAuth } from "@/components/AuthProvider";
import { supabase } from "@/integrations/supabase/client";

interface RankRow {
  user_id: string;
  display_name: string;
  xp: number;
  weekly_xp: number;
  streak_days: number;
}

export default function Ranking() {
  const stats = useStats();
  const { user } = useAuth();
  const displayName =
    (user?.user_metadata?.display_name as string | undefined) ??
    user?.email?.split("@")[0] ??
    "Estudante";

  const [rows, setRows] = useState<RankRow[]>([]);
  const [loading, setLoading] = useState(true);

  // próximo domingo
  const now = new Date();
  const days = (7 - now.getDay()) % 7 || 7;
  const reset = new Date(now);
  reset.setDate(now.getDate() + days);

  // Sync local stats -> DB, then reload leaderboard
  useEffect(() => {
    let cancel = false;
    async function sync() {
      if (!user) return;
      try {
        await supabase.from("user_stats").upsert(
          {
            user_id: user.id,
            display_name: displayName,
            xp: stats.xp,
            weekly_xp: stats.xp, // simple: total XP counts on the week for now
            streak_days: stats.streakDays,
            best_streak: stats.bestStreak,
            total_answered: stats.totalAnswered,
            total_correct: stats.totalCorrect,
          },
          { onConflict: "user_id" }
        );
      } catch (e) {
        console.error("sync stats", e);
      }
      const { data, error } = await supabase
        .from("user_stats")
        .select("user_id, display_name, xp, weekly_xp, streak_days")
        .order("xp", { ascending: false })
        .limit(100);
      if (!cancel) {
        if (error) console.error(error);
        setRows((data as RankRow[]) ?? []);
        setLoading(false);
      }
    }
    sync();
    return () => {
      cancel = true;
    };
  }, [user, displayName, stats.xp, stats.streakDays, stats.bestStreak, stats.totalAnswered, stats.totalCorrect]);

  const podium = rows.slice(0, 3);
  const podiumIcons = [Crown, Trophy, Medal];
  const podiumTones = ["text-warning", "text-primary", "text-accent"];

  const myIndex = user ? rows.findIndex((r) => r.user_id === user.id) : -1;
  const myRow = myIndex >= 0 ? rows[myIndex] : null;
  const nextRival = myIndex > 0 ? rows[myIndex - 1] : null;
  const gapToNext = nextRival && myRow ? Math.max(0, nextRival.xp - myRow.xp + 1) : 0;
  const leader = rows[0];
  const gapToLeader = leader && myRow ? Math.max(0, leader.xp - myRow.xp) : 0;

  return (
    <div className="container py-8 md:py-12 max-w-4xl">
      <div className="text-xs uppercase tracking-widest text-accent mb-2">
        Leaderboard global do AprovaEdu
      </div>
      <h1 className="font-display text-5xl md:text-6xl">Ranking dos estudantes</h1>
      <p className="text-muted-foreground mt-2">
        Todos os usuários competindo por XP. Reseta domingo às 23:59 —{" "}
        {reset.toLocaleDateString("pt-BR", {
          weekday: "long",
          day: "2-digit",
          month: "long",
        })}
        .
      </p>

      {loading && (
        <div className="card-elevated rounded-2xl p-8 mt-8 text-center text-muted-foreground">
          Carregando ranking...
        </div>
      )}

      {!loading && rows.length === 0 && (
        <div className="card-elevated rounded-2xl p-8 mt-8 text-center">
          <Trophy className="size-10 text-muted-foreground mx-auto mb-3" />
          <h2 className="font-display text-2xl">O ranking está começando.</h2>
          <p className="text-sm text-muted-foreground mt-2">
            Responda questões para ganhar XP e aparecer aqui.
          </p>
        </div>
      )}

      {!loading && rows.length > 0 && (
        <>
          {myRow && (
            <div className="card-elevated rounded-2xl mt-8 p-6 border-primary/40 bg-primary/5">
              <div className="grid sm:grid-cols-3 gap-4">
                <div>
                  <div className="text-xs uppercase tracking-widest text-primary-glow mb-1">Sua posição</div>
                  <div className="font-display text-4xl">#{myIndex + 1}</div>
                  <div className="text-xs text-muted-foreground mt-1">
                    de {rows.length} estudante{rows.length === 1 ? "" : "s"}
                  </div>
                </div>
                <div>
                  <div className="text-xs uppercase tracking-widest text-accent mb-1 flex items-center gap-1">
                    <ArrowUp className="size-3" /> Próximo rival
                  </div>
                  {nextRival ? (
                    <>
                      <div className="font-display text-xl truncate">{nextRival.display_name}</div>
                      <div className="text-xs text-muted-foreground mt-1">
                        Faltam <span className="text-warning font-semibold">{gapToNext.toLocaleString("pt-BR")} XP</span> para ultrapassar
                      </div>
                    </>
                  ) : (
                    <>
                      <div className="font-display text-xl">Você é o líder 👑</div>
                      <div className="text-xs text-muted-foreground mt-1">Mantenha o ritmo pra não perder o topo</div>
                    </>
                  )}
                </div>
                <div>
                  <div className="text-xs uppercase tracking-widest text-success mb-1 flex items-center gap-1">
                    <Target className="size-3" /> Para o topo
                  </div>
                  <div className="font-display text-xl">
                    {gapToLeader > 0 ? `${gapToLeader.toLocaleString("pt-BR")} XP` : "Você já está lá"}
                  </div>
                  <div className="text-xs text-muted-foreground mt-1 truncate">
                    {gapToLeader > 0 ? `Líder: ${leader.display_name}` : "Continue somando XP"}
                  </div>
                </div>
              </div>
            </div>
          )}

          {podium.length > 0 && (
            <div className="grid sm:grid-cols-3 gap-4 mt-8">
              {podium.map((u, i) => {
                const Icon = podiumIcons[i];
                return (
                  <div
                    key={u.user_id}
                    className={cn(
                      "card-elevated rounded-2xl p-6 text-center",
                      i === 0 && "md:scale-105 md:-translate-y-2 border-warning/40 sm:order-2",
                      i === 1 && "sm:order-1",
                      i === 2 && "sm:order-3"
                    )}
                  >
                    <Icon className={cn("size-6 mx-auto mb-2", podiumTones[i])} />
                    <div className="font-display text-4xl">#{i + 1}</div>
                    <div className="font-medium mt-2 truncate">
                      {u.display_name}
                      {u.user_id === user?.id && " (você)"}
                    </div>
                    <div className="font-display text-2xl text-gradient-primary mt-3">
                      {u.xp.toLocaleString("pt-BR")} XP
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          <div className="card-elevated rounded-2xl mt-6 overflow-hidden">
            <div className="px-6 py-4 border-b border-border flex items-center gap-2">
              <Trophy className="size-4 text-accent" />
              <h2 className="font-display text-xl">Ranking completo</h2>
              <span className="ml-auto text-xs text-muted-foreground">
                {rows.length} estudante{rows.length === 1 ? "" : "s"}
              </span>
            </div>
            <ul>
              {rows.map((u, idx) => {
                const you = u.user_id === user?.id;
                const isAboveMe = myIndex >= 0 && idx < myIndex;
                const xpToBeat = isAboveMe && myRow ? Math.max(0, u.xp - myRow.xp + 1) : 0;
                return (
                  <li
                    key={u.user_id}
                    className={cn(
                      "flex items-center gap-4 px-6 py-4 border-b border-border last:border-0 transition-colors",
                      you && "bg-primary/10"
                    )}
                  >
                    <div
                      className={cn(
                        "size-10 rounded-lg grid place-items-center font-display text-lg shrink-0",
                        idx < 3
                          ? "bg-gradient-primary text-primary-foreground"
                          : "bg-muted text-muted-foreground"
                      )}
                    >
                      {idx + 1}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="font-medium truncate">
                        {u.display_name}
                        {you && " (você)"}
                      </div>
                      <div className="text-xs text-muted-foreground">
                        {isAboveMe
                          ? `Faltam ${xpToBeat.toLocaleString("pt-BR")} XP para ultrapassar`
                          : u.streak_days > 0
                          ? `${u.streak_days} dia${u.streak_days === 1 ? "" : "s"} de ofensiva`
                          : "Sem ofensiva ativa"}
                      </div>
                    </div>
                    <div className="hidden sm:flex items-center gap-1 text-warning text-sm">
                      <Flame className="size-3.5" /> {u.streak_days}d
                    </div>
                    <div className="font-display text-lg w-28 text-right">
                      {u.xp.toLocaleString("pt-BR")}
                    </div>
                  </li>
                );
              })}
            </ul>

          </div>
        </>
      )}
    </div>
  );
}
