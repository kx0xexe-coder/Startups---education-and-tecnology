import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import {
  Brain,
  Timer,
  Trophy,
  LineChart,
  ShieldCheck,
  Flame,
  ArrowRight,
  Zap,
  Check,
  X,
  HelpCircle,
  Wallet,
  Users,
  Target,
  GraduationCap,
} from "lucide-react";
import { useAuth } from "@/components/AuthProvider";
import Logo, { LogoMark } from "@/components/Logo";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const features = [
  {
    icon: Brain,
    title: "IA Adaptativa",
    desc: "3 acertos seguidos? Sobe pra nível absurdo. Errou? Reforço de base no mesmo tema.",
  },
  {
    icon: Timer,
    title: "Simulador anti-fraude",
    desc: "Saiu da aba? O cronômetro pausa e o sistema te avisa. Como na prova real.",
  },
  {
    icon: LineChart,
    title: "TRI + Predição ENEM",
    desc: "Cálculo TRI ponderado pela taxa de acerto global. Sua nota estimada em tempo real.",
  },
  {
    icon: Trophy,
    title: "Ranking semanal",
    desc: "Leaderboard que zera todo domingo. Vibração de competição constante.",
  },
  {
    icon: Flame,
    title: "Streaks & XP logarítmico",
    desc: "Curva f(x) = log(x). Primeiros níveis rápidos, maestria custa caro.",
  },
  {
    icon: ShieldCheck,
    title: "Acessibilidade real",
    desc: "Upload de laudo, leitor de tela, navegação por teclado e tempo estendido.",
  },
];

export default function Landing() {
  const { session } = useAuth();
  const ctaTo = session ? "/dashboard" : "/auth";

  return (
    <div className="min-h-screen relative overflow-hidden">
      {/* Background grid */}
      <div className="absolute inset-0 grid-bg pointer-events-none" />

      {/* Header */}
      <header className="relative z-10 container flex items-center justify-between py-6">
        <Link to="/" className="flex items-center gap-2">
          <Logo size="md" />
        </Link>
        <nav className="hidden md:flex items-center gap-8 text-sm text-muted-foreground">
          <a href="#features" className="hover:text-foreground transition-colors">Recursos</a>
          <a href="#metodo" className="hover:text-foreground transition-colors">Método</a>
          <a href="#porque" className="hover:text-foreground transition-colors">Por que</a>
          <a href="#faq" className="hover:text-foreground transition-colors">FAQ</a>
          <Link to="/acessibilidade" className="hover:text-foreground transition-colors">Acessibilidade</Link>
        </nav>
        <div className="flex items-center gap-2">
          {!session && (
            <Button asChild variant="ghost" size="sm" className="hidden sm:inline-flex">
              <Link to="/auth">Entrar</Link>
            </Button>
          )}
          <Button asChild variant="default" size="sm" className="bg-gradient-primary hover:opacity-90">
            <Link to={session ? "/dashboard" : "/auth?mode=signup"}>
              {session ? "Dashboard" : "Cadastrar"} <ArrowRight className="size-4" />
            </Link>
          </Button>
        </div>
      </header>

      {/* Hero */}
      <section className="relative z-10 container py-20 md:py-32 text-center max-w-5xl">
        <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full glass text-xs text-muted-foreground mb-8 animate-fade-in">
          <Zap className="size-3 text-accent" />
          Aprovação não é sorte. É algoritmo.
        </div>

        <h1 className="font-display text-6xl md:text-8xl leading-[0.95] tracking-tight animate-slide-up">
          Estude do jeito{" "}
          <span className="italic text-gradient-primary">certo</span>
          <br />
          gabaritar é{" "}
          <span className="italic">consequência.</span>
        </h1>

        <p className="mt-8 text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto animate-slide-up [animation-delay:120ms]">
          A AprovaEDu usa IA adaptativa, simulador de alta fidelidade e analytics
          preditivo para preparar você para o ENEM e Concursos com a precisão de
          um atleta de alto rendimento.
        </p>

        <div className="mt-10 flex flex-col sm:flex-row gap-3 justify-center animate-slide-up [animation-delay:240ms]">
          <Button asChild size="lg" className="bg-gradient-primary hover:opacity-90 shadow-glow h-12 px-8">
            <Link to={session ? "/dashboard" : "/auth?mode=signup"}>
              {session ? "Continuar estudando" : "Criar conta grátis"} <ArrowRight className="size-4" />
            </Link>
          </Button>
          {!session && (
            <Button asChild size="lg" variant="outline" className="h-12 px-8">
              <Link to="/auth">Já tenho conta</Link>
            </Button>
          )}
        </div>

        {/* Stats */}
        <div className="mt-20 grid grid-cols-2 md:grid-cols-4 gap-6 max-w-3xl mx-auto animate-fade-in [animation-delay:400ms]">
          {[
            ["+120k", "questões"],
            ["98%", "fidelidade ENEM"],
            ["TRI", "real"],
            ["24/7", "leaderboard"],
          ].map(([n, l]) => (
            <div key={l} className="text-center">
              <div className="font-display text-4xl md:text-5xl text-gradient">{n}</div>
              <div className="text-xs uppercase tracking-widest text-muted-foreground mt-1">{l}</div>
            </div>
          ))}
        </div>
      </section>

      {/* Features */}
      <section id="features" className="relative z-10 container py-20">
        <div className="max-w-2xl mb-16">
          <div className="text-xs uppercase tracking-widest text-accent mb-3">Recursos</div>
          <h2 className="font-display text-5xl md:text-6xl leading-[1] tracking-tight">
            Cada detalhe pensado para
            <span className="italic text-gradient-primary"> aprovação.</span>
          </h2>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
          {features.map(({ icon: Icon, title, desc }, i) => (
            <div
              key={title}
              className="card-elevated rounded-2xl p-6 group hover:border-primary/40 transition-all duration-500 ease-out-expo hover:-translate-y-1"
              style={{ animationDelay: `${i * 80}ms` }}
            >
              <div className="size-10 rounded-lg bg-primary/10 border border-primary/20 grid place-items-center mb-4 group-hover:bg-primary/20 transition-colors">
                <Icon className="size-5 text-primary-glow" />
              </div>
              <h3 className="font-display text-2xl mb-2">{title}</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">{desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Método (editorial) */}
      <section id="metodo" className="relative z-10 container py-20">
        <div className="card-elevated rounded-3xl p-8 md:p-16 grid md:grid-cols-2 gap-12 items-center">
          <div>
            <div className="text-xs uppercase tracking-widest text-accent mb-3">Método</div>
            <h2 className="font-display text-5xl md:text-6xl leading-[1] tracking-tight">
              O cérebro da plataforma
              <span className="italic"> aprende com você.</span>
            </h2>
            <p className="mt-6 text-muted-foreground leading-relaxed">
              Nosso engine adaptativo monitora cada resposta. Acertou três difíceis
              seguidas? A próxima é nível absurdo. Errou? Você recebe uma fácil do
              mesmo assunto para reforço de base. Sem desperdício de tempo.
            </p>
            <Button asChild className="mt-8 bg-gradient-primary hover:opacity-90">
              <Link to="/questoes">Experimentar agora <ArrowRight className="size-4" /></Link>
            </Button>
          </div>
          <div className="space-y-3">
            {[
              { label: "Acertou (Difícil)", color: "bg-success" },
              { label: "Acertou (Difícil)", color: "bg-success" },
              { label: "Acertou (Difícil)", color: "bg-success" },
              { label: "Próxima: Absurdo 🔥", color: "bg-gradient-primary" },
            ].map((s, i) => (
              <div
                key={i}
                className="flex items-center gap-3 p-4 rounded-xl bg-surface-elevated border border-border animate-slide-up"
                style={{ animationDelay: `${i * 100}ms` }}
              >
                <div className={`size-2.5 rounded-full ${s.color}`} />
                <span className="text-sm">{s.label}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Por que AprovaEDU — comparação + storytelling */}
      <section id="porque" className="relative z-10 container py-20">
        <div className="max-w-3xl mb-12">
          <div className="text-xs uppercase tracking-widest text-accent mb-3">Por que AprovaEDU</div>
          <h2 className="font-display text-5xl md:text-6xl leading-[1] tracking-tight">
            Você quer passar no ENEM.
            <span className="italic text-gradient-primary"> A gente quer o mesmo.</span>
          </h2>
          <p className="mt-6 text-lg text-muted-foreground leading-relaxed">
            Cursinhos pagos custam de R$ 1.500 a R$ 8.000 por ano — e ainda assim a maioria dos
            aprovados estuda sozinho com material avulso. A AprovaEDU nasceu para acabar com isso:
            tecnologia de ponta, conteúdo completo e <span className="text-foreground font-medium">100% grátis</span>,
            porque acesso à universidade pública não pode depender da renda da sua família.
          </p>
        </div>

        {/* Personas */}
        <div className="grid md:grid-cols-3 gap-4 mb-16">
          {[
            {
              icon: Wallet,
              title: "Não tem dinheiro pro cursinho",
              desc: "Você não precisa de R$ 5 mil pra ter um plano de estudos sério. Aqui você tem TRI, simulado e analytics — de graça, pra sempre.",
            },
            {
              icon: Target,
              title: "Estuda sozinho e se perde",
              desc: "Sem saber por onde começar, você pula de matéria em matéria. Nossa IA decide o que vem depois com base no que VOCÊ erra.",
            },
            {
              icon: Users,
              title: "Quer disputar no mesmo nível",
              desc: "Quem paga cursinho tem simulado semanal, ranking e correção TRI. Você também tem. Sem mensalidade, sem letras miúdas.",
            },
          ].map(({ icon: Icon, title, desc }) => (
            <div key={title} className="card-elevated rounded-2xl p-6 hover:-translate-y-1 transition-transform duration-500 ease-out-expo">
              <div className="size-10 rounded-lg bg-primary/10 border border-primary/20 grid place-items-center mb-4">
                <Icon className="size-5 text-primary-glow" />
              </div>
              <h3 className="font-display text-2xl mb-2">{title}</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">{desc}</p>
            </div>
          ))}
        </div>

        {/* Comparação */}
        <div className="card-elevated rounded-3xl p-6 md:p-10 overflow-hidden">
          <div className="grid md:grid-cols-3 gap-6">
            <div className="md:col-span-1 flex flex-col justify-center">
              <div className="text-xs uppercase tracking-widest text-accent mb-3">Comparação honesta</div>
              <h3 className="font-display text-3xl md:text-4xl leading-tight">
                AprovaEDU vs.
                <span className="italic"> cursinho pago.</span>
              </h3>
              <p className="text-sm text-muted-foreground mt-3">
                Mesma tecnologia. Mesma seriedade. Sem a mensalidade.
              </p>
            </div>

            <div className="md:col-span-2">
              <div className="grid grid-cols-3 gap-2 text-xs uppercase tracking-widest text-muted-foreground pb-3 border-b border-border">
                <div>Recurso</div>
                <div className="text-center text-primary-glow">AprovaEDU</div>
                <div className="text-center">Plataformas pagas</div>
              </div>
              {[
                ["Preço", "Grátis", "R$ 1.500 – R$ 8.000/ano"],
                ["IA adaptativa por erro", true, "raramente"],
                ["Predição de nota TRI real", true, "às vezes"],
                ["Simulador anti-fraude", true, true],
                ["Ranking semanal", true, "extra pago"],
                ["Acessibilidade c/ laudo", true, "limitado"],
                ["Biblioteca direcionada ao erro", true, false],
              ].map(([label, ours, theirs], i) => (
                <div key={i} className="grid grid-cols-3 gap-2 py-3 border-b border-border/50 items-center text-sm">
                  <div className="text-foreground/90">{label}</div>
                  <div className="text-center">
                    {typeof ours === "boolean" ? (
                      ours ? <Check className="size-4 text-success inline" /> : <X className="size-4 text-destructive inline" />
                    ) : (
                      <span className="text-primary-glow font-medium">{ours}</span>
                    )}
                  </div>
                  <div className="text-center text-muted-foreground">
                    {typeof theirs === "boolean" ? (
                      theirs ? <Check className="size-4 text-muted-foreground inline" /> : <X className="size-4 text-destructive/70 inline" />
                    ) : (
                      <span>{theirs}</span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section id="faq" className="relative z-10 container py-20">
        <div className="grid md:grid-cols-[1fr_1.4fr] gap-12">
          <div className="md:sticky md:top-24 self-start">
            <div className="text-xs uppercase tracking-widest text-accent mb-3 flex items-center gap-2">
              <HelpCircle className="size-3" /> Perguntas frequentes
            </div>
            <h2 className="font-display text-5xl md:text-6xl leading-[1] tracking-tight">
              Tudo que você quer saber
              <span className="italic text-gradient-primary"> antes de criar a conta.</span>
            </h2>
            <p className="mt-6 text-muted-foreground leading-relaxed">
              Sem letras miúdas, sem trial de 7 dias virando boleto. Resposta direta pra cada dúvida real de quem está se preparando pro ENEM.
            </p>
            <Button asChild size="lg" className="mt-8 bg-gradient-primary hover:opacity-90 shadow-glow">
              <Link to={session ? "/dashboard" : "/auth?mode=signup"}>
                {session ? "Voltar ao painel" : "Começar grátis agora"} <ArrowRight className="size-4" />
              </Link>
            </Button>
          </div>

          <Accordion type="single" collapsible className="card-elevated rounded-2xl px-6 md:px-8 py-2">
            {[
              {
                q: "A AprovaEDU é realmente grátis ou tem pegadinha?",
                a: "É 100% grátis. Sem cartão de crédito no cadastro, sem trial, sem versão premium escondida. A plataforma existe para democratizar a preparação pro ENEM — qualquer estudante de escola pública ou particular acessa o mesmo conteúdo, com a mesma tecnologia.",
              },
              {
                q: "Por que eu usaria a AprovaEDU em vez de um cursinho pago?",
                a: "Porque você tem aqui as três coisas que cursinhos cobram caro: (1) correção TRI real, igual a do ENEM; (2) IA que adapta a dificuldade ao seu erro, sem te fazer perder tempo no que já sabe; (3) simulador de alta fidelidade que pausa se você sair da aba. Cursinho custa de R$ 1.500 a R$ 8.000/ano para entregar quase isso.",
              },
              {
                q: "Funciona se eu estudo sozinho e nunca fiz um simulado de verdade?",
                a: "Sim — e foi pensada exatamente para você. Tudo começa zerado. Conforme você responde questões, a plataforma constrói seu mapa de conhecimento, sua ofensiva diária, sua predição de nota ENEM e te recomenda exatamente o assunto da biblioteca que você precisa revisar.",
              },
              {
                q: "Como a IA decide o que eu estudo?",
                a: "Cada questão tem um peso TRI. Se você acerta 3 difíceis seguidas no mesmo assunto, a próxima vai pra nível absurdo. Se você erra, a IA te devolve uma questão fácil daquele tópico + sugere o material da biblioteca. Sem desperdício de tempo com o que você já domina.",
              },
              {
                q: "Como vocês calculam minha nota estimada no ENEM?",
                a: "Usamos a fórmula TRI ponderada pela sua taxa de acerto global — a mesma lógica do INEP. Quanto mais questões você responde, mais a predição se calibra. Você vê em tempo real como seus estudos estão movendo sua nota possível.",
              },
              {
                q: "Eu tenho laudo de TDAH / dislexia / baixa visão. Vocês me atendem?",
                a: "Sim. A página de Acessibilidade permite upload do seu laudo, ativa tempo estendido nos simulados, leitor de tela, alto contraste e navegação por teclado completa. Tudo como na prova real.",
              },
              {
                q: "Vou ficar sozinho ou tem competição de verdade?",
                a: "Tem ranking semanal que zera todo domingo. Você compete em XP, ofensiva e acertos com outros estudantes do Brasil inteiro. Saudável, viciante e gratuito.",
              },
              {
                q: "E se eu já uso outra plataforma paga?",
                a: "Use as duas. A AprovaEDU não exige exclusividade. Só te garantimos que, ao terminar um bloco de questões aqui, você sai sabendo exatamente o que errou, por quê, e qual material revisar. Compare e veja.",
              },
            ].map((item, i) => (
              <AccordionItem key={i} value={`item-${i}`} className="border-b border-border/60 last:border-b-0">
                <AccordionTrigger className="text-left font-display text-lg md:text-xl hover:no-underline">
                  {item.q}
                </AccordionTrigger>
                <AccordionContent className="text-muted-foreground leading-relaxed text-base">
                  {item.a}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      </section>

      {/* CTA final */}
      <section className="relative z-10 container py-20">
        <div className="card-elevated rounded-3xl p-10 md:p-16 text-center bg-gradient-to-br from-primary/10 via-transparent to-accent/10">
          <GraduationCap className="size-10 text-primary-glow mx-auto mb-6" />
          <h2 className="font-display text-4xl md:text-6xl leading-[1] tracking-tight max-w-3xl mx-auto">
            Sua vaga na federal não devia
            <span className="italic text-gradient-primary"> custar mensalidade.</span>
          </h2>
          <p className="mt-6 text-muted-foreground max-w-xl mx-auto">
            Crie sua conta grátis em 30 segundos e comece a contabilizar XP, ofensiva e nota TRI agora.
          </p>
          <Button asChild size="lg" className="mt-8 bg-gradient-primary hover:opacity-90 shadow-glow h-12 px-8">
            <Link to={session ? "/dashboard" : "/auth?mode=signup"}>
              {session ? "Continuar estudando" : "Criar conta grátis"} <ArrowRight className="size-4" />
            </Link>
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="relative z-10 container py-12 border-t border-border mt-20">
        <div className="flex flex-col md:flex-row gap-4 items-center justify-between text-sm text-muted-foreground">
          <div className="flex items-center gap-2">
            <LogoMark size="sm" />
            AprovaEDU © {new Date().getFullYear()} — Aprovação por algoritmo.
          </div>
          <div className="flex gap-6">
            <Link to="/acessibilidade" className="hover:text-foreground">Acessibilidade</Link>
            <a href="#features" className="hover:text-foreground">Recursos</a>
            <a href="#faq" className="hover:text-foreground">FAQ</a>
          </div>
        </div>
      </footer>
    </div>
  );
}
