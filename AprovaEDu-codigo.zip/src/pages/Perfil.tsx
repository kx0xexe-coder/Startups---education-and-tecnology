import { useEffect, useState } from "react";
import { useAuth } from "@/components/AuthProvider";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { User, Mail, Save, LogOut, UserPlus } from "lucide-react";
import { useNavigate } from "react-router-dom";

export default function Perfil() {
  const { user, signOut } = useAuth();
  const navigate = useNavigate();
  const [displayName, setDisplayName] = useState("");
  const [loading, setLoading] = useState(false);
  const [initialName, setInitialName] = useState("");

  useEffect(() => {
    if (!user) return;
    (async () => {
      const { data } = await supabase
        .from("profiles")
        .select("display_name")
        .eq("id", user.id)
        .maybeSingle();
      const name =
        data?.display_name ??
        (user.user_metadata?.display_name as string | undefined) ??
        "";
      setDisplayName(name);
      setInitialName(name);
    })();
  }, [user]);

  async function handleSave() {
    if (!user) return;
    if (displayName.trim().length < 2) {
      toast.error("Nome muito curto");
      return;
    }
    setLoading(true);
    try {
      const { error: pErr } = await supabase
        .from("profiles")
        .update({ display_name: displayName.trim() })
        .eq("id", user.id);
      if (pErr) throw pErr;

      const { error: uErr } = await supabase.auth.updateUser({
        data: { display_name: displayName.trim() },
      });
      if (uErr) throw uErr;

      setInitialName(displayName.trim());
      toast.success("Perfil atualizado");
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Erro desconhecido";
      toast.error("Falha ao salvar", { description: msg });
    } finally {
      setLoading(false);
    }
  }

  async function handleAddAccount() {
    await supabase.auth.signOut();
    navigate("/auth", { state: { addAccount: true } });
  }

  return (
    <div className="container py-8 md:py-12 max-w-3xl space-y-8">
      <div>
        <div className="text-xs uppercase tracking-widest text-accent mb-2">Conta</div>
        <h1 className="font-display text-5xl md:text-6xl leading-none">
          Meu <span className="italic text-gradient-primary">perfil</span>
        </h1>
        <p className="text-muted-foreground mt-2">
          Gerencie seus dados pessoais e o acesso à sua conta.
        </p>
      </div>

      <section className="card-elevated rounded-2xl p-6 md:p-8 space-y-6">
        <h2 className="font-display text-2xl">Dados pessoais</h2>

        <div className="space-y-2">
          <Label htmlFor="name" className="text-xs uppercase tracking-wider text-muted-foreground">
            Nome completo
          </Label>
          <div className="relative">
            <User className="size-4 text-muted-foreground absolute left-3 top-1/2 -translate-y-1/2" />
            <Input
              id="name"
              value={displayName}
              onChange={(e) => setDisplayName(e.target.value)}
              placeholder="Seu nome completo"
              className="pl-10"
            />
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="email" className="text-xs uppercase tracking-wider text-muted-foreground">
            E-mail cadastrado
          </Label>
          <div className="relative">
            <Mail className="size-4 text-muted-foreground absolute left-3 top-1/2 -translate-y-1/2" />
            <Input
              id="email"
              value={user?.email ?? ""}
              readOnly
              disabled
              className="pl-10 opacity-80"
            />
          </div>
          <p className="text-xs text-muted-foreground">
            O e-mail é vinculado ao login e não pode ser alterado por aqui.
          </p>
        </div>

        <Button
          onClick={handleSave}
          disabled={loading || displayName.trim() === initialName.trim()}
          className="bg-gradient-primary hover:opacity-90 shadow-glow"
        >
          <Save className="size-4" />
          {loading ? "Salvando…" : "Salvar alterações"}
        </Button>
      </section>

      <section className="card-elevated rounded-2xl p-6 md:p-8 space-y-4">
        <h2 className="font-display text-2xl">Sessão</h2>
        <p className="text-sm text-muted-foreground">
          Saia desta conta ou faça login com outra para alternar entre perfis.
        </p>
        <div className="flex flex-col sm:flex-row gap-3">
          <Button variant="outline" onClick={handleAddAccount}>
            <UserPlus className="size-4" /> Adicionar outra conta
          </Button>
          <Button variant="destructive" onClick={signOut}>
            <LogOut className="size-4" /> Sair da conta
          </Button>
        </div>
      </section>
    </div>
  );
}
