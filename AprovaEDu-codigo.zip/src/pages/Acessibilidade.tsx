import { useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Heart, Upload, FileCheck2, Eye, Keyboard, Volume2, Clock, ShieldCheck, X, Trash2, Clock3, CheckCircle2, XCircle } from "lucide-react";
import { toast } from "sonner";
import { z } from "zod";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/components/AuthProvider";
import { cn } from "@/lib/utils";
import { useAccessibility } from "@/components/AccessibilityProvider";
import { Sparkles } from "lucide-react";

const recursos = [
  { icon: Eye, title: "Alto contraste & dislexia", desc: "Modo visual ajustável e fonte amigável para dislexia." },
  { icon: Keyboard, title: "Navegação por teclado", desc: "Tab, setas, Enter — toda a plataforma sem mouse." },
  { icon: Volume2, title: "Leitor de tela", desc: "Marcação ARIA semântica, roles e labels descritivas." },
  { icon: Clock, title: "Tempo estendido", desc: "Cronômetros adaptados conforme o laudo aprovado." },
];

const formSchema = z.object({
  fullName: z.string().trim().min(2, { message: "Nome muito curto" }).max(120),
  cid: z.string().trim().max(40).optional().or(z.literal("")),
  consent: z.literal(true, { errorMap: () => ({ message: "Você precisa autorizar a LGPD" }) }),
});

interface ReportRow {
  id: string;
  full_name: string;
  cid: string | null;
  file_name: string;
  file_size_bytes: number;
  status: "pending" | "approved" | "rejected";
  created_at: string;
  file_path: string;
}

const MAX_BYTES = 10 * 1024 * 1024;
const VALID_TYPES = ["application/pdf", "image/png", "image/jpeg"];

export default function Acessibilidade() {
  const { user } = useAuth();
  const { profile, refresh } = useAccessibility();
  const [file, setFile] = useState<File | null>(null);
  const [fullName, setFullName] = useState("");
  const [cid, setCid] = useState("");
  const [consent, setConsent] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [reports, setReports] = useState<ReportRow[]>([]);
  const [loading, setLoading] = useState(true);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (!user) { setLoading(false); return; }
    loadReports();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.id]);

  async function loadReports() {
    setLoading(true);
    const { data, error } = await supabase
      .from("medical_reports")
      .select("id, full_name, cid, file_name, file_size_bytes, status, created_at, file_path")
      .order("created_at", { ascending: false });
    if (error) toast.error("Erro ao carregar laudos", { description: error.message });
    setReports(data ?? []);
    setLoading(false);
  }

  function handleFile(f: File | null) {
    if (!f) return;
    if (f.size > MAX_BYTES) {
      toast.error("Arquivo muito grande", { description: "Limite de 10 MB." });
      return;
    }
    if (!VALID_TYPES.includes(f.type)) {
      toast.error("Formato inválido", { description: "Aceitamos PDF, PNG ou JPG." });
      return;
    }
    setFile(f);
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!user) {
      toast.error("Faça login para enviar o laudo");
      return;
    }
    if (!file) {
      toast.error("Selecione o arquivo do laudo");
      return;
    }
    const parsed = formSchema.safeParse({ fullName, cid, consent });
    if (!parsed.success) {
      toast.error(parsed.error.issues[0].message);
      return;
    }

    setSubmitting(true);
    const safeName = file.name.replace(/[^\w.\-]+/g, "_");
    const path = `${user.id}/${Date.now()}-${safeName}`;
    try {
      const { error: upErr } = await supabase.storage
        .from("medical-reports")
        .upload(path, file, { contentType: file.type, upsert: false });
      if (upErr) throw upErr;

      const { error: insErr } = await supabase.from("medical_reports").insert({
        user_id: user.id,
        full_name: parsed.data.fullName,
        cid: parsed.data.cid || null,
        file_path: path,
        file_name: file.name,
        file_size_bytes: file.size,
        mime_type: file.type,
        consent_lgpd: true,
      });
      if (insErr) {
        // rollback file
        await supabase.storage.from("medical-reports").remove([path]);
        throw insErr;
      }

      toast.success("Laudo enviado", { description: "Análise em até 48h." });
      setFile(null);
      setFullName("");
      setCid("");
      setConsent(false);
      if (inputRef.current) inputRef.current.value = "";
      loadReports();
      refresh();
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : "Erro inesperado";
      toast.error("Falha no envio", { description: msg });
    } finally {
      setSubmitting(false);
    }
  }

  async function deleteReport(r: ReportRow) {
    if (!confirm(`Remover o laudo "${r.file_name}"?`)) return;
    const { error: stErr } = await supabase.storage.from("medical-reports").remove([r.file_path]);
    if (stErr) toast.error("Erro ao remover arquivo", { description: stErr.message });
    const { error } = await supabase.from("medical_reports").delete().eq("id", r.id);
    if (error) {
      toast.error("Erro ao remover", { description: error.message });
      return;
    }
    toast.success("Laudo removido");
    loadReports();
    refresh();
  }

  return (
    <div className="container py-8 md:py-12 max-w-5xl">
      {/* Hero */}
      <div className="card-elevated rounded-3xl p-8 md:p-12 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-transparent to-accent/10 pointer-events-none" />
        <div className="relative">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full glass text-xs text-accent mb-6">
            <Heart className="size-3" />
            Acessibilidade & Neurodiversidade
          </div>
          <h1 className="font-display text-5xl md:text-6xl leading-[1] max-w-3xl">
            Estudo adaptado para
            <span className="italic text-gradient-primary"> cada cérebro.</span>
          </h1>
          <p className="text-muted-foreground mt-6 max-w-2xl leading-relaxed">
            A AprovaEDu acredita que aprovação não tem fórmula única. Pessoas neurodivergentes —
            TDAH, TEA, dislexia, discalculia, entre outras — podem enviar seu laudo médico para
            ativar recursos personalizados de tempo, interface e correção.
          </p>
        </div>
      </div>

      {/* Status de personalização ativa */}
      {profile.active && (
        <div className="card-elevated rounded-2xl p-6 mt-8 border-success/40 bg-success/5">
          <div className="flex items-center gap-3 mb-3">
            <div className="size-10 rounded-xl bg-success/15 grid place-items-center">
              <Sparkles className="size-5 text-success" />
            </div>
            <div>
              <div className="text-xs uppercase tracking-widest text-success">Personalização ativa</div>
              <h2 className="font-display text-2xl">Estudo adaptado para {profile.label}</h2>
            </div>
          </div>
          <ul className="grid sm:grid-cols-2 gap-2 mt-2">
            {profile.adaptations.map((a) => (
              <li key={a} className="text-sm text-muted-foreground flex items-start gap-2">
                <CheckCircle2 className="size-4 text-success mt-0.5 shrink-0" />
                <span>{a}</span>
              </li>
            ))}
          </ul>
        </div>
      )}
      {profile.status === "pending" && profile.analysisEndsAt && (
        <div className="card-elevated rounded-2xl p-6 mt-8 border-warning/40 bg-warning/5 flex items-center gap-4">
          <Clock3 className="size-6 text-warning shrink-0" />
          <div>
            <div className="text-xs uppercase tracking-widest text-warning">Em análise</div>
            <p className="text-sm text-muted-foreground mt-1">
              Sua personalização será ativada automaticamente até{" "}
              <strong>{new Date(profile.analysisEndsAt).toLocaleString("pt-BR")}</strong>.
            </p>
          </div>
        </div>
      )}

      {/* Recursos */}
      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4 mt-8">

        {recursos.map(({ icon: Icon, title, desc }) => (
          <div key={title} className="card-elevated rounded-2xl p-5">
            <div className="size-10 rounded-lg bg-primary/10 border border-primary/20 grid place-items-center mb-3">
              <Icon className="size-5 text-primary-glow" />
            </div>
            <h3 className="font-display text-xl">{title}</h3>
            <p className="text-xs text-muted-foreground mt-1 leading-relaxed">{desc}</p>
          </div>
        ))}
      </div>

      {/* Upload + sidebar */}
      <div className="grid lg:grid-cols-[1.2fr_1fr] gap-6 mt-8">
        <form onSubmit={submit} className="card-elevated rounded-2xl p-8">
          <div className="flex items-center gap-2 text-accent text-xs uppercase tracking-widest mb-3">
            <ShieldCheck className="size-3.5" />
            Envio seguro e confidencial
          </div>
          <h2 className="font-display text-3xl">Enviar laudo médico</h2>
          <p className="text-sm text-muted-foreground mt-2">
            PDF, PNG ou JPG · até 10 MB. Análise em 48h. Apenas nossa equipe clínica tem acesso.
          </p>

          <label
            htmlFor="laudo"
            className="mt-6 block cursor-pointer rounded-2xl border-2 border-dashed border-border hover:border-primary/60 hover:bg-primary/5 transition-all p-8 text-center"
            onDragOver={(e) => e.preventDefault()}
            onDrop={(e) => {
              e.preventDefault();
              handleFile(e.dataTransfer.files?.[0] ?? null);
            }}
          >
            <input
              ref={inputRef}
              id="laudo"
              type="file"
              accept="application/pdf,image/png,image/jpeg"
              className="sr-only"
              onChange={(e) => handleFile(e.target.files?.[0] ?? null)}
              aria-label="Upload do laudo médico"
            />
            {!file ? (
              <>
                <div className="size-12 mx-auto rounded-full bg-primary/10 grid place-items-center mb-3">
                  <Upload className="size-5 text-primary-glow" />
                </div>
                <div className="font-medium">Clique ou arraste seu laudo aqui</div>
                <div className="text-xs text-muted-foreground mt-1">PDF, PNG, JPG · máx 10 MB</div>
              </>
            ) : (
              <div className="flex items-center gap-3 justify-center">
                <FileCheck2 className="size-6 text-success" />
                <div className="text-left">
                  <div className="font-medium">{file.name}</div>
                  <div className="text-xs text-muted-foreground">{(file.size / 1024).toFixed(1)} KB</div>
                </div>
                <button
                  type="button"
                  onClick={(e) => { e.preventDefault(); setFile(null); if (inputRef.current) inputRef.current.value = ""; }}
                  className="ml-2 text-muted-foreground hover:text-destructive"
                  aria-label="Remover arquivo"
                >
                  <X className="size-4" />
                </button>
              </div>
            )}
          </label>

          <div className="mt-4 grid sm:grid-cols-2 gap-3">
            <Field label="Nome completo" id="nome" value={fullName} onChange={(e) => setFullName(e.target.value)} placeholder="Seu nome" required />
            <Field label="Diagnóstico (CID)" id="cid" value={cid} onChange={(e) => setCid(e.target.value)} placeholder="Ex: F90.0 (TDAH)" />
          </div>

          <label className="flex items-start gap-2 mt-4 text-xs text-muted-foreground">
            <input
              type="checkbox"
              checked={consent}
              onChange={(e) => setConsent(e.target.checked)}
              className="mt-0.5 accent-[hsl(var(--primary))]"
              required
            />
            <span>Autorizo a AprovaEDu a tratar os dados deste laudo conforme a LGPD, exclusivamente para adaptação de recursos.</span>
          </label>

          <Button
            type="submit"
            disabled={submitting || !user}
            size="lg"
            className="mt-6 w-full bg-gradient-primary hover:opacity-90 shadow-glow"
          >
            {!user ? "Entre para enviar" : submitting ? "Enviando…" : "Enviar para análise"}
          </Button>
        </form>

        <aside className="space-y-4">
          <div className="card-elevated rounded-2xl p-6">
            <h3 className="font-display text-2xl mb-3">Como funciona</h3>
            <ol className="space-y-3">
              {[
                "Você envia o laudo (PDF/foto).",
                "Nossa equipe clínica valida em até 48h.",
                "Recursos adaptados são ativados na sua conta.",
                "Você pode atualizar ou remover quando quiser.",
              ].map((p, i) => (
                <li key={i} className="flex gap-3 text-sm">
                  <span className="size-6 rounded-full bg-gradient-primary text-primary-foreground grid place-items-center font-bold text-xs shrink-0">
                    {i + 1}
                  </span>
                  <span className="text-muted-foreground">{p}</span>
                </li>
              ))}
            </ol>
          </div>

          <div className="card-elevated rounded-2xl p-6 border-success/30">
            <div className="flex items-center gap-2 text-success text-xs uppercase tracking-widest mb-2">
              <ShieldCheck className="size-3.5" />
              Privacidade
            </div>
            <p className="text-sm text-muted-foreground leading-relaxed">
              Criptografia em repouso. Bucket privado com acesso apenas pelo dono do laudo.
            </p>
          </div>
        </aside>
      </div>

      {/* Histórico */}
      {user && (
        <div className="card-elevated rounded-2xl mt-8 overflow-hidden">
          <div className="px-6 py-4 border-b border-border flex items-center gap-2">
            <FileCheck2 className="size-4 text-primary-glow" />
            <h2 className="font-display text-xl">Seus laudos enviados</h2>
          </div>
          {loading ? (
            <div className="p-6 text-sm text-muted-foreground">Carregando…</div>
          ) : reports.length === 0 ? (
            <div className="p-6 text-sm text-muted-foreground">Nenhum laudo enviado ainda.</div>
          ) : (
            <ul>
              {reports.map((r) => (
                <li key={r.id} className="flex items-center gap-4 px-6 py-4 border-b border-border last:border-0">
                  <StatusPill status={r.status} />
                  <div className="flex-1 min-w-0">
                    <div className="font-medium truncate">{r.file_name}</div>
                    <div className="text-xs text-muted-foreground">
                      {r.full_name}{r.cid ? ` · ${r.cid}` : ""} · {(r.file_size_bytes / 1024).toFixed(1)} KB
                    </div>
                  </div>
                  <div className="text-xs text-muted-foreground hidden sm:block">
                    {new Date(r.created_at).toLocaleDateString("pt-BR")}
                  </div>
                  <Button variant="ghost" size="icon" onClick={() => deleteReport(r)} aria-label="Remover laudo">
                    <Trash2 className="size-4 text-muted-foreground hover:text-destructive" />
                  </Button>
                </li>
              ))}
            </ul>
          )}
        </div>
      )}
    </div>
  );
}

function StatusPill({ status }: { status: ReportRow["status"] }) {
  const map = {
    pending: { label: "Em análise", icon: Clock3, cls: "bg-warning/15 text-warning border-warning/30" },
    approved: { label: "Aprovado", icon: CheckCircle2, cls: "bg-success/15 text-success border-success/30" },
    rejected: { label: "Rejeitado", icon: XCircle, cls: "bg-destructive/15 text-destructive border-destructive/30" },
  }[status];
  const Icon = map.icon;
  return (
    <span className={cn("inline-flex items-center gap-1.5 text-xs px-2.5 py-1 rounded-md border", map.cls)}>
      <Icon className="size-3" />
      {map.label}
    </span>
  );
}

function Field({ label, id, ...rest }: React.InputHTMLAttributes<HTMLInputElement> & { label: string; id: string }) {
  return (
    <div>
      <label htmlFor={id} className="text-xs uppercase tracking-wider text-muted-foreground">
        {label}
      </label>
      <input
        id={id}
        {...rest}
        className="mt-1 w-full rounded-lg bg-input border border-border px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-ring focus:border-primary transition-all"
      />
    </div>
  );
}
