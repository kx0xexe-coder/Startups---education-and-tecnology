import { useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { questions, materias, bancas, dificuldadeLabel, Difficulty, Question } from "@/data/questions";
import { applyExclusion, ExclusionFilter, nextDifficulty, triScore } from "@/lib/engine";
import { findMaterialsForQuestion } from "@/data/library";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { CheckCircle2, XCircle, Filter, Sparkles, ArrowRight, Brain, BookMarked, RotateCcw, Flag } from "lucide-react";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import { recordAnswer } from "@/lib/stats";

const allDifficulties: Difficulty[] = ["facil", "media", "dificil", "absurdo"];

export default function Questoes() {
  const [filter, setFilter] = useState<ExclusionFilter>({
    excludedMaterias: [],
    excludedDifficulties: [],
    excludedBancas: [],
    excludedTags: [],
  });
  const [currentDifficulty, setCurrentDifficulty] = useState<Difficulty>("media");
  const [streak, setStreak] = useState(0);
  const [xpEarned, setXpEarned] = useState(0);
  const [index, setIndex] = useState(0);
  const [selected, setSelected] = useState<string | null>(null);
  const [revealed, setRevealed] = useState(false);
  const [answeredCount, setAnsweredCount] = useState(0);
  const [wrongIds, setWrongIds] = useState<string[]>([]);
  const [reviewPool, setReviewPool] = useState<Question[] | null>(null);
  const [finished, setFinished] = useState(false);

  const pool = useMemo(() => {
    if (reviewPool) return reviewPool;
    const filtered = applyExclusion(questions, filter);
    const ofLevel = filtered.filter((q) => q.dificuldade === currentDifficulty);
    return ofLevel.length > 0 ? ofLevel : filtered;
  }, [filter, currentDifficulty, reviewPool]);

  const question = pool[index % Math.max(pool.length, 1)];

  if (!question) {
    return (
      <div className="container py-12">
        <div className="card-elevated rounded-2xl p-12 text-center">
          <h2 className="font-display text-3xl">Sem questões disponíveis</h2>
          <p className="text-muted-foreground mt-2">Reduza os filtros de exclusão para continuar.</p>
        </div>
      </div>
    );
  }

  const acertou = revealed && selected === question.corretaId;

  function answer(optId: string) {
    if (revealed) return;
    setSelected(optId);
    setRevealed(true);
    setAnsweredCount((c) => c + 1);
    const correct = optId === question.corretaId;
    const xp = correct ? triScore(question, true) : 0;
    recordAnswer({ materia: question.materia, correct, xp });
    if (correct) {
      setWrongIds((w) => w.filter((id) => id !== question.id));
      const novoStreak = streak + 1;
      setStreak(novoStreak);
      setXpEarned((p) => p + xp);
      toast.success(`+${xp} XP`, { description: "Boa! Resposta correta." });
      const next = nextDifficulty(currentDifficulty, novoStreak, false);
      if (next !== currentDifficulty) {
        toast(`Subindo nível: ${dificuldadeLabel[next]} 🔥`);
        setCurrentDifficulty(next);
        setStreak(0);
      }
    } else {
      setStreak(0);
      setWrongIds((w) => (w.includes(question.id) ? w : [...w, question.id]));
      const next = nextDifficulty(currentDifficulty, 0, true);
      toast.error("Errou", { description: "Vamos reforçar a base nesse assunto." });
      if (next !== currentDifficulty) {
        setCurrentDifficulty(next);
      }
    }
  }

  function nextQuestion() {
    setIndex((i) => i + 1);
    setSelected(null);
    setRevealed(false);
  }

  function finalizar() {
    setFinished(true);
  }

  function refazerErradas() {
    const erradas = questions.filter((q) => wrongIds.includes(q.id));
    if (erradas.length === 0) {
      toast("Você não tem questões erradas para refazer.");
      return;
    }
    setReviewPool(erradas);
    setIndex(0);
    setSelected(null);
    setRevealed(false);
    setFinished(false);
    setAnsweredCount(0);
    toast.success(`Refazendo ${erradas.length} questão(ões) errada(s)`);
  }

  function reiniciar() {
    setReviewPool(null);
    setWrongIds([]);
    setAnsweredCount(0);
    setXpEarned(0);
    setStreak(0);
    setIndex(0);
    setSelected(null);
    setRevealed(false);
    setFinished(false);
  }

  if (finished) {
    const erradas = questions.filter((q) => wrongIds.includes(q.id));
    const materiasErradas = Array.from(new Set(erradas.map((q) => q.materia)));
    const materiaisRecomendados = Array.from(
      new Map(
        erradas.flatMap((q) => findMaterialsForQuestion(q.id)).map((m) => [m.id, m])
      ).values()
    );
    const focoParam = materiaisRecomendados.map((m) => m.id).join(",");
    const matsParam = materiasErradas.join(",");

    return (
      <div className="container py-12 max-w-3xl">
        <div className="card-elevated rounded-3xl p-8 md:p-12 animate-scale-in">
          <div className="text-xs uppercase tracking-widest text-accent mb-2 text-center">
            Sessão finalizada
          </div>
          <h1 className="font-display text-4xl md:text-5xl text-center">Bom trabalho!</h1>
          <div className="grid grid-cols-3 gap-3 mt-8">
            <div className="rounded-xl bg-surface-elevated border border-border p-4 text-center">
              <div className="text-xs uppercase text-muted-foreground">Respondidas</div>
              <div className="font-display text-3xl mt-1">{answeredCount}</div>
            </div>
            <div className="rounded-xl bg-surface-elevated border border-border p-4 text-center">
              <div className="text-xs uppercase text-muted-foreground">Erradas</div>
              <div className="font-display text-3xl mt-1 text-destructive">{erradas.length}</div>
            </div>
            <div className="rounded-xl bg-surface-elevated border border-border p-4 text-center">
              <div className="text-xs uppercase text-muted-foreground">XP</div>
              <div className="font-display text-3xl mt-1 text-primary-glow">{xpEarned}</div>
            </div>
          </div>

          {erradas.length > 0 && (
            <div className="mt-8 p-5 rounded-2xl border border-primary/30 bg-primary/5">
              <div className="flex items-center gap-2 mb-2">
                <BookMarked className="size-4 text-primary-glow" />
                <h3 className="font-display text-xl">Rever material das questões</h3>
              </div>
              <p className="text-sm text-muted-foreground mb-3">
                Identificamos {materiaisRecomendados.length} material(is) ligado(s) ao
                que você errou em {materiasErradas.join(", ")}.
              </p>
              <ul className="text-sm space-y-1 mb-4">
                {materiaisRecomendados.slice(0, 4).map((m) => (
                  <li key={m.id} className="text-foreground/90">• {m.titulo}</li>
                ))}
              </ul>
              <Button asChild className="bg-gradient-primary hover:opacity-90">
                <Link to={`/biblioteca?foco=${focoParam}&materias=${matsParam}`}>
                  Rever material das questões <ArrowRight className="size-4" />
                </Link>
              </Button>
            </div>
          )}

          <div className="mt-6 flex flex-wrap gap-3 justify-center">
            <Button onClick={refazerErradas} variant="outline" disabled={erradas.length === 0}>
              <RotateCcw className="size-4" />
              Refazer questões erradas ({erradas.length})
            </Button>
            <Button onClick={reiniciar} variant="ghost">
              Nova sessão
            </Button>
            <Button asChild variant="outline">
              <Link to="/biblioteca">
                <BookMarked className="size-4" /> Abrir biblioteca
              </Link>
            </Button>
          </div>
        </div>
      </div>
    );
  }

  function toggleExclude<K extends keyof ExclusionFilter>(key: K, value: string) {
    setFilter((f) => {
      const list = f[key] as string[];
      const next = list.includes(value) ? list.filter((v) => v !== value) : [...list, value];
      return { ...f, [key]: next } as ExclusionFilter;
    });
  }

  return (
    <div className="container py-8 md:py-12 grid lg:grid-cols-[1fr_320px] gap-6">
      {/* Question card */}
      <div className="space-y-4">
        <div className="flex items-center justify-between flex-wrap gap-3">
          <div className="flex items-center gap-2 flex-wrap">
            <Badge variant="outline" className="border-primary/40 text-primary-glow">
              <Brain className="size-3" /> Adaptativo
            </Badge>
            <Badge variant="outline">{question.materia}</Badge>
            <Badge variant="outline">{question.banca} {question.ano}</Badge>
            <Badge
              className={cn(
                "border-0",
                question.dificuldade === "facil" && "bg-success/20 text-success",
                question.dificuldade === "media" && "bg-warning/20 text-warning",
                question.dificuldade === "dificil" && "bg-primary/20 text-primary-glow",
                question.dificuldade === "absurdo" && "bg-gradient-primary text-primary-foreground"
              )}
            >
              {dificuldadeLabel[question.dificuldade]}
            </Badge>
          </div>
          <div className="text-xs text-muted-foreground flex items-center gap-3">
            <span>Streak <span className="text-warning font-semibold">{streak}</span></span>
            <span>XP <span className="text-primary-glow font-semibold">{xpEarned}</span></span>
          </div>
        </div>

        <article className="card-elevated rounded-2xl p-6 md:p-10 animate-scale-in">
          <p className="font-display text-xl md:text-2xl leading-relaxed">{question.enunciado}</p>

          <ul className="mt-8 space-y-3" role="radiogroup" aria-label="Alternativas">
            {question.opcoes.map((opt) => {
              const isSelected = selected === opt.id;
              const isCorrect = revealed && opt.id === question.corretaId;
              const isWrong = revealed && isSelected && !isCorrect;
              return (
                <li key={opt.id}>
                  <button
                    role="radio"
                    aria-checked={isSelected}
                    onClick={() => answer(opt.id)}
                    disabled={revealed}
                    className={cn(
                      "w-full text-left rounded-xl border p-4 flex items-start gap-4 transition-all duration-300 ease-out-expo focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
                      "border-border bg-surface-elevated hover:border-primary/40 hover:translate-x-0.5",
                      isSelected && !revealed && "border-primary bg-primary/10",
                      isCorrect && "border-success bg-success/10",
                      isWrong && "border-destructive bg-destructive/10"
                    )}
                  >
                    <span className={cn(
                      "size-8 shrink-0 rounded-lg border grid place-items-center font-display text-lg",
                      isCorrect ? "border-success text-success" : isWrong ? "border-destructive text-destructive" : "border-border text-muted-foreground"
                    )}>
                      {opt.id.toUpperCase()}
                    </span>
                    <span className="flex-1 pt-1">{opt.texto}</span>
                    {isCorrect && <CheckCircle2 className="size-5 text-success mt-1" />}
                    {isWrong && <XCircle className="size-5 text-destructive mt-1" />}
                  </button>
                </li>
              );
            })}
          </ul>

          {revealed && (
            <div className={cn(
              "mt-6 p-5 rounded-xl border animate-slide-up",
              acertou ? "border-success/40 bg-success/5" : "border-primary/40 bg-primary/5"
            )}>
              <div className="flex items-center gap-2 text-sm font-medium mb-2">
                <Sparkles className="size-4 text-accent" />
                Comentário do professor
              </div>
              <p className="text-sm text-muted-foreground leading-relaxed">{question.comentario}</p>
              {!acertou && (
                <div className="mt-3">
                  <Button asChild size="sm" variant="outline">
                    <Link to={`/biblioteca?foco=${findMaterialsForQuestion(question.id).map((m) => m.id).join(",")}&materias=${question.materia}`}>
                      <BookMarked className="size-4" /> Rever material desta questão
                    </Link>
                  </Button>
                </div>
              )}
            </div>
          )}

          {revealed && (
            <div className="mt-6 flex flex-wrap justify-between gap-3">
              <Button onClick={finalizar} variant="outline">
                <Flag className="size-4" /> Finalizar
              </Button>
              <Button onClick={nextQuestion} size="lg" className="bg-gradient-primary hover:opacity-90">
                Próxima questão <ArrowRight className="size-4" />
              </Button>
            </div>
          )}
        </article>
      </div>

      {/* Filter sidebar */}
      <aside className="space-y-4 lg:sticky lg:top-6 self-start">
        <div className="card-elevated rounded-2xl p-5">
          <div className="flex items-center gap-2 mb-4">
            <Filter className="size-4 text-primary-glow" />
            <h3 className="font-display text-xl">Filtro por exclusão</h3>
          </div>
          <p className="text-xs text-muted-foreground mb-4">
            Marque o que você <em>não</em> quer ver.
          </p>

          <FilterGroup
            title="Matérias"
            options={[...materias]}
            excluded={filter.excludedMaterias}
            onToggle={(v) => toggleExclude("excludedMaterias", v)}
          />
          <FilterGroup
            title="Dificuldade"
            options={allDifficulties}
            labels={dificuldadeLabel}
            excluded={filter.excludedDifficulties}
            onToggle={(v) => toggleExclude("excludedDifficulties", v)}
          />
          <FilterGroup
            title="Bancas"
            options={[...bancas]}
            excluded={filter.excludedBancas}
            onToggle={(v) => toggleExclude("excludedBancas", v)}
          />
        </div>

        <div className="card-elevated rounded-2xl p-5 bg-gradient-to-br from-primary/10 to-transparent border-primary/30">
          <div className="text-xs uppercase tracking-widest text-accent mb-2">Nível atual</div>
          <div className="font-display text-3xl">{dificuldadeLabel[currentDifficulty]}</div>
          <p className="text-xs text-muted-foreground mt-2">
            3 acertos seguidos sobem o nível. Erro reforça a base.
          </p>
        </div>
      </aside>
    </div>
  );
}

function FilterGroup<T extends string>({
  title,
  options,
  excluded,
  labels,
  onToggle,
}: {
  title: string;
  options: T[];
  excluded: string[];
  labels?: Record<string, string>;
  onToggle: (v: T) => void;
}) {
  return (
    <div className="mb-4">
      <div className="text-xs uppercase tracking-wider text-muted-foreground mb-2">{title}</div>
      <div className="flex flex-wrap gap-1.5">
        {options.map((o) => {
          const isExcluded = excluded.includes(o);
          return (
            <button
              key={o}
              onClick={() => onToggle(o)}
              className={cn(
                "px-2.5 py-1 rounded-md text-xs border transition-all",
                isExcluded
                  ? "border-destructive/40 bg-destructive/10 text-destructive line-through"
                  : "border-border text-foreground hover:border-primary/40"
              )}
            >
              {labels?.[o] ?? o}
            </button>
          );
        })}
      </div>
    </div>
  );
}
