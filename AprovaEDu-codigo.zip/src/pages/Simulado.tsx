import { useEffect, useRef, useState } from "react";
import { questions } from "@/data/questions";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { AlertTriangle, Pause, Play, ShieldCheck, Timer as TimerIcon, CheckCircle2 } from "lucide-react";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import { recordSimulado } from "@/lib/stats";
import { useAccessibility } from "@/components/AccessibilityProvider";

const STORAGE_KEY = "educazero-simulado-state";
const BASE_SECONDS = 60 * 30; // 30 min base

interface State {
  answers: Record<string, string>;
  remaining: number;
  current: number;
  finished: boolean;
}

const initial = (totalSeconds: number): State => ({ answers: {}, remaining: totalSeconds, current: 0, finished: false });

export default function Simulado() {
  const { profile } = useAccessibility();
  const totalSeconds = Math.round(BASE_SECONDS * profile.timeMultiplier);
  const [state, setState] = useState<State>(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) return JSON.parse(raw) as State;
    } catch {}
    return initial(totalSeconds);
  });
  const [paused, setPaused] = useState(false);
  const [tabSwitches, setTabSwitches] = useState(0);
  const tickRef = useRef<number | null>(null);

  // Persist
  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  }, [state]);

  // Timer
  useEffect(() => {
    if (paused || state.finished) return;
    tickRef.current = window.setInterval(() => {
      setState((s) => {
        if (s.remaining <= 1) {
          return { ...s, remaining: 0, finished: true };
        }
        return { ...s, remaining: s.remaining - 1 };
      });
    }, 1000);
    return () => {
      if (tickRef.current) window.clearInterval(tickRef.current);
    };
  }, [paused, state.finished]);

  // Anti-fraude: pausa ao sair da aba
  useEffect(() => {
    function onVisibility() {
      if (document.hidden && !state.finished) {
        setPaused(true);
        setTabSwitches((c) => c + 1);
        toast.warning("Cronômetro pausado", {
          description: "Você saiu da aba. O sistema registrou.",
        });
      }
    }
    document.addEventListener("visibilitychange", onVisibility);
    return () => document.removeEventListener("visibilitychange", onVisibility);
  }, [state.finished]);

  const q = questions[state.current % questions.length];
  const answered = Object.keys(state.answers).length;
  const progress = (answered / questions.length) * 100;

  const mins = Math.floor(state.remaining / 60).toString().padStart(2, "0");
  const secs = (state.remaining % 60).toString().padStart(2, "0");

  function answer(optId: string) {
    setState((s) => ({ ...s, answers: { ...s.answers, [q.id]: optId } }));
  }

  function go(delta: number) {
    setState((s) => ({
      ...s,
      current: Math.max(0, Math.min(questions.length - 1, s.current + delta)),
    }));
  }

  function finish() {
    setState((s) => ({ ...s, finished: true }));
  }

  function reset() {
    localStorage.removeItem(STORAGE_KEY);
    setState(initial(totalSeconds));
    setTabSwitches(0);
    setPaused(false);
  }

  if (state.finished) {
    const corretas = questions.filter((qq) => state.answers[qq.id] === qq.corretaId).length;
    const taxa = (corretas / questions.length) * 100;
    const notaTri = Math.round(400 + taxa * 4);
    // Persist result once
    if (!(state as any)._recorded) {
      recordSimulado({ corretas, total: questions.length, notaTri });
      (state as any)._recorded = true;
    }
    return (
      <div className="container py-12 max-w-3xl">
        <div className="card-elevated rounded-3xl p-12 text-center animate-scale-in">
          <CheckCircle2 className="size-12 text-success mx-auto mb-4" />
          <div className="text-xs uppercase tracking-widest text-accent mb-2">Simulado finalizado</div>
          <h1 className="font-display text-5xl">Sua nota TRI estimada</h1>
          <div className="font-display text-8xl text-gradient-primary my-6">{notaTri}</div>
          <div className="grid grid-cols-3 gap-4 mt-8">
            <Stat label="Acertos" value={`${corretas}/${questions.length}`} />
            <Stat label="Taxa" value={`${taxa.toFixed(0)}%`} />
            <Stat label="Trocas de aba" value={tabSwitches.toString()} />
          </div>
          <Button onClick={reset} className="mt-8 bg-gradient-primary hover:opacity-90" size="lg">
            Refazer simulado
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="container py-6 md:py-8 max-w-4xl">
      {/* HUD */}
      <div className="card-elevated rounded-2xl p-4 mb-6 sticky top-4 z-30 backdrop-blur-xl">
        <div className="flex items-center justify-between gap-4 flex-wrap">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <TimerIcon className="size-4 text-primary-glow" />
              <span className={cn("font-display text-2xl tabular-nums", state.remaining < 60 && "text-destructive")}>
                {mins}:{secs}
              </span>
            </div>
            <div className="hidden sm:flex items-center gap-2 text-xs text-success">
              <ShieldCheck className="size-3.5" /> Anti-fraude ativo
            </div>
            {profile.active && profile.timeMultiplier > 1 && (
              <div className="hidden md:flex items-center gap-1.5 text-xs text-accent bg-accent/10 border border-accent/30 px-2 py-1 rounded-md">
                +{Math.round((profile.timeMultiplier - 1) * 100)}% tempo · {profile.label}
              </div>
            )}
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs text-muted-foreground">{answered}/{questions.length}</span>
            <Button size="sm" variant="outline" onClick={() => setPaused((p) => !p)}>
              {paused ? <Play className="size-4" /> : <Pause className="size-4" />}
              {paused ? "Continuar" : "Pausar"}
            </Button>
            <Button size="sm" onClick={finish} className="bg-gradient-primary hover:opacity-90">
              Finalizar
            </Button>
          </div>
        </div>
        <Progress value={progress} className="mt-3 h-1" />
      </div>

      {paused && (
        <div className="card-elevated rounded-2xl p-6 mb-6 border-warning/40 bg-warning/5 flex items-center gap-3 animate-fade-in">
          <AlertTriangle className="size-5 text-warning" />
          <div className="flex-1 text-sm">
            <strong>Pausado.</strong> Trocas de aba registradas: {tabSwitches}.
          </div>
          <Button size="sm" onClick={() => setPaused(false)}>Voltar</Button>
        </div>
      )}

      <article className="card-elevated rounded-2xl p-6 md:p-10">
        <div className="text-xs uppercase tracking-widest text-muted-foreground mb-3">
          Questão {state.current + 1} · {q.materia}
        </div>
        <p className="font-display text-xl md:text-2xl leading-relaxed">{q.enunciado}</p>

        <ul className="mt-8 space-y-3">
          {q.opcoes.map((opt) => {
            const isSelected = state.answers[q.id] === opt.id;
            return (
              <li key={opt.id}>
                <button
                  onClick={() => answer(opt.id)}
                  className={cn(
                    "w-full text-left rounded-xl border p-4 flex items-start gap-4 transition-all",
                    "border-border bg-surface-elevated hover:border-primary/40",
                    isSelected && "border-primary bg-primary/10"
                  )}
                >
                  <span className={cn(
                    "size-8 shrink-0 rounded-lg border grid place-items-center font-display text-lg",
                    isSelected ? "border-primary text-primary-glow" : "border-border text-muted-foreground"
                  )}>
                    {opt.id.toUpperCase()}
                  </span>
                  <span className="flex-1 pt-1">{opt.texto}</span>
                </button>
              </li>
            );
          })}
        </ul>

        <div className="mt-8 flex items-center justify-between">
          <Button variant="outline" onClick={() => go(-1)} disabled={state.current === 0}>
            Anterior
          </Button>
          <Button onClick={() => go(1)} disabled={state.current === questions.length - 1} className="bg-gradient-primary hover:opacity-90">
            Próxima
          </Button>
        </div>
      </article>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl bg-surface-elevated border border-border p-4">
      <div className="text-xs uppercase tracking-wider text-muted-foreground">{label}</div>
      <div className="font-display text-2xl mt-1">{value}</div>
    </div>
  );
}
