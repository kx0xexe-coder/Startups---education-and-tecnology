import { useEffect, useMemo, useRef, useState } from "react";
import { useSearchParams, Link } from "react-router-dom";
import { library } from "@/data/library";
import { materias } from "@/data/questions";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { BookMarked, Search, ArrowRight } from "lucide-react";
import { cn } from "@/lib/utils";

export default function Biblioteca() {
  const [params] = useSearchParams();
  const destaqueRef = useRef<HTMLElement | null>(null);
  const focoIds = (params.get("foco") ?? "").split(",").filter(Boolean);
  const focoMaterias = (params.get("materias") ?? "").split(",").filter(Boolean);

  const [filtroMateria, setFiltroMateria] = useState<string | null>(
    focoMaterias[0] ?? null
  );
  const [busca, setBusca] = useState("");

  const filtrada = useMemo(() => {
    return library.filter((m) => {
      if (filtroMateria && m.materia !== filtroMateria) return false;
      if (busca) {
        const q = busca.toLowerCase();
        if (
          !m.titulo.toLowerCase().includes(q) &&
          !m.resumo.toLowerCase().includes(q) &&
          !m.tags.some((t) => t.toLowerCase().includes(q))
        )
          return false;
      }
      return true;
    });
  }, [filtroMateria, busca]);

  const destaque = focoIds.length > 0 ? library.filter((m) => focoIds.includes(m.id)) : [];

  useEffect(() => {
    if (destaque.length > 0 && destaqueRef.current) {
      destaqueRef.current.scrollIntoView({ behavior: "smooth", block: "start" });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [focoIds.join(",")]);


  return (
    <div className="container py-8 md:py-12 max-w-5xl">
      <div className="flex items-center gap-3 mb-2">
        <BookMarked className="size-6 text-primary-glow" />
        <h1 className="font-display text-4xl md:text-5xl">Biblioteca</h1>
      </div>
      <p className="text-muted-foreground mb-8">
        Materiais de estudo organizados por assunto. Use antes dos simulados ou
        para revisar questões que você errou.
      </p>

      {destaque.length > 0 && (
        <section ref={destaqueRef} className="mb-8 scroll-mt-24">
          <div className="text-xs uppercase tracking-widest text-accent mb-3">
            Recomendado para você
          </div>
          <div className="grid gap-3">
            {destaque.map((m) => (
              <MaterialCard key={m.id} material={m} highlight defaultOpen />
            ))}
          </div>
        </section>
      )}

      {/* Filtros */}
      <div className="card-elevated rounded-2xl p-4 mb-6 flex flex-wrap items-center gap-3">
        <div className="flex items-center gap-2 flex-1 min-w-[200px]">
          <Search className="size-4 text-muted-foreground" />
          <input
            value={busca}
            onChange={(e) => setBusca(e.target.value)}
            placeholder="Buscar assunto, tag..."
            className="flex-1 bg-transparent outline-none text-sm"
          />
        </div>
        <div className="flex flex-wrap gap-1.5">
          <button
            onClick={() => setFiltroMateria(null)}
            className={cn(
              "px-2.5 py-1 rounded-md text-xs border transition-all",
              !filtroMateria
                ? "border-primary bg-primary/10 text-primary-glow"
                : "border-border text-muted-foreground hover:border-primary/40"
            )}
          >
            Todas
          </button>
          {materias.map((mat) => (
            <button
              key={mat}
              onClick={() => setFiltroMateria(mat)}
              className={cn(
                "px-2.5 py-1 rounded-md text-xs border transition-all",
                filtroMateria === mat
                  ? "border-primary bg-primary/10 text-primary-glow"
                  : "border-border text-muted-foreground hover:border-primary/40"
              )}
            >
              {mat}
            </button>
          ))}
        </div>
      </div>

      <div className="grid gap-3">
        {filtrada.map((m) => (
          <MaterialCard key={m.id} material={m} />
        ))}
        {filtrada.length === 0 && (
          <div className="card-elevated rounded-2xl p-10 text-center text-muted-foreground">
            Nenhum material encontrado.
          </div>
        )}
      </div>

      <div className="mt-10 flex flex-wrap gap-3 justify-center">
        <Button asChild variant="outline">
          <Link to="/questoes">
            Ir para Questões <ArrowRight className="size-4" />
          </Link>
        </Button>
        <Button asChild className="bg-gradient-primary hover:opacity-90">
          <Link to="/simulado">
            Iniciar simulado <ArrowRight className="size-4" />
          </Link>
        </Button>
      </div>
    </div>
  );
}

function MaterialCard({
  material,
  highlight,
  defaultOpen,
}: {
  material: (typeof library)[number];
  highlight?: boolean;
  defaultOpen?: boolean;
}) {
  const [open, setOpen] = useState(!!defaultOpen);
  return (
    <article
      className={cn(
        "card-elevated rounded-2xl p-5 transition-all",
        highlight && "border-primary/40 bg-primary/5"
      )}
    >
      <div className="flex items-start justify-between gap-4 flex-wrap">
        <div className="flex-1 min-w-[220px]">
          <div className="flex items-center gap-2 mb-2 flex-wrap">
            <Badge variant="outline">{material.materia}</Badge>
            {material.tags.slice(0, 3).map((t) => (
              <Badge key={t} variant="outline" className="text-xs">
                {t}
              </Badge>
            ))}
          </div>
          <h3 className="font-display text-xl">{material.titulo}</h3>
          <p className="text-sm text-muted-foreground mt-1">{material.resumo}</p>
        </div>
        <Button size="sm" variant="outline" onClick={() => setOpen((o) => !o)}>
          {open ? "Recolher" : "Ler material"}
        </Button>
      </div>
      {open && (
        <div className="mt-4 p-4 rounded-xl bg-surface-elevated border border-border text-sm leading-relaxed animate-fade-in whitespace-pre-line">
          {material.conteudo}
        </div>
      )}
    </article>
  );
}
