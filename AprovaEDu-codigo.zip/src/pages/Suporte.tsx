import { useEffect, useRef, useState } from "react";
import { Headset, Send, Loader2, Sparkles, LifeBuoy, CheckCircle2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card } from "@/components/ui/card";
import { useAuth } from "@/components/AuthProvider";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { z } from "zod";

type ChatMsg = { role: "user" | "assistant"; content: string };

const ticketSchema = z.object({
  subject: z.string().trim().min(3, "Mínimo 3 caracteres").max(120),
  message: z.string().trim().min(10, "Conte um pouco mais (mín. 10)").max(2000),
});

export default function Suporte() {
  const { user } = useAuth();
  const [messages, setMessages] = useState<ChatMsg[]>([
    { role: "assistant", content: "Olá! 👋 Sou o suporte do **AprovaEDU**. Posso ajudar com dúvidas sobre a plataforma, conteúdos do ENEM, redação, técnicas de estudo ou acessibilidade. Como posso te ajudar hoje?" },
  ]);
  const [input, setInput] = useState("");
  const [sending, setSending] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages, sending]);

  async function sendChat() {
    const text = input.trim();
    if (!text || sending) return;
    const next = [...messages, { role: "user" as const, content: text }];
    setMessages(next);
    setInput("");
    setSending(true);

    try {
      const url = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/support-chat`;
      const resp = await fetch(url, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY}`,
        },
        body: JSON.stringify({ messages: next.map(({ role, content }) => ({ role, content })) }),
      });

      if (!resp.ok || !resp.body) {
        const err = await resp.json().catch(() => ({}));
        throw new Error(err.error || "Falha no suporte. Tente novamente.");
      }

      const reader = resp.body.getReader();
      const dec = new TextDecoder();
      let buf = "";
      let assistant = "";
      setMessages((m) => [...m, { role: "assistant", content: "" }]);

      while (true) {
        const { value, done } = await reader.read();
        if (done) break;
        buf += dec.decode(value, { stream: true });
        const lines = buf.split("\n");
        buf = lines.pop() ?? "";
        for (const line of lines) {
          if (!line.startsWith("data: ")) continue;
          const payload = line.slice(6);
          if (payload === "[DONE]") continue;
          try {
            const json = JSON.parse(payload);
            const delta = json.choices?.[0]?.delta?.content;
            if (delta) {
              assistant += delta;
              setMessages((m) => {
                const copy = [...m];
                copy[copy.length - 1] = { role: "assistant", content: assistant };
                return copy;
              });
            }
          } catch { /* ignore partial */ }
        }
      }
    } catch (e) {
      toast.error((e as Error).message || "Erro ao falar com o suporte");
      setMessages((m) => m.slice(0, -1));
    } finally {
      setSending(false);
    }
  }

  // Ticket form
  const [tSubject, setTSubject] = useState("");
  const [tMessage, setTMessage] = useState("");
  const [tSending, setTSending] = useState(false);

  async function sendTicket() {
    if (!user) { toast.error("Faça login para enviar uma mensagem"); return; }
    const parsed = ticketSchema.safeParse({ subject: tSubject, message: tMessage });
    if (!parsed.success) { toast.error(parsed.error.issues[0].message); return; }
    setTSending(true);
    const { error } = await supabase.from("support_messages").insert({
      user_id: user.id, subject: parsed.data.subject, message: parsed.data.message,
    });
    setTSending(false);
    if (error) { toast.error(error.message); return; }
    toast.success("Mensagem enviada! Nossa equipe responderá em breve.");
    setTSubject(""); setTMessage("");
  }

  return (
    <div className="p-4 md:p-8 max-w-6xl mx-auto space-y-6">
      <header className="space-y-1">
        <div className="flex items-center gap-2 text-primary">
          <Headset className="size-5" />
          <span className="text-xs font-medium uppercase tracking-wider">Suporte online</span>
        </div>
        <h1 className="font-display text-3xl md:text-4xl">Como podemos te ajudar?</h1>
        <p className="text-muted-foreground">Tire dúvidas com nosso assistente em tempo real ou fale com a equipe.</p>
      </header>

      <div className="grid lg:grid-cols-[1.4fr_1fr] gap-6">
        <Card className="flex flex-col h-[560px] overflow-hidden">
          <div className="px-4 py-3 border-b border-border flex items-center gap-2">
            <Sparkles className="size-4 text-primary" />
            <span className="text-sm font-medium">Assistente AprovaEDU</span>
            <span className="ml-auto text-xs text-muted-foreground flex items-center gap-1">
              <span className="size-2 rounded-full bg-emerald-500 animate-pulse" /> online
            </span>
          </div>
          <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-3">
            {messages.map((m, i) => (
              <div key={i} className={m.role === "user" ? "flex justify-end" : "flex justify-start"}>
                <div className={
                  m.role === "user"
                    ? "max-w-[85%] rounded-2xl rounded-br-sm bg-primary text-primary-foreground px-3.5 py-2 text-sm whitespace-pre-wrap"
                    : "max-w-[85%] text-sm whitespace-pre-wrap text-foreground/90"
                }>{m.content || (sending && i === messages.length - 1 ? "…" : "")}</div>
              </div>
            ))}
            {sending && messages[messages.length - 1]?.role === "user" && (
              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                <Loader2 className="size-3 animate-spin" /> escrevendo…
              </div>
            )}
          </div>
          <form
            onSubmit={(e) => { e.preventDefault(); sendChat(); }}
            className="border-t border-border p-3 flex gap-2"
          >
            <Input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Escreva sua dúvida…"
              disabled={sending}
              maxLength={1000}
            />
            <Button type="submit" disabled={sending || !input.trim()} size="icon" aria-label="Enviar">
              {sending ? <Loader2 className="size-4 animate-spin" /> : <Send className="size-4" />}
            </Button>
          </form>
        </Card>

        <Card className="p-5 space-y-4">
          <div className="flex items-center gap-2 text-primary">
            <LifeBuoy className="size-4" />
            <span className="text-sm font-medium">Falar com a equipe</span>
          </div>
          <p className="text-sm text-muted-foreground">
            Problemas de conta, bugs ou sugestões? Envie pra gente — respondemos por e-mail.
          </p>
          {!user ? (
            <div className="text-sm text-muted-foreground rounded-lg border border-dashed border-border p-3">
              Faça login para abrir um chamado.
            </div>
          ) : (
            <div className="space-y-3">
              <Input
                placeholder="Assunto"
                value={tSubject}
                onChange={(e) => setTSubject(e.target.value)}
                maxLength={120}
              />
              <Textarea
                placeholder="Descreva sua situação…"
                value={tMessage}
                onChange={(e) => setTMessage(e.target.value)}
                rows={6}
                maxLength={2000}
              />
              <Button onClick={sendTicket} disabled={tSending} className="w-full">
                {tSending ? <Loader2 className="size-4 animate-spin" /> : <CheckCircle2 className="size-4" />}
                Enviar mensagem
              </Button>
            </div>
          )}
        </Card>
      </div>
    </div>
  );
}
