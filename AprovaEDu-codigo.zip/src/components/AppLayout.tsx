import { Link, NavLink, Outlet, useLocation, useNavigate } from "react-router-dom";
import {
  LayoutDashboard,
  BookOpen,
  BookMarked,
  Timer,
  Trophy,
  LineChart,
  Heart,
  Headset,
  MessageSquareHeart,
  MessageCircle,
  Flame,
  LogOut,
  UserPlus,
  UserCog,
  ChevronUp,
} from "lucide-react";
import { usePresenceHeartbeat } from "@/hooks/usePresence";
import { useChatNotifications } from "@/hooks/useChatNotifications";
import { useChatUnread, useChatUnreadTracker } from "@/hooks/useChatUnread";
import { cn } from "@/lib/utils";
import { useAuth } from "./AuthProvider";
import { Button } from "./ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "./ui/dropdown-menu";
import { supabase } from "@/integrations/supabase/client";
import Logo, { LogoMark } from "./Logo";

const nav = [
  { to: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { to: "/questoes", label: "Questões", icon: BookOpen },
  { to: "/biblioteca", label: "Biblioteca", icon: BookMarked },
  { to: "/simulado", label: "Simulado", icon: Timer },
  { to: "/ranking", label: "Ranking", icon: Trophy },
  { to: "/chat", label: "Bate-papo", icon: MessageCircle },
  { to: "/analytics", label: "Analytics", icon: LineChart },
  { to: "/feedbacks", label: "Feedbacks", icon: MessageSquareHeart },
  { to: "/suporte", label: "Suporte", icon: Headset },
  { to: "/acessibilidade", label: "Acessibilidade", icon: Heart },
];

export default function AppLayout() {
  usePresenceHeartbeat();
  useChatNotifications();
  useChatUnreadTracker();
  const { total: chatUnread } = useChatUnread();
  const location = useLocation();
  const navigate = useNavigate();
  const { user, signOut } = useAuth();
  const initial = (user?.user_metadata?.display_name as string | undefined)?.[0]?.toUpperCase()
    ?? user?.email?.[0]?.toUpperCase()
    ?? "?";
  const name = (user?.user_metadata?.display_name as string | undefined) ?? user?.email ?? "Estudante";

  async function handleAddAccount() {
    await supabase.auth.signOut();
    navigate("/auth", { state: { addAccount: true } });
  }

  const accountMenu = (
    <DropdownMenuContent align="end" side="top" className="w-60">
      <DropdownMenuLabel className="flex flex-col">
        <span className="truncate">{name}</span>
        <span className="text-xs font-normal text-muted-foreground truncate">
          {user?.email}
        </span>
      </DropdownMenuLabel>
      <DropdownMenuSeparator />
      <DropdownMenuItem onClick={() => navigate("/perfil")}>
        <UserCog className="size-4" /> Meu perfil
      </DropdownMenuItem>
      <DropdownMenuItem onClick={handleAddAccount}>
        <UserPlus className="size-4" /> Adicionar outra conta
      </DropdownMenuItem>
      <DropdownMenuSeparator />
      <DropdownMenuItem
        onClick={signOut}
        className="text-destructive focus:text-destructive"
      >
        <LogOut className="size-4" /> Sair da conta
      </DropdownMenuItem>
    </DropdownMenuContent>
  );

  return (
    <div className="min-h-screen flex">
      {/* Sidebar */}
      <aside className="hidden lg:flex w-64 shrink-0 flex-col border-r border-border bg-sidebar/60 backdrop-blur-xl sticky top-0 h-screen">
        <Link to="/" className="px-6 py-6 flex items-center gap-2 border-b border-sidebar-border">
          <Logo size="md" />
        </Link>

        <nav className="flex-1 p-3 space-y-1">
          {nav.map(({ to, label, icon: Icon }) => {
            const badge = to === "/chat" && chatUnread > 0 ? chatUnread : 0;
            return (
              <NavLink
                key={to}
                to={to}
                className={({ isActive }) =>
                  cn(
                    "flex items-center gap-3 px-3 py-2.5 rounded-md text-sm transition-all duration-300 ease-out-expo",
                    isActive
                      ? "bg-sidebar-accent text-sidebar-accent-foreground shadow-card"
                      : "text-sidebar-foreground hover:bg-sidebar-accent/50 hover:translate-x-0.5"
                  )
                }
              >
                <Icon className="size-4" />
                <span className="flex-1">{label}</span>
                {badge > 0 && (
                  <span className="ml-auto min-w-5 h-5 px-1.5 rounded-full bg-primary text-primary-foreground text-[10px] font-medium grid place-items-center">
                    {badge > 99 ? "99+" : badge}
                  </span>
                )}
              </NavLink>
            );
          })}
        </nav>

        <div className="m-3 p-4 rounded-xl card-elevated">
          <div className="flex items-center gap-2 text-warning">
            <Flame className="size-4" />
            <span className="text-xs font-medium uppercase tracking-wider">Ofensiva</span>
          </div>
          <div className="font-display text-3xl mt-1">14 dias</div>
          <p className="text-xs text-muted-foreground mt-1">Estude hoje para manter</p>
        </div>

        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <button
              className="m-3 p-3 rounded-xl card-elevated flex items-center gap-3 text-left hover:bg-sidebar-accent/40 transition-colors"
              aria-label="Abrir menu da conta"
            >
              <div className="size-9 rounded-full bg-gradient-primary grid place-items-center font-display text-lg text-primary-foreground shrink-0">
                {initial}
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-sm font-medium truncate">{name}</div>
                <div className="text-xs text-muted-foreground truncate">{user?.email}</div>
              </div>
              <ChevronUp className="size-4 text-muted-foreground shrink-0" />
            </button>
          </DropdownMenuTrigger>
          {accountMenu}
        </DropdownMenu>
      </aside>

      <main className="flex-1 min-w-0">
        {/* Mobile header */}
        <header className="lg:hidden sticky top-0 z-40 glass border-b border-border px-4 py-3 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-2">
            <Logo size="sm" />
          </Link>
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1 text-warning text-sm">
              <Flame className="size-4" /> 14
            </div>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button
                  variant="ghost"
                  size="icon"
                  className="size-8 rounded-full bg-gradient-primary text-primary-foreground font-display"
                  aria-label="Abrir menu da conta"
                >
                  {initial}
                </Button>
              </DropdownMenuTrigger>
              {accountMenu}
            </DropdownMenu>
          </div>
        </header>
        <div key={location.pathname} className="animate-fade-in">
          <Outlet />
        </div>

        {/* Mobile bottom nav */}
        <nav className="lg:hidden sticky bottom-0 z-40 glass border-t border-border overflow-x-auto">
          <div className="flex min-w-max">
            {nav.map(({ to, icon: Icon, label }) => {
              const badge = to === "/chat" && chatUnread > 0 ? chatUnread : 0;
              return (
                <NavLink
                  key={to}
                  to={to}
                  className={({ isActive }) =>
                    cn(
                      "relative flex flex-col items-center gap-1 py-2.5 px-4 text-[10px] shrink-0",
                      isActive ? "text-primary" : "text-muted-foreground"
                    )
                  }
                >
                  <Icon className="size-4" />
                  <span className="truncate">{label}</span>
                  {badge > 0 && (
                    <span className="absolute top-1 right-2 min-w-4 h-4 px-1 rounded-full bg-primary text-primary-foreground text-[9px] font-medium grid place-items-center">
                      {badge > 9 ? "9+" : badge}
                    </span>
                  )}
                </NavLink>
              );
            })}
          </div>
        </nav>
      </main>
    </div>
  );
}
