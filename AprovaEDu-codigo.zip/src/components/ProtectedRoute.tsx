import { Navigate, useLocation } from "react-router-dom";
import { useAuth } from "./AuthProvider";
import { Sparkles } from "lucide-react";

export default function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const { session, loading } = useAuth();
  const location = useLocation();

  if (loading) {
    return (
      <div className="min-h-screen grid place-items-center">
        <div className="flex items-center gap-3 text-muted-foreground animate-pulse">
          <Sparkles className="size-5 text-primary-glow" />
          <span className="font-display text-xl">Carregando…</span>
        </div>
      </div>
    );
  }

  if (!session) {
    return <Navigate to="/auth" state={{ from: location.pathname }} replace />;
  }

  return <>{children}</>;
}
