import { cn } from "@/lib/utils";
import logoSrc from "@/assets/logo.png";

interface LogoProps {
  className?: string;
  size?: "sm" | "md" | "lg";
  showWordmark?: boolean;
}

const sizeMap = {
  sm: { box: "size-7", text: "text-xl" },
  md: { box: "size-9", text: "text-2xl" },
  lg: { box: "size-12", text: "text-3xl" },
};

export function LogoMark({ className, size = "md" }: { className?: string; size?: LogoProps["size"] }) {
  const s = sizeMap[size!];
  return (
    <div
      className={cn(
        s.box,
        "relative rounded-xl overflow-hidden shadow-glow shrink-0",
        className,
      )}
      aria-hidden
    >
      <img
        src={logoSrc}
        alt=""
        className="w-full h-full object-cover"
        draggable={false}
      />
    </div>
  );
}

export default function Logo({ className, size = "md", showWordmark = true }: LogoProps) {
  const s = sizeMap[size];
  return (
    <div className={cn("flex items-center gap-2.5", className)}>
      <LogoMark size={size} />
      {showWordmark && (
        <span className={cn("font-display tracking-tight leading-none", s.text)}>
          Aprova<span className="text-gradient-primary italic">EDU</span>
        </span>
      )}
    </div>
  );
}
