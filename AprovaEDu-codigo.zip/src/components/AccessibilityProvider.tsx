import { createContext, useContext, useEffect, type ReactNode } from "react";
import { useAccessibilityProfile, type AccessibilityProfile } from "@/lib/accessibility";

interface Ctx {
  profile: AccessibilityProfile;
  loading: boolean;
  refresh: () => void;
}

const AccessibilityContext = createContext<Ctx | null>(null);

export function AccessibilityProvider({ children }: { children: ReactNode }) {
  const value = useAccessibilityProfile();
  const { profile } = value;

  useEffect(() => {
    const root = document.documentElement;
    root.classList.toggle("a11y-dyslexia", profile.dyslexiaFont);
    root.classList.toggle("a11y-calm", profile.calmMode);
    root.classList.toggle("a11y-focus", profile.focusMode);
    return () => {
      root.classList.remove("a11y-dyslexia", "a11y-calm", "a11y-focus");
    };
  }, [profile.dyslexiaFont, profile.calmMode, profile.focusMode]);

  return <AccessibilityContext.Provider value={value}>{children}</AccessibilityContext.Provider>;
}

export function useAccessibility() {
  const ctx = useContext(AccessibilityContext);
  if (!ctx) {
    // Safe fallback if used outside provider
    return {
      profile: {
        active: false,
        neurotype: null,
        label: "Padrão",
        timeMultiplier: 1,
        dyslexiaFont: false,
        calmMode: false,
        focusMode: false,
        mathScaffold: false,
        adaptations: [],
        analysisEndsAt: null,
        status: "none",
      } as AccessibilityProfile,
      loading: false,
      refresh: () => {},
    };
  }
  return ctx;
}
