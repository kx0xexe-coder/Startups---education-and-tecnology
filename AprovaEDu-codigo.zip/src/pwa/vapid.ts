// Public VAPID key — safe to expose. Paired with the private key stored as a backend secret.
export const VAPID_PUBLIC_KEY =
  "BDo5TyNzbwLx9RsOD1zujUa4FZCxa6whtc7hRjEcDxGulEOshrMuNw9HTnLqDX1tx1YTgP_xJsjJe9yW1pRpAn8";

export function urlBase64ToUint8Array(base64String: string): Uint8Array {
  const padding = "=".repeat((4 - (base64String.length % 4)) % 4);
  const base64 = (base64String + padding).replace(/-/g, "+").replace(/_/g, "/");
  const raw = atob(base64);
  const output = new Uint8Array(raw.length);
  for (let i = 0; i < raw.length; ++i) output[i] = raw.charCodeAt(i);
  return output;
}
