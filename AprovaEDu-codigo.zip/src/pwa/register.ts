import { registerSW } from "virtual:pwa-register";
import { toast } from "sonner";

const SW_URL = "/sw.js";

function isRefusedContext(): boolean {
  if (!import.meta.env.PROD) return true;
  if (typeof window === "undefined") return true;
  try {
    if (window.self !== window.top) return true;
  } catch {
    return true;
  }
  const h = window.location.hostname;
  if (
    h.startsWith("id-preview--") ||
    h.startsWith("preview--") ||
    h === "lovableproject.com" ||
    h.endsWith(".lovableproject.com") ||
    h === "lovableproject-dev.com" ||
    h.endsWith(".lovableproject-dev.com") ||
    h === "beta.lovable.dev" ||
    h.endsWith(".beta.lovable.dev")
  ) {
    return true;
  }
  if (new URLSearchParams(window.location.search).has("sw") &&
      new URLSearchParams(window.location.search).get("sw") === "off") {
    return true;
  }
  return false;
}

async function unregisterMatching() {
  if (!("serviceWorker" in navigator)) return;
  try {
    const regs = await navigator.serviceWorker.getRegistrations();
    for (const r of regs) {
      const url = r.active?.scriptURL ?? r.installing?.scriptURL ?? r.waiting?.scriptURL ?? "";
      if (url.endsWith(SW_URL)) await r.unregister();
    }
  } catch {
    /* noop */
  }
}

export function registerAppServiceWorker() {
  if (isRefusedContext()) {
    void unregisterMatching();
    return;
  }
  const updateSW = registerSW({
    immediate: true,
    onNeedRefresh() {
      toast("Nova versão disponível", {
        description: "Atualize para receber as últimas melhorias.",
        duration: Infinity,
        action: {
          label: "Atualizar",
          onClick: () => updateSW(true),
        },
      });
    },
    onOfflineReady() {
      toast.success("Pronto para uso offline");
    },
  });
}
