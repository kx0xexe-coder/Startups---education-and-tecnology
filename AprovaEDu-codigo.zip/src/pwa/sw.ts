/// <reference lib="webworker" />
// Custom service worker for AprovaEdu.
// Handles Web Push notifications for chat messages + basic runtime caching.
declare const self: ServiceWorkerGlobalScope;

const CACHE_STATIC = "aprovaedu-static-v1";
const CACHE_HTML = "aprovaedu-html-v1";

self.addEventListener("install", () => {
  self.skipWaiting();
});

self.addEventListener("activate", (event) => {
  event.waitUntil(self.clients.claim());
});

// Basic HTML NetworkFirst for navigations (skip OAuth)
self.addEventListener("fetch", (event) => {
  const req = event.request;
  if (req.method !== "GET") return;
  const url = new URL(req.url);
  if (url.origin !== self.location.origin) return;
  if (url.pathname.startsWith("/~oauth")) return;

  if (req.mode === "navigate") {
    event.respondWith(
      (async () => {
        try {
          const fresh = await fetch(req);
          const cache = await caches.open(CACHE_HTML);
          cache.put(req, fresh.clone());
          return fresh;
        } catch {
          const cache = await caches.open(CACHE_HTML);
          const cached = await cache.match(req);
          if (cached) return cached;
          return new Response("Offline", { status: 503 });
        }
      })()
    );
    return;
  }

  if (/\.(?:js|css|woff2|png|svg|ico)$/.test(url.pathname)) {
    event.respondWith(
      (async () => {
        const cache = await caches.open(CACHE_STATIC);
        const cached = await cache.match(req);
        if (cached) return cached;
        const fresh = await fetch(req);
        if (fresh.ok) cache.put(req, fresh.clone());
        return fresh;
      })()
    );
  }
});

// ---- Web Push ----
type PushPayload = {
  title?: string;
  body?: string;
  icon?: string;
  tag?: string;
  url?: string;
};

self.addEventListener("push", (event) => {
  let payload: PushPayload = {};
  try {
    payload = event.data?.json() ?? {};
  } catch {
    payload = { title: "AprovaEdu", body: event.data?.text() ?? "" };
  }

  const title = payload.title || "AprovaEdu";
  const options: NotificationOptions = {
    body: payload.body || "",
    icon: payload.icon || "/icon-192.png",
    badge: "/icon-192.png",
    tag: payload.tag,
    data: { url: payload.url || "/chat" },
  };

  event.waitUntil(self.registration.showNotification(title, options));
});

self.addEventListener("notificationclick", (event) => {
  event.notification.close();
  const target = (event.notification.data as { url?: string } | undefined)?.url || "/chat";
  event.waitUntil(
    (async () => {
      const all = await self.clients.matchAll({ type: "window", includeUncontrolled: true });
      for (const client of all) {
        try {
          await (client as WindowClient).navigate(target);
          return (client as WindowClient).focus();
        } catch {
          /* try next */
        }
      }
      return self.clients.openWindow(target);
    })()
  );
});
