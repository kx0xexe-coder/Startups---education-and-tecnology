
-- Feedbacks (testimonials)
CREATE TABLE public.feedbacks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  display_name text NOT NULL,
  message text NOT NULL,
  rating int NOT NULL DEFAULT 5,
  course text,
  university text,
  approved_enem boolean NOT NULL DEFAULT false,
  is_published boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT feedbacks_rating_range CHECK (rating BETWEEN 1 AND 5),
  CONSTRAINT feedbacks_message_len CHECK (char_length(message) BETWEEN 10 AND 1000),
  CONSTRAINT feedbacks_name_len CHECK (char_length(display_name) BETWEEN 2 AND 80)
);

GRANT SELECT ON public.feedbacks TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.feedbacks TO authenticated;
GRANT ALL ON public.feedbacks TO service_role;

ALTER TABLE public.feedbacks ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Public can view published feedbacks"
ON public.feedbacks FOR SELECT
USING (is_published = true);

CREATE POLICY "Users insert own feedback"
ON public.feedbacks FOR INSERT TO authenticated
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users update own feedback"
ON public.feedbacks FOR UPDATE TO authenticated
USING (auth.uid() = user_id);

CREATE POLICY "Users delete own feedback"
ON public.feedbacks FOR DELETE TO authenticated
USING (auth.uid() = user_id);

CREATE TRIGGER feedbacks_touch
BEFORE UPDATE ON public.feedbacks
FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

-- Support messages
CREATE TABLE public.support_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  subject text NOT NULL,
  message text NOT NULL,
  status text NOT NULL DEFAULT 'open',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT support_subject_len CHECK (char_length(subject) BETWEEN 3 AND 120),
  CONSTRAINT support_message_len CHECK (char_length(message) BETWEEN 10 AND 2000),
  CONSTRAINT support_status_vals CHECK (status IN ('open','in_progress','closed'))
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.support_messages TO authenticated;
GRANT ALL ON public.support_messages TO service_role;

ALTER TABLE public.support_messages ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users view own support messages"
ON public.support_messages FOR SELECT TO authenticated
USING (auth.uid() = user_id);

CREATE POLICY "Users insert own support messages"
ON public.support_messages FOR INSERT TO authenticated
WITH CHECK (auth.uid() = user_id);

CREATE TRIGGER support_messages_touch
BEFORE UPDATE ON public.support_messages
FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
