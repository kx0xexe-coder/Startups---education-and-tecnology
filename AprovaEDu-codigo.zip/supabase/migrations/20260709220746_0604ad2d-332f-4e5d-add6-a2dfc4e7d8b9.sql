
-- Backfill user_stats from existing profiles
INSERT INTO public.user_stats (user_id, display_name)
SELECT p.id, COALESCE(p.display_name, 'Estudante')
FROM public.profiles p
LEFT JOIN public.user_stats s ON s.user_id = p.id
WHERE s.user_id IS NULL;

-- Trigger to auto-create user_stats row on new profile
CREATE OR REPLACE FUNCTION public.handle_new_user_stats()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.user_stats (user_id, display_name)
  VALUES (NEW.id, COALESCE(NEW.display_name, 'Estudante'))
  ON CONFLICT (user_id) DO NOTHING;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_profile_created_stats ON public.profiles;
CREATE TRIGGER on_profile_created_stats
AFTER INSERT ON public.profiles
FOR EACH ROW EXECUTE FUNCTION public.handle_new_user_stats();

-- Ensure authenticated users can read the full leaderboard
DROP POLICY IF EXISTS "Anyone authenticated can view stats" ON public.user_stats;
CREATE POLICY "Anyone authenticated can view stats"
ON public.user_stats FOR SELECT
TO authenticated
USING (true);
