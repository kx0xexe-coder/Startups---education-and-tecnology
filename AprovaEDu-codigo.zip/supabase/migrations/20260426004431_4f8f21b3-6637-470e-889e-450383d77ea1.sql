-- ============================================
-- Profiles
-- ============================================
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.profiles enable row level security;

create policy "Users view own profile"
  on public.profiles for select
  to authenticated
  using (auth.uid() = id);

create policy "Users update own profile"
  on public.profiles for update
  to authenticated
  using (auth.uid() = id);

create policy "Users insert own profile"
  on public.profiles for insert
  to authenticated
  with check (auth.uid() = id);

-- updated_at trigger
create or replace function public.touch_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

create trigger profiles_set_updated_at
  before update on public.profiles
  for each row execute function public.touch_updated_at();

-- Auto-create profile on signup
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles (id, display_name)
  values (new.id, coalesce(new.raw_user_meta_data ->> 'display_name', new.email));
  return new;
end;
$$;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- ============================================
-- Medical reports (laudos)
-- ============================================
create type public.report_status as enum ('pending', 'approved', 'rejected');

create table public.medical_reports (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  full_name text not null,
  cid text,
  file_path text not null,
  file_name text not null,
  file_size_bytes bigint not null,
  mime_type text not null,
  status public.report_status not null default 'pending',
  consent_lgpd boolean not null default false,
  reviewer_notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.medical_reports enable row level security;

create policy "Users view own reports"
  on public.medical_reports for select
  to authenticated
  using (auth.uid() = user_id);

create policy "Users insert own reports"
  on public.medical_reports for insert
  to authenticated
  with check (auth.uid() = user_id);

create policy "Users delete own reports"
  on public.medical_reports for delete
  to authenticated
  using (auth.uid() = user_id);

create trigger medical_reports_set_updated_at
  before update on public.medical_reports
  for each row execute function public.touch_updated_at();

create index medical_reports_user_id_idx on public.medical_reports(user_id);

-- ============================================
-- Storage bucket (private)
-- ============================================
insert into storage.buckets (id, name, public)
values ('medical-reports', 'medical-reports', false);

-- Path convention: {user_id}/{filename}
create policy "Users read own report files"
  on storage.objects for select
  to authenticated
  using (
    bucket_id = 'medical-reports'
    and auth.uid()::text = (storage.foldername(name))[1]
  );

create policy "Users upload own report files"
  on storage.objects for insert
  to authenticated
  with check (
    bucket_id = 'medical-reports'
    and auth.uid()::text = (storage.foldername(name))[1]
  );

create policy "Users delete own report files"
  on storage.objects for delete
  to authenticated
  using (
    bucket_id = 'medical-reports'
    and auth.uid()::text = (storage.foldername(name))[1]
  );